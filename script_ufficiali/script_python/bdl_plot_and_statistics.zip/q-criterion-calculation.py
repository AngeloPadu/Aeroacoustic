#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 22:29:53 2024

@author: angelo
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Dec 15 17:16:58 2022

@author: mynames
"""

"Code to assess the flow profile parameters"

"Import python packages"
import numpy as np
import time
import pandas as pd
import matplotlib.pyplot as plt
import cv2
import os
xticks = [0,'$-H$','$-2H$']

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
plt.close('all')

V = '14_1'
ac_source = 'up'


path = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/q_criterion_entire_field/'

voxel_size_fine = 2.43e-05 
d = 1.17e-3


def fix_coordinate(x,y,z):
    x = x[~pd.isnull(x)]
    x = [x[1:] for x in x]
    x = [x[1:] for x in x]
    x = np.asarray(x).astype(float)
    y = y[~pd.isnull(y)]
    z = z[~pd.isnull(z)]
    z = [z[:-1] for z in z]
    z = np.asarray(z).astype(float)
    return x,y,z

"Import points and fix array of coordinates"
points = pd.read_csv(path + 'xVel_export0.txt',skiprows=6)
x,y,z = np.asarray(points.iloc[:,2]),np.asarray(points.iloc[:,3]),np.asarray(points.iloc[:,4])
x,y,z = fix_coordinate(x,y,z)

"Import data - Acoustic only"
xVac_raw = np.loadtxt(path + 'xVel_export0.txt')[:,1:]
yVac_raw = np.loadtxt(path + 'yVel_export0.txt')[:,1:]

try:
    "Import data - w/ flow"
    xVel_raw = np.loadtxt(path + 'flow/xVel_export0.txt')[:,1:]
    yVel_raw = np.loadtxt(path + 'flow/yVel_export0.txt')[:,1:]
    rho0_raw = np.loadtxt(path + 'flow/density_export0.txt')[:,1:]
except: # No Flow data
    xVel_raw = np.loadtxt(path + 'xVel_export0.txt')[:,1:]
    yVel_raw = np.loadtxt(path + 'yVel_export0.txt')[:,1:]
    rho0_raw = np.loadtxt(path + 'density_export0.txt')[:,1:]
    
"Define time vector"
time_vec = np.linspace(0,np.shape(xVac_raw)[0]-1,np.shape(xVac_raw)[0])

"Create mesh for plot"
X, Y = np.meshgrid(np.unique(x),np.unique(y))
X = np.flip(X,axis=1)
Y = np.flip(Y,axis=0)

"Create arrays to store data over time"
xVac = np.zeros((np.shape(X)[0],np.shape(X)[1],len(time_vec)))
yVac = np.copy(xVac)
xVel = np.copy(xVac)
yVel = np.copy(xVac)
rho0 = np.copy(xVac)

tempo = time.time()
for t in range(len(time_vec)):
    for i in range(np.shape(X)[0]):
        for j in range(np.shape(X)[1]):
            idx = np.intersect1d( np.where(Y[i,0]==y)[0] , np.where(X[0,j]==x)[0] )
            if len(idx) != 0:
                idx = idx[0]
                if Y[i,0] == y[idx] and X[0,j] == x[idx]:
                    xVac[i,j,t] = xVac_raw[t,idx]
                    yVac[i,j,t] = yVac_raw[t,idx]
                    xVel[i,j,t] = xVel_raw[t,idx]
                    yVel[i,j,t] = yVel_raw[t,idx]
                    rho0[i,j,t] = rho0_raw[t,idx]
elapsed = time.time() - tempo
print('It took {:.2f} seconds to load and prepare the data.'.format(elapsed))     
        
"Normalize size of arrows for velocity field plot"
xVel_norm = xVel_raw / np.sqrt(xVel_raw**2 + yVel_raw**2)
yVel_norm = yVel_raw / np.sqrt(xVel_raw**2 + yVel_raw**2)
xVac_norm = xVac_raw / np.sqrt(xVac_raw**2 + yVac_raw**2)
yVac_norm = yVac_raw / np.sqrt(xVac_raw**2 + yVac_raw**2)

"The mean velocity of the flow is the phaselocked velocity field minus the acoustically induced particle velocity"
# yVel = yVel - yVac
# xVel = xVel - xVac

"Calculate the two-dimensional vorticity in the Z direction"
"To derivative along the Y axis, use axis = 0, i.e., derivative along the lines"
"To derivative along the X axis, use axis = 1, i.e., derivative along the columns"
zVor = np.gradient(yVel,X[0,:],axis=1) - np.gradient(xVel,Y[:,0],axis=0)
"Normalize the vorticity values"
zVor = zVor/4.5e5
boundVor = 1

"Calculate Q-criterion"
def calculate_q_criterion(xVel, yVel, X, Y):
    # Calculate gradients
    dudx = np.gradient(xVel,X[0,:],axis=1)
    dudy = np.gradient(xVel,Y[:,0],axis=0)
    dvdx = np.gradient(yVel,X[0,:],axis=1)
    dvdy = np.gradient(yVel,Y[:,0],axis=0)
    
    # Calculate components of the rate-of-strain tensor S
    Sxx = dudx
    Syy = dvdy
    Sxy = 0.5 * (dudy + dvdx)
    
    # Calculate components of the rate-of-rotation tensor Omega
    Omega_xy = 0.5 * (dudy - dvdx)
    
    # Calculate Q-criterion
    Q = 0.5 * (Omega_xy**2 - Sxy**2 )
    
    return Q
nu = 1.5518539565775285e-05
Y = -Y/(0.016)


"Plot Q-criterion"
for t in range(len(time_vec)):
    
    Q = calculate_q_criterion(xVel[:,:,t], yVel[:,:,t], X, Y)
    Q = Q/1e05;
    fig, ax = plt.subplots(1, 1, figsize=(6/.833,2/.833))
    plt.axis([np.min(X), np.max(X), 0, 0.1])
    plt.pcolormesh(X,Y, Q, cmap='bwr',vmin=-1,vmax=1, shading='gouraud')
    cbar = plt.colorbar()
    plt.axvline(x=0, color='k', linewidth=1, linestyle='dashed')
    plt.axvline(x=0.0045, color='r', linewidth=0.5, linestyle='dashed')
    plt.axvline(x=0.0055, color='r', linewidth=0.5, linestyle='dashed')
    plt.axvline(x=0.0068, color='r', linewidth=0.5, linestyle='dashed')
    plt.axvline(x=0.008, color='r', linewidth=0.5, linestyle='dashed')

    cbar.set_label('Normalized Q-criterion')
    plt.xlabel('$x$ Coordinate, mm')
    plt.ylabel('$y/\\delta$')
    plt.savefig('/home/angelo/Scrivania/qcriterion.png'.format(t),dpi=300)

"Plot vorticity"
step=10
line = 1
style='dashed'
fig, ax = plt.subplots(1, 1, figsize=(6/.833,2/.833))
plt.axis([np.min(X), np.max(X), np.min(Y), np.max(Y)])
plt.pcolormesh(X,Y,zVor[:,:,0], cmap='bwr',vmin=-1,vmax=1,shading='gouraud')
cbar = plt.colorbar()
cbar.set_label('Normalized Vorticity')

