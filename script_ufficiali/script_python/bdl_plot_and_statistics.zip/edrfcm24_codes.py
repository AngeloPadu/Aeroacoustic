#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 17:59:39 2024

@author: angelo
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 15:28:58 2023

@author: angelo
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as spOpt
import pandas as pd
import scipy.io as sio
from scipy.interpolate import CubicSpline
from scipy.optimize import curve_fit
from matplotlib.ticker import FormatStrFormatter
from matplotlib.ticker import EngFormatter
from matplotlib.ticker import ScalarFormatter


import numpy as np
import pandas as pd
from scipy.signal import csd
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy.signal import welch
#%%
"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Times New Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.500,0.800,1.100,1.400,1.700,2.000,2.300,2.600]
plt.close('all')



##Path definition
resolution          = ['40vx','40vx']
resolution_write    = ['up', 'dw']

#Flow data
k  = 0.41
centro_del_canale = -0.02
A                   = 6.1e-4
B                   = 1.43e-3
C                   = 5.2
Lambda              = (A+B)**(1/3)

legend_labels = {
    'solid': 'law of the wall'

}
d = 1.17e-03
"Fluid parameters"

Tc                  = 25    
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                         
n                   = 7
u_t                 = 4.4



uTAU_Guess      = 4
# Definisci la funzione log-law
def log_law():
    
    yPlus = np.linspace(0, 100000,100000)
    uPlus = np.zeros(len(yPlus))

    eta = 1
    karman = 0.41
    for i in range(len(yPlus)):
        if yPlus[i]<=5 and eta<=1:
            uPlus[i] = yPlus[i]
        elif yPlus[i]>5 and yPlus[i]<=70 and eta<=1:
            uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*yPlus[i]+1)/np.sqrt((Lambda*yPlus[i])**2-Lambda*yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/karman*np.log(1+karman*B*yPlus[i]**4);
        elif yPlus[i] > 70 and eta <=1:
            uPlus[i] = (1/karman)*np.log(yPlus[i]) + C
            
    return uPlus, yPlus
##funzione per il calcolo della utau
def SchlichtingFit(x,y,nu,karman,eta,Lambda,B,C,idx):
    
    yPlus = np.abs(y[idx:]*x/nu)
    uPlus = np.zeros(len(yPlus))
    
    for i in range(len(yPlus)):
        if yPlus[i]<=5 and eta[i]<=1:
            uPlus[i] = yPlus[i]
        elif yPlus[i]>5 and yPlus[i]<=70 and eta[i]<=1:
            uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*yPlus[i]+1)/np.sqrt((Lambda*yPlus[i])**2-Lambda*yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/karman*np.log(1+karman*B*yPlus[i]**4);
        elif yPlus[i] > 70 and eta[i] <=1:
            uPlus[i] = (1/karman)*np.log(yPlus[i]) + C
    
    guessUx = uPlus*x
    
    return guessUx

##funzione per il calcolo della utau sperimentale
def SchlichtingFit_exp(x,y,nu,karman,eta,Lambda,B,C,idx):
    
    yPlus = np.abs(y[:idx]*x/nu)
    uPlus = np.zeros(len(yPlus))
    
    for i in range(len(yPlus)):
        if yPlus[i]<=5 and eta[i]<=0.8:
            uPlus[i] = yPlus[i]
        elif yPlus[i]>5 and yPlus[i]<=70 and eta[i]<=0.5:
            uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*yPlus[i]+1)/np.sqrt((Lambda*yPlus[i])**2-Lambda*yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/karman*np.log(1+karman*B*yPlus[i]**4);
        elif yPlus[i] > 70 and eta[i] <=0.5:
            uPlus[i] = (1/karman)*np.log(yPlus[i]) + C
    
    guessUx = uPlus*x
    
    return guessUx

def lawouterreynolds(y,H):
    reynolds_stresses_wall = 1.16-1.25*np.log(y/H)
    return reynolds_stresses_wall


path_experimantal = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/Flow/Oct2022'

# path1 = '/media/angelo/simulations/Simulations/flow_only/nominal_geom/'



path1 = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/'




data = np.asarray(pd.read_csv(path1+'/flow_only/bdl_up_dw.csv',skiprows=2))   

fig, ax = plt.subplots(1, 1, figsize=(15,8))


y = np.abs(data[:,0])
u_aft =  data[:,1]
u_bef = data[:,2]
yticks = [0.0025,0.0075,0.0125,0.0175]
plt.plot(y,u_aft,linewidth=3,label='downstream')
plt.plot(y,u_bef,linewidth=3,label='upstream')
ax.grid(alpha=0.5)
ax.set_xlim([0, 0.02])  
ax.set_ylim([0, 115])
ax.set_xticks(yticks, yticks)
ax.legend(numpoints=1,loc='best',fontsize=25)
plt.tick_params(axis='both', labelsize = 35)

# plt.savefig('/home/angelo/Scrivania/flow_prof_bd_up_dw.svg', dpi=300, edgecolor='black', bbox_inches='tight')




data = np.asarray(pd.read_csv(path1+'/flow_only/bdl_up_dw.csv',skiprows=2))   
data_up_1= np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_up_1.csv',skiprows=0))  
data_up_2 = np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_up_2.csv',skiprows=0))  
data_up_3 = np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_up_3.csv',skiprows=0))  

data_dw_1= np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_down_1.csv',skiprows=0))  
data_dw_2 = np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_down_2.csv',skiprows=0))  
data_dw_3 = np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/up/1400/sample_down_3.csv',skiprows=0))  

data_ac_dw_1= np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/down/1400/sample_up.csv',skiprows=0)) 
data_ac_dw_2= np.asarray(pd.read_csv(path1+'../40vx/flow+acoustic/down/1400/sample_down.csv',skiprows=0)) 


 
y_ac = np.abs(data_up_1[:,0])
u_bef_ac = (data_up_1[:,1])//1
u_aft_ac = (data_dw_1[:,1])//1

u_bef_ac_dw = (data_ac_dw_1[:,1])//1
u_aft_ac_dw = (data_ac_dw_2[:,1])//1

y = np.abs(data[:,0])
u_aft = data[:,1]
u_bef = data[:,2]

MaxMach  = np.max(u_bef)/c0
MeanMach = np.abs((np.trapz(u_bef,y)/y[0]))/c0

print(('Maximum Mach: {}').format(MaxMach))
print(('Mean Mach:{}').format(MeanMach))
# Trova l'indice e il valore più vicini
###########################################################################################################################################
###############################################Boundary layer tickness#####################################################################
##########################################################################################################################################

idx_max_velocita = np.argmax(u_bef)
u_99_percento = 0.99 * u_bef[idx_max_velocita]
idx_u_99_percento = np.abs(u_bef[idx_max_velocita:] - u_99_percento).argmin()+idx_max_velocita
delta = np.interp(u_99_percento, [u_bef[idx_u_99_percento-1],u_bef[idx_u_99_percento]], [y[idx_u_99_percento-1],y[idx_u_99_percento]])

idx_max_velocita_aft = np.argmax(u_aft)
u_99_percento_aft = 0.99 * u_aft[idx_max_velocita]
idx_u_99_percento_aft = np.abs(u_aft[idx_max_velocita:] - u_99_percento_aft).argmin()+idx_max_velocita_aft
delta_aft = np.interp(u_99_percento_aft, [u_aft[idx_u_99_percento_aft-1],u_aft[idx_u_99_percento_aft]], [y[idx_u_99_percento_aft-1],y[idx_u_99_percento_aft]])


idx_max_velocita_bef_ac = np.argmax(u_bef_ac)
u_99_percento_bef_ac = 0.99 * u_bef_ac[idx_max_velocita]
idx_u_99_percento_bef_ac = np.abs(u_bef_ac[idx_max_velocita:] - u_99_percento_bef_ac).argmin()+idx_max_velocita_bef_ac
delta_bef_ac = np.interp(u_99_percento_bef_ac, [u_bef_ac[idx_max_velocita_bef_ac-1],u_bef_ac[idx_max_velocita_bef_ac]], [y[idx_max_velocita_bef_ac-1],y[idx_max_velocita_bef_ac]])


idx_max_velocita_aft_ac = np.argmax(u_aft_ac)
u_99_percento_aft_ac = 0.99 * u_aft_ac[idx_max_velocita]
idx_u_99_percento_aft_ac = np.abs(u_aft_ac[idx_max_velocita:] - u_99_percento_aft_ac).argmin()+idx_max_velocita_aft_ac
delta_aft_ac = np.interp(u_99_percento_aft_ac, [u_aft_ac[idx_max_velocita_aft_ac-1],u_aft_ac[idx_max_velocita_aft_ac]], [y[idx_max_velocita_aft_ac-1],y[idx_max_velocita_aft_ac]])

idx_max_velocita_aft_ac_dw = np.argmax(u_aft_ac_dw)
u_99_percento_aft_ac_dw = 0.99 * u_aft_ac_dw[idx_max_velocita_aft_ac_dw]
idx_u_99_percento_aft_ac_dw = np.abs(u_aft_ac_dw[idx_max_velocita_aft_ac_dw:] - u_99_percento_aft_ac_dw).argmin()+idx_max_velocita_aft_ac_dw
delta_aft_ac_dw = np.interp(u_99_percento_aft_ac_dw, [u_aft_ac_dw[idx_u_99_percento_aft_ac_dw-1],u_aft_ac_dw[idx_u_99_percento_aft_ac_dw]], [y[idx_u_99_percento_aft_ac_dw-1],y[idx_u_99_percento_aft_ac_dw]])


idx_max_velocita_bef_ac_dw = np.argmax(u_bef_ac_dw)
u_99_percento_bef_ac_dw = 0.99 * u_bef_ac_dw[idx_max_velocita_bef_ac_dw]
idx_u_99_percento_bef_ac_dw = np.abs(u_bef_ac_dw[idx_max_velocita:] - u_99_percento_bef_ac_dw).argmin()+idx_max_velocita_bef_ac_dw
delta_bef_ac_dw = np.interp(u_99_percento_bef_ac_dw, [u_bef_ac_dw[idx_u_99_percento_bef_ac_dw-1],u_bef_ac_dw[idx_u_99_percento_bef_ac_dw]], [y[idx_u_99_percento_bef_ac_dw-1],y[idx_u_99_percento_bef_ac_dw]])


delta =np.abs(y[idx_u_99_percento])
print(('delta = {}').format(delta*1e03))
delt1= 0
delt2 = 0

idx_lim_num = np.where(y>=0.02)[0][-1]

delt1      = np.abs(np.trapz(1-(u_bef[idx_u_99_percento:]/np.max(u_bef[idx_u_99_percento:])),y[idx_u_99_percento:]))
delt2     = np.abs(np.trapz(u_bef[idx_u_99_percento:]/np.max(u_bef[idx_u_99_percento:])*(1-(u_bef[idx_u_99_percento:]/np.max(u_bef[idx_u_99_percento:]))),y[idx_u_99_percento:]))


###############################################################################################################################
################################################## Numerical utau ###############################################################
###############################################################################################################################

numerical_eta =np.abs(y)/delta

costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento) - u_bef[idx_u_99_percento:]))
numerical_uTau      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]

costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento_aft) - u_aft[idx_u_99_percento_aft:]))
numerical_uTau_aft      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]


costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento_bef_ac) - u_bef_ac[idx_u_99_percento_bef_ac:]))
numerical_uTau_bef_ac      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]

costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento_aft_ac) - u_aft_ac[idx_u_99_percento_aft_ac:]))
numerical_uTau_aft_ac      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]

costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento_bef_ac_dw) - u_bef_ac_dw[idx_u_99_percento_bef_ac_dw:]))
numerical_uTau_bef_ac_down      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]

costFun             = lambda x: np.sum(np.abs(SchlichtingFit(x,y,nu,k,numerical_eta,Lambda,B,C,idx_u_99_percento_aft_ac_dw) - u_aft_ac_dw[idx_u_99_percento_aft_ac_dw:]))
numerical_uTau_aft_ac_down      = spOpt.least_squares(costFun, uTAU_Guess, method = 'trf')['x'][0]

print(('utau :{}\n').format(numerical_uTau))

yplus = y*numerical_uTau/nu
uplus_bef = u_bef/numerical_uTau
yplus_aft = y*numerical_uTau_aft/nu
uplus_aft = u_aft/numerical_uTau_aft

 
yplus_ac_bef = y_ac*numerical_uTau_bef_ac/nu
yplus_ac_aft = y_ac*numerical_uTau_aft_ac/nu

uplus_bef_ac = u_bef_ac/numerical_uTau_bef_ac
uplus_aft_ac = u_aft_ac/numerical_uTau_aft_ac

yplus_ac_bef_dw = y_ac*numerical_uTau_bef_ac_down/nu
yplus_ac_aft_dw = y_ac*numerical_uTau_aft_ac_down/nu

uplus_bef_ac_dw = u_bef_ac_dw/numerical_uTau_bef_ac_down
uplus_aft_ac_dw = u_aft_ac_dw/numerical_uTau_aft_ac_down

symbols = ['s','o']  # Puoi cambiare i simboli a tuo piacimento
colors  = [ 'gray','k']

fig,ax = plt.subplots(1, 1, figsize=(8,10))

ax.plot(u_bef/np.max(u_bef),y/delta,linewidth=3, color='b',label='up. flow only')
ax.plot(u_aft/np.max(u_aft),y/delta_aft,linewidth=3, color='k', label='down. flow only')
ax.plot(u_bef_ac_dw/np.max(u_bef_ac_dw),y/delta_bef_ac,linewidth=3, color='gray', label='up. flow + acoustics up')
ax.plot(u_aft_ac/np.max(u_aft_ac),y/delta_aft_ac,linewidth=3,color='g', label='down. flow + acoustics up')
ax.plot(u_bef_ac_dw/np.max(u_bef_ac_dw),y/delta_bef_ac_dw,linewidth=3,color='r', label='up. flow + acoustics down')
ax.plot(u_aft_ac_dw/np.max(u_aft_ac_dw),y/delta_aft_ac_dw,linewidth=3,color='orange', label='down. flow + acoustics down')
ax.legend(fontsize=25)
ax.set_xscale('log')

ax.set_ylim([0,1])
ax.set_xlim([0, 1e0])
ax.set_ylabel('$u/U_{\infty}$', fontsize=40)
ax.set_xlabel('$y/\\delta$', fontsize=40)

# Impostiamo i parametri dei tick
ax.tick_params(axis='both', labelsize=30)

plt.savefig('/home/angelo/Scrivania/flow_profile.png', dpi=300, edgecolor='black', bbox_inches='tight')


fig, ax = plt.subplots(1, 1, figsize=(8,9))

ax.scatter(yplus[(yplus<7000)], uplus_bef[(yplus<7000)], marker='^', s=100, linewidth=2, edgecolors='b',facecolors='b', label='up. flow only')
ax.scatter(yplus_aft[(yplus_aft<7000)], uplus_aft[(yplus_aft<7000)], marker='o', s=100, linewidth=2, edgecolors='k',facecolors='k', label='down. flow only')

# ax.scatter(yplus[(y<1000)][::2], uplus_bef_ac[(y<1000)][::2], marker='^', s=100, linewidth=2, edgecolors='gray',facecolors='gray')
ax.scatter(yplus_ac_bef[(yplus_ac_bef<7000)], uplus_bef_ac[(yplus_ac_bef<7000)], marker='^', s=100, linewidth=2, edgecolors='gray',facecolors='gray', label='up. flow + acoustics up')
ax.scatter(yplus_ac_aft[(yplus_ac_aft<7000)], uplus_aft_ac[(yplus_ac_aft<7000)], marker='o', s=100, linewidth=2, edgecolors='g',facecolors='g', label='down. flow + acoustics up')
  
ax.scatter(yplus_ac_bef_dw[(yplus_ac_bef_dw<7000)], uplus_bef_ac_dw[(yplus_ac_bef_dw<7000)], marker='^', s=100, linewidth=2, edgecolors='r',facecolors='r', label='up. flow + acoustics down')
ax.scatter(yplus_ac_aft_dw[(yplus_ac_aft_dw<7000)], uplus_aft_ac_dw[(yplus_ac_aft_dw<7000)], marker='o', s=100, linewidth=2, edgecolors='orange',facecolors='orange', label='down. flow + acoustics down')
  



exp_MeanMach = '0296'
MeanMach_exp = 0.296
H = 0.02
# Large Pitot Tube
exp_M032        = sio.loadmat(path_experimantal + '/M{}'.format(exp_MeanMach))
exp_y           = exp_M032['position'][0]*1e-3
exp_Mach        = exp_M032['Mmean'][0]/exp_M032['Mref'][0]*MeanMach_exp

# Hot Wire Anemometer
exp_M032_hotW   = sio.loadmat(path_experimantal+'/M0296_hotW')
exp_y_hotW      = exp_M032_hotW['position'].T[0]*1e-3
exp_Mach_hotW   = exp_M032_hotW['Mmean'].T[0]/exp_M032_hotW['Mref'].T[0]*MeanMach_exp

# =============================================================================
# Fit Schlichting Experimental HotWire
# =============================================================================
print('Results from HotWire - experimental\n')

"Fit Schlichting"
exp_Tc          = exp_M032_hotW['Temp'][:,0]
exp_Tk          = exp_Tc + sutherland_tref                                     # Temperature (Kelvin)
exp_c0          = np.sqrt(gamma*R*exp_Tk)  
exp_Velocity    = exp_Mach_hotW*exp_c0

estimated_TBL_delta_velocity = 0.99*np.max(exp_Velocity)
for i in range(len(exp_Velocity)):
    if exp_Velocity[i] >= estimated_TBL_delta_velocity:
        break

exp_idx_TBL_delta           = i
exp_MeanMach                = np.trapz(exp_Mach_hotW,exp_y_hotW)/exp_y_hotW[-1]
exp_MaxMach                 = np.max(exp_Mach_hotW)
exp_mean_velocity           = exp_MeanMach*c0
exp_TBL_delta               = np.interp(estimated_TBL_delta_velocity, [exp_Velocity[i-1],exp_Velocity[i]], [exp_y_hotW[i-1],exp_y_hotW[i]])
exp_edge_TBL_velocity       = np.interp(estimated_TBL_delta_velocity, [exp_y_hotW[i-1],exp_y_hotW[i]], [exp_Velocity[i-1],exp_Velocity[i]])
exp_eta                     = exp_y_hotW[:]/exp_TBL_delta

costFun                     = lambda x: np.sum(np.abs(SchlichtingFit_exp(x,exp_y_hotW,nu,k,exp_eta,Lambda,B,C,exp_idx_TBL_delta) - exp_Velocity[:exp_idx_TBL_delta]))
experimental_uTau           = spOpt.least_squares(costFun, uTAU_Guess)['x'][0]


print('Maximum Mach: {}'.format(exp_MaxMach))
print('Mean Mach: {}'.format(exp_MeanMach))



"Build Fitted Profile"

exp_yPlus = np.linspace(0,exp_TBL_delta,100)*experimental_uTau/nu
exp_uPlus = np.zeros(len(exp_yPlus))

for i in range(len(exp_yPlus)):
    if exp_yPlus[i]<=5:
        exp_uPlus[i] = exp_yPlus[i]
    elif exp_yPlus[i]>5 and exp_yPlus[i]<=70:
        exp_uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*exp_yPlus[i]+1)/np.sqrt((Lambda*exp_yPlus[i])**2-Lambda*exp_yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*exp_yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/k*np.log(1+k*B*exp_yPlus[i]**4);
    elif exp_yPlus[i] > 70:
        exp_uPlus[i] = (1/k)*np.log(exp_yPlus[i]) + C

expY            = exp_yPlus*nu/experimental_uTau
exp_fitProfile  = exp_uPlus*experimental_uTau

exp_fitLimit    = np.where(exp_fitProfile<=exp_edge_TBL_velocity)[0][-1]
exp_fitProfile  = exp_fitProfile[:exp_fitLimit]
expY            = expY[:exp_fitLimit]

exp_TBL_delta   = expY[-1]
exp_delta1      = np.trapz(1-(exp_fitProfile/np.max(exp_fitProfile)),expY)
exp_delta2      = np.trapz(exp_fitProfile/np.max(exp_fitProfile)*(1-(exp_fitProfile/np.max(exp_fitProfile))),expY)

exp_delta1_full      = np.trapz(1-(exp_Velocity/np.max(exp_Velocity)),exp_y_hotW)
exp_delta2_full      = np.trapz(exp_Velocity/np.max(exp_Velocity)*(1-(exp_Velocity/np.max(exp_Velocity))),exp_y_hotW)

print('boundary layer thickness: {}'.format(exp_TBL_delta*1e03))
print('delta 1: {}'.format(exp_delta1*1e03))
print('delta 2: {}'.format(exp_delta2*1e03))
print('utau: {}'.format(experimental_uTau))

yplus = exp_yPlus
uplus = exp_uPlus

# ax.scatter(yplus, uplus, marker='d', s=250, linewidth=2, edgecolors='b', facecolors='b', label=f'Experimental - Hot Wire')


[U_plus, y_plus] = log_law()
yticks = [5,10,15,20,25,30]

# Plottiamo i dati
ax.semilogx(y_plus[y_plus <= 5], U_plus[y_plus <= 5], color='k', linestyle='dashed', linewidth=3)
ax.semilogx(y_plus[y_plus > 4], U_plus[y_plus > 4], color='k', linestyle='dashed', linewidth=3, label='Law of the wall')

# Label degli assi
ax.set_ylabel('$u^{+}$', fontsize=40)
ax.set_xlabel('$y^{+}$', fontsize=40)

# Impostiamo i parametri dei tick
ax.tick_params(axis='both', labelsize=30)

# Aggiungiamo la griglia con una leggera trasparenza
#ax.grid(alpha=0.5, which='both', linestyle='--', linewidth=0.7)

# Impostiamo i limiti degli assi
ax.set_xlim([1, 7000])
ax.set_ylim([1, 40])

# Impostiamo i ticks dell'asse y
yticks = np.arange(1, 36, 5)
ax.set_yticks(yticks)
ax.set_yticklabels(yticks)

# Aggiungiamo la legenda
ax.legend(numpoints=1, loc='upper left', fontsize=20, frameon=True, fancybox=True)


plt.savefig('/home/angelo/Scrivania/flow_profile_wallunits.png', dpi=300, edgecolor='black', bbox_inches='tight')

Re_3341 = np.asarray(pd.read_csv(path1 + '../../nominal_geom/Re_3341.csv', header=0, delimiter=';', decimal=','))

data_fluc = np.asarray(np.loadtxt(path1+'flow_only/time_history/fluctuation_before.txt',skiprows=0))[1:] 
data_fluc_aft = np.asarray(np.loadtxt(path1+'flow_only/time_history/fluctuation_after.txt',skiprows=0))[1:] 

data_fluc_ac = np.asarray(np.loadtxt(path1+'flow+acoustic/up/2000/fluctuation_before.txt',skiprows=0))[1:] 
data_fluc_aft_ac = np.asarray(np.loadtxt(path1+'flow+acoustic/up/1400/fluctuation_after.txt',skiprows=0))[1:] 


data_fluc_ac_dw = np.asarray(np.loadtxt(path1+'flow+acoustic/down/1400/fluctuation_before.txt',skiprows=0))[1:] 
data_fluc_aft_ac_dw = np.asarray(np.loadtxt(path1+'flow+acoustic/down/1400/fluctuation_after.txt',skiprows=0))[1:] 


reynolds_stress = data_fluc / numerical_uTau**2
reynolds_stress_down = data_fluc_aft / numerical_uTau_aft**2

reynolds_stress_ac = data_fluc_ac / numerical_uTau_bef_ac**2
reynolds_stress_down_ac = data_fluc_aft_ac / numerical_uTau_aft_ac**2

reynolds_stress_ac_dw = data_fluc_ac_dw / numerical_uTau_bef_ac_down**2
reynolds_stress_down_ac_dw = data_fluc_aft_ac_dw / numerical_uTau_aft_ac_down**2



fig,ax = plt.subplots(1, 1, figsize=(12,10))
yplus = y*numerical_uTau/nu
 
ax.scatter(yplus[(yplus<2000)],reynolds_stress[(yplus<2000)], marker='^',s=150, linewidth=2, edgecolors='b', facecolors='b', label='up. flow only')
ax.scatter(yplus_aft[(yplus_aft<2000)],reynolds_stress_down[(yplus_aft<2000)], marker='o',s=150, linewidth=2, edgecolors='k', facecolors='k', label='down. flow only')

ax.scatter(yplus_ac_bef[(yplus_ac_bef<2000)],reynolds_stress_ac[(yplus_ac_bef<2000)], marker='^',s=150, linewidth=2, edgecolors='gray', facecolors='gray', label='up. flow + acoustics')
ax.scatter(yplus_ac_aft[(yplus_ac_aft<2000)],reynolds_stress_down_ac[(yplus_ac_aft<2000)], marker='o',s=150, linewidth=2, edgecolors='g', facecolors='g', label='down. flow + acoustics')

ax.scatter(yplus_ac_bef_dw[(yplus_ac_bef_dw<2000)],reynolds_stress_ac_dw[(yplus_ac_bef_dw<2000)], marker='^',s=150, linewidth=2, edgecolors='r', facecolors='r', label='up. flow + acoustics down')
ax.scatter(yplus_ac_aft_dw[(yplus_ac_aft_dw<2000)],reynolds_stress_down_ac_dw[(yplus_ac_aft_dw<2000)], marker='o',s=150, linewidth=2, edgecolors='orange', facecolors='orange', label='down. flow + acoustics down')

ax.set_xscale('log') 
#ax.scatter(Re_5000[:35,0],Re_5000[:35,1], marker='s',s=250, linewidth=2, edgecolors='k', facecolors='none', label=r'Experimental data $Re_{\tau} = 5412$')    
ax.scatter(Re_3341[:35, 0], Re_3341[:35, 1], marker='v', s=250, linewidth=2, edgecolors='r', facecolors='r', label=r'Experiments $Re_{\tau} = 3341$')

plt.ylabel('$\\rho u^{\\prime}u^{\\prime} / \\rho_w u_{\\tau}^2$', fontsize=40)
plt.xlabel('$y^{+}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 30)
#ax.grid(alpha=0.5)
ax.set_xlim([1, 15000])
ax.set_ylim([1, 10])
ax.legend(numpoints=1, loc='best', fontsize=25)
plt.savefig('/home/angelo/Scrivania/fluctuation_wallunits_acoustics.png', dpi=300, edgecolor='black', bbox_inches='tight')

H = 0.02
y_data = Re_3341[:35,0]*nu/(4.12)

reynolds_stresses_wall = lawouterreynolds(y_data, H)
fig,ax = plt.subplots(1, 1, figsize=(12,10))
yplus = y*numerical_uTau/nu
 
ax.scatter(y/H,reynolds_stress, marker='^',s=150, linewidth=2, edgecolors='b', facecolors='b', label='up. flow only')
# ax.scatter(y/H,reynolds_stress_down, marker='o',s=150, linewidth=2, edgecolors='k', facecolors='k', label='down. flow only')

ax.scatter(y/H,reynolds_stress_ac, marker='^',s=150, linewidth=2, edgecolors='gray', facecolors='gray', label='up. flow + acoustics')
# ax.scatter(y/H,reynolds_stress_down_ac, marker='o',s=150, linewidth=2, edgecolors='g', facecolors='g', label='down. flow + acoustics')

ax.scatter(y/H,reynolds_stress_ac_dw, marker='^',s=150, linewidth=2, edgecolors='r', facecolors='r', label='up. flow + acoustics down')
# ax.scatter(y/H,reynolds_stress_down_ac_dw, marker='o',s=150, linewidth=2, edgecolors='orange', facecolors='orange', label='down. flow + acoustics down')
ax.scatter(y_data/H, Re_3341[:35, 1], marker='v', s=250, linewidth=2, edgecolors='r', facecolors='r', label=r'Experiments $Re_{\tau} = 3341$')

ax.plot(y_data/H,reynolds_stresses_wall, linewidth=2, color='k', label='law')

ax.set_xscale('log') 
#ax.scatter(Re_5000[:35,0],Re_5000[:35,1], marker='s',s=250, linewidth=2, edgecolors='k', facecolors='none', label=r'Experimental data $Re_{\tau} = 5412$')    
# ax.scatter(Re_3341[:35, 0], Re_3341[:35, 1], marker='v', s=250, linewidth=2, edgecolors='r', facecolors='r', label=r'Experiments $Re_{\tau} = 3341$')

plt.ylabel('$\\rho u^{\\prime}u^{\\prime} / \\rho_w u_{\\tau}^2$', fontsize=40)
plt.xlabel('$y/H$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 30)
#ax.grid(alpha=0.5)
ax.set_xlim([2e-03, 1])
ax.set_ylim([1, 10])
ax.legend(numpoints=1, loc='best', fontsize=25)


forces = np.loadtxt('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/145/1400/forces.txt')
xforces = forces[:,1]
xforces = np.mean(xforces)


F_smooth = (0.074*5)/8*rho*max(u_aft)**(7/5)*nu**(1/5)*(0.137)**(4/5)*0.012
fig,ax = plt.subplots(1, 1, figsize=(8,5))

categorie = ['no sound', '145']
orifices = [0.042, xforces]


# Posizioni delle barre
ind = np.arange(len(categorie))
width = 0.1 # Larghezza delle barre
valori = np.array(orifices) / (rho * c0**2 * d**2)
F_smooth_norm = F_smooth / (rho * c0**2 * d**2)

# Create bars with black edges and specified colors
plt.bar(ind/3 + width/2, valori, width, label='Orifices', color='blue', edgecolor='black')
plt.bar(ind/3 - width/2, [F_smooth_norm, 0], width, label='Smooth', color='#D92600', edgecolor='black')  # Darker red

# Customize the x-axis ticks and labels
ax.set_xticks(ind/3)
ax.set_xticks([0,0.38],['flow only', 'flow + acoustics'])
plt.tick_params(axis='both', labelsize=25)

# Add labels and title
plt.ylabel('$F_{drag}/\\rho_{\infty}a^2_{\infty}d^2$', fontsize=25)

plt.savefig('/home/angelo/Scrivania/forces.png', dpi=300, edgecolor='black', bbox_inches='tight')



data = np.asarray(pd.read_csv('/home/angelo/Scaricati/pressure_time_signal.csv'))[:-1,:]
data            = data.astype(float)

data1 = np.asarray(pd.read_csv('/home/angelo/Scaricati/pressure_time_signal_1.csv'))[:-1,:]
data1            = data.astype(float)

data2 = np.asarray(pd.read_csv('/home/angelo/Scaricati/pressure_time_signal_2.csv'))[:-1,:]
data2            = data.astype(float)

dt = 3.319251e-05
fs = 1/dt
pressure = data[:,1]
pressure_1 = data1[:,1]
pressure_2 = data2[:,1]
nperseg = len(pressure)//3

f, Sxx = welch(pressure,fs=fs,nperseg=nperseg)

fig, ax = plt.subplots(1, 1, figsize=(10,6))

ax.loglog(f,Sxx,color='k',linewidth=3,label='flow only')


data = np.asarray(pd.read_csv('/home/angelo/Scaricati/pressure_time_signal_acoustics.csv'))[:-1,:]
data            = data.astype(float)
last_417_values = data[-417:, :]
for _ in range(5):
    data = np.concatenate((data, last_417_values), axis=0)

dt = 2.370893e-06
fs = 1/dt
pressure = data[:,1]
nperseg = len(pressure)//2

f, Sxx = welch(pressure,fs=fs,nperseg=nperseg)

ax.loglog(f,Sxx,linewidth=3,color='b',label='flow + acoustics')

plt.ylabel('$Power$ $Spectrum$', fontsize=30)
plt.xlabel('$f [Hz]$',fontsize = 30)
plt.tick_params(axis='both', labelsize = 25)
#ax.grid(alpha=0.5)
ax.set_xlim([5e01, 20000])
ax.set_ylim([1e-05, 1e06])
plt.tick_params(axis='both', labelsize = 25)

ax.legend(numpoints=1, loc='lower left', fontsize=25)

plt.savefig('/home/angelo/Scrivania/spectra.png', dpi=300, edgecolor='black', bbox_inches='tight')
