#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 11:50:10 2024

@author: angelo
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 16:32:04 2024

@author: angelo
"""


import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as spOpt
import pandas as pd
import scipy.io as sio
import os
from scipy.interpolate import CubicSpline
from scipy.optimize import curve_fit
from scipy.signal import welch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib.patches import Rectangle

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Times New Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.500,0.800,1.100,1.400,1.700,2.000,2.300,2.600]
plt.close('all')


#Flow data
k  = 0.41
centro_del_canale = -0.02
A                   = 6.1e-4
B                   = 1.43e-3
C                   = 5.2
Lambda              = (A+B)**(1/3)

legend_labels = {
    'solid': 'law of the wall'

}

"Fluid parameters"

Tc                  = 25    
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                         
n                   = 7
u_t                 = 4.4

l = 0.137

uTAU_Guess      = 4
# Definisci la funzione log-law
def log_law():
    y_plus = np.linspace(0, 100000,10000000)
    U_plus_bl = y_plus[y_plus<15]
    U_plus = (1/k) * np.log(y_plus[y_plus > 10]) + C
    return y_plus, U_plus_bl, U_plus

##funzione per il calcolo della utau
def SchlichtingFit(x,y,nu,karman,eta,Lambda,B,C,idx):
    
    yPlus = np.abs(y[idx:]*x/nu)
    uPlus = np.zeros(len(yPlus))
    
    for i in range(len(yPlus)):
        if yPlus[i]<=5 and eta[i]<=1:
            uPlus[i] = yPlus[i]
        elif yPlus[i]>5 and yPlus[i]<=70 and eta[i]<=1:
            uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*yPlus[i]+1)/np.sqrt((Lambda*yPlus[i])**2-Lambda*yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/karman*np.log(1+karman*B*yPlus[i]**4);
        elif yPlus[i] > 70 and eta[i] <=1:
            uPlus[i] = (1/karman)*np.log(yPlus[i]) + C
    
    guessUx = uPlus*x
    
    return guessUx

##funzione per il calcolo della utau sperimentale
def SchlichtingFit_exp(x,y,nu,karman,eta,Lambda,B,C,idx):
    
    yPlus = np.abs(y[:idx]*x/nu)
    uPlus = np.zeros(len(yPlus))
    
    for i in range(len(yPlus)):
        if yPlus[i]<=5 and eta[i]<=1:
            uPlus[i] = yPlus[i]
        elif yPlus[i]>5 and yPlus[i]<=70 and eta[i]<=1:
            uPlus[i] = (1/Lambda)*(1/3 * np.log((Lambda*yPlus[i]+1)/np.sqrt((Lambda*yPlus[i])**2-Lambda*yPlus[i]+1)) + 1/np.sqrt(3)*(np.arctan((2*Lambda*yPlus[i]-1)/np.sqrt(3))+np.pi/6) ) + 0.25/karman*np.log(1+karman*B*yPlus[i]**4);
        elif yPlus[i] > 70 and eta[i] <=1:
            uPlus[i] = (1/karman)*np.log(yPlus[i]) + C
    
    guessUx = uPlus*x
    
    return guessUx



def scientific_formatter(x, pos):
    """Convert the axis values to scientific notation."""
    return f'{x:.1e}'

def add_white_rectangles(ax, x_positions, width):
    """Add white rectangles between specific x positions."""
    for i in range(len(x_positions) - 1):
        rect = Rectangle((x_positions[i], ax.get_ylim()[0]), width,
                         ax.get_ylim()[1] - ax.get_ylim()[0],
                         facecolor='white', edgecolor='none', zorder=0)
        ax.add_patch(rect)
        
        
        
def H_model(k, Re_star):
    H = (1 - 7.11 / (k**-1 * np.log(Re_star) + 3.3))**-1 + 12 / Re_star
    return H
#########################################################CODE STARTS##################################################################
#%%################################## ESTIMATION OF THE BDL EVOLUTION ALONG THE LINER ################################################
path_experimantal = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/Flow/Oct2022'

# path1 = '/media/angelo/simulations/Simulations/flow_only/nominal_geom/'


path1 = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/time_history/samples_along_liner/'
path_ac = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow+acoustic/up/1400/samples_along_liner/'
path_ac_dw = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow+acoustic/down/1400/samples_along_liner/'

delt_star = []
theta = []
delt_star_ac = []
delt_star_ac_dw = []

theta_ac = []
theta_ac_dw = []
velocity = []
delta = []
delta_ac = []
delta_ac_dw = []
reynolds_theta = []
reynolds_theta_ac = []
reynolds_theta_ac_dw = []
list_u_99 = []

fig, ax = plt.subplots(1, 1, figsize=(20, 10))
for i in range(len(os.listdir(path1))-1):
    
    
    data = np.asarray(pd.read_csv(path1 + 'sample_{}.csv'.format(i+1),skiprows=0))[:155,:]
    data_ac = np.asarray(pd.read_csv(path_ac +'sample_{}.csv'.format(i+1), skiprows=0))[:155,:]
    data_ac_dw = np.asarray(pd.read_csv(path_ac_dw +'sample_{}.csv'.format(i+1), skiprows=0))[:155,:]

    y = np.abs(data[:, 0])  # Distanza dalla parete
    u = data[:, 1]
    velocity.append(u)
    u_ac = data_ac[:,1]
    u_ac_dw = data_ac_dw[:,1]
    MaxMach  = np.max(u)/c0
    MeanMach = np.abs((np.trapz(u,y)/y[0]))/c0

###########################################################################################################################################
###############################################Boundary layer tickness#####################################################################
##########################################################################################################################################


###################FLOW ONLY###################################################
    if i == 0:
        max_u = np.max(u)
    
    idx_max_velocita = np.argmax(u)
    
    u_99_percento =  u[idx_max_velocita]
    list_u_99.append(u_99_percento/max_u)
    # u_99_percento = 0.99*max_u
    # idx_max_velocita = np.abs(max_u-u).argmin()
    idx_u_99_percento = np.abs(u[idx_max_velocita:] - u_99_percento).argmin()+idx_max_velocita

    delta.append(np.abs(y[idx_u_99_percento]))

       
    idx_lim_num = np.where(y>=0.02)[0][-1]

    delt_star.append(np.abs(np.trapz(1-(u[idx_u_99_percento:]/np.max(u[idx_u_99_percento:])),y[idx_u_99_percento:])))
    theta.append(np.abs(np.trapz(u[idx_u_99_percento:-12]/np.max(u[idx_u_99_percento:-12])*(1-(u[idx_u_99_percento:-12]/np.max(u[idx_u_99_percento:-12]))),y[idx_u_99_percento:-12])))

    reynolds_theta.append((delt_star[i]*u_99_percento)/nu)
# ################FLOW + ACOUSTICS###############################################


    idx_max_velocita = np.argmax(u_ac)
    
    u_99_percento = u_ac[idx_max_velocita]
    idx_u_99_percento = np.abs(u_ac[idx_max_velocita:] - u_99_percento).argmin()+idx_max_velocita

    delta_ac.append(np.abs(y[idx_u_99_percento]))

    
       
    idx_lim_num = np.where(y>=0.02)[0][-1]

    delt_star_ac.append(np.abs(np.trapz(1-(u_ac[idx_u_99_percento:]/np.max(u_ac[idx_u_99_percento:])),y[idx_u_99_percento:])))
    theta_ac.append(np.abs(np.trapz(u_ac[idx_u_99_percento:]/np.max(u_ac[idx_u_99_percento:])*(1-(u_ac[idx_u_99_percento:]/np.max(u_ac[idx_u_99_percento:]))),y[idx_u_99_percento:])))
    reynolds_theta_ac.append((delt_star_ac[i]*u_99_percento)/nu)


    idx_max_velocita = np.argmax(u_ac_dw)
    
    u_99_percento = u_ac_dw[idx_max_velocita]
    idx_u_99_percento = np.abs(u_ac_dw[idx_max_velocita:] - u_99_percento).argmin()+idx_max_velocita
    
    delta_ac_dw.append(np.abs(y[idx_u_99_percento]))
    
    
       
    idx_lim_num = np.where(y>=0.02)[0][-1]
    
    delt_star_ac_dw.append(np.abs(np.trapz(1-(u_ac_dw[idx_u_99_percento:]/np.max(u_ac_dw[idx_u_99_percento:])),y[idx_u_99_percento:])))
    theta_ac_dw.append(np.abs(np.trapz(u_ac_dw[idx_u_99_percento:]/np.max(u_ac_dw[idx_u_99_percento:])*(1-(u_ac_dw[idx_u_99_percento:]/np.max(u_ac_dw[idx_u_99_percento:]))),y[idx_u_99_percento:])))

    reynolds_theta_ac_dw.append((delt_star_ac_dw[i]*u_99_percento)/nu)


    if  i ==72 or i ==74 or i ==75:
        
        ax.scatter(u/np.max(u),y/delta[i], label = 'profile {}'.format(i))
        ax.set_xlim([0, 1])
        ax.set_ylim([0, 1])
        plt.ylabel('$ y/\\delta$', fontsize=40)
        plt.xlabel('$u/u_{\\infty}$',fontsize = 40)
        ax.legend(numpoints=1, loc='best', fontsize=35)
        # print(('Case {}').format(i))
        # print(('idx_u_99: {}').format(idx_u_99_percento))
        # print(('delta:{}').format(delta))
        # print(('thetha:{}').format(theta[i]))



delt_star_ac = np.array(delt_star_ac)
delt_star_ac_dw = np.array(delt_star_ac_dw)
delt_star = np.array(delt_star)

theta = np.array(theta)
theta_ac = np.array(theta_ac)
theta_ac_dw = np.array(theta_ac_dw)


   
x = np.arange(-0.07,0.2,0.001)

# Positions for the black lines
x_positions = [0.0044 + i * 0.01243 for i in range(11)]
x_positions += [0.0055 + i * 0.01243 for i in range(11)]
x_positions += [0.0069 + i * 0.01243 for i in range(11)]
x_positions += [0.0080 + i * 0.01243 for i in range(11)]
x_positions = sorted(x_positions)
# Width for the white rectangles
width = 0.0011
cvt_width_mm = 0.49*25.4
# First plot
fig, ax = plt.subplots(1, 1, figsize=(20, 10))
ax.scatter(x,list_u_99)

reynolds_star = np.arange(1.4e04,2e04,100)
H = H_model(k, reynolds_star)

fig, ax = plt.subplots(1, 1, figsize=(20, 10))
ax.scatter(reynolds_theta[:], delt_star[:]/theta[:], color='k', linewidth=3, label='only flow')
ax.scatter(reynolds_theta_ac[:], delt_star_ac[:]/theta_ac[:], color='r',linewidth=3, label='flow + acoustics up')
ax.scatter(reynolds_theta_ac_dw[:], delt_star_ac_dw[:]/theta_ac_dw[:], color='b',linewidth=3, label='flow + acoustics down')
# ax.plot(reynolds_star, H, color='gray',linewidth=3, linestyle='-.', label='Chauhan et al. 2009 ZPG TBL')

plt.ylabel(r'$H$', fontsize=35)
plt.xlabel('$Re_{\\delta^{*}}$', fontsize=35)
plt.tick_params(axis='both', labelsize=35)
ax.xaxis.set_major_formatter(FuncFormatter(scientific_formatter))
ax.grid(alpha=0.5)
ax.legend(numpoints=1, loc='best', fontsize=35)
plt.savefig('/home/angelo/Scrivania/shape_factor_vs_reynolds_star.png', dpi=300, edgecolor='black', bbox_inches='tight')

fig, ax = plt.subplots(1, 1, figsize=(20, 10))
ax.scatter(x/l, delt_star[:], color='k', linewidth=3, label='only flow')
ax.scatter(x/l, delt_star_ac[:], color='r',linewidth=3, label='flow + acoustics up')
ax.scatter(x/l, delt_star_ac_dw[:], color='b',linewidth=3, label='flow + acoustics down')

plt.ylabel(r'$\delta^{*}$', fontsize=35)
plt.xlabel('$x/L$', fontsize=35)
plt.tick_params(axis='both', labelsize=35)
ax.yaxis.set_major_formatter(FuncFormatter(scientific_formatter))
ax.grid(alpha=0.5)
ax.legend(numpoints=1, loc='best', fontsize=35)
ax.set_ylim([0.0021, 0.00255])

for xc in np.arange(0, 0.137, cvt_width_mm / 1000):
    xc = xc/l
    ax.axvline(x=xc, color='r', linewidth=0.5, linestyle='dashed')

ax.axvline(x=max(x)/l, color='r', linewidth=0.5, linestyle='dashed')

# Add other vertical lines at specific intervals
for pos in x_positions:
    pos = float(pos)/l

    ax.axvline(x=pos, color='k', linewidth=0.5, linestyle='dashed')
plt.savefig('/home/angelo/Scrivania/delta_star.png', dpi=300, edgecolor='black', bbox_inches='tight')


fig, ax = plt.subplots(1, 1, figsize=(20, 10))
ax.scatter(x/l, delt_star[:]/theta[:], color='k', linewidth=3, label='only flow')
ax.scatter(x/l, delt_star_ac[:]/theta_ac[:], color='r',linewidth=3, label='flow + acoustics up')
ax.scatter(x/l, delt_star_ac_dw[:]/theta_ac_dw[:], color='b',linewidth=3, label='flow + acoustics down')

plt.ylabel(r'$H$', fontsize=35)
plt.xlabel('$x/L$', fontsize=35)
plt.tick_params(axis='both', labelsize=35)
# ax.yaxis.set_major_formatter(FuncFormatter(scientific_formatter))
ax.grid(alpha=0.5)
ax.legend(numpoints=1, loc='best', fontsize=35)
# ax.set_ylim([0.0021, 0.00255])

for xc in np.arange(0, 0.137, cvt_width_mm / 1000):
    xc = xc/l
    ax.axvline(x=xc, color='r', linewidth=0.5, linestyle='dashed')


# Add other vertical lines at specific intervals
for pos in x_positions:
    pos = float(pos)/l

    ax.axvline(x=pos, color='k', linewidth=0.5, linestyle='dashed')
plt.savefig('/home/angelo/Scrivania/shape_factor.png', dpi=300, edgecolor='black', bbox_inches='tight')

# Add white rectangles between black lines
add_white_rectangles(ax, x_positions, width)



# Second plot
fig, ax = plt.subplots(1, 1, figsize=(20, 10))
ax.scatter(x/l, theta, color='k', linewidth=3, label='only flow')
ax.scatter(x/l, theta_ac, color='r', linewidth=3, label='flow + acoustics up')
ax.scatter(x/l, theta_ac_dw, color='b', linewidth=3, label='flow + acoustics down')

# Add vertical dashed lines every cvt_width_mm/1000
for xc in np.arange(0, 0.137, cvt_width_mm / 1000):
    xc = xc/l

    ax.axvline(x=xc, color='r', linewidth=0.5, linestyle='dashed')


# Add other vertical lines at specific intervals
for pos in x_positions:
    pos = float(pos)/l
    ax.axvline(x=pos, color='k', linewidth=0.5, linestyle='dashed')

# Add white rectangles between black lines
add_white_rectangles(ax, x_positions, width)

plt.ylabel(r'$\theta$', fontsize=35)
plt.xlabel('$x/L$', fontsize=35)
plt.tick_params(axis='both', labelsize=35)
ax.yaxis.set_major_formatter(FuncFormatter(scientific_formatter))
ax.grid(alpha=0.5)
ax.legend(numpoints=1, loc='best', fontsize=35)
# Uncomment the line below to set y-axis limits if necessary
# ax.set_ylim([0.002, 0.0025])
plt.savefig('/home/angelo/Scrivania/theta_star.png', dpi=300, edgecolor='black', bbox_inches='tight')
#%%########################################### FLOW PROFILES INSIDE CAVITIES ##################################################################

cavity = '1_cavity'

data = ('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/profiles_inside_cavity/{}/'.format(cavity))

y = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,0]*(-1)
x1 = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,1]
x2 = np.asarray(pd.read_csv(data + 'x2.csv',skiprows=0))[:,1]
x3 = np.asarray(pd.read_csv(data + 'x3.csv',skiprows=0))[:,1]


fig, ax = plt.subplots(1, 1, figsize=(10, 10))

plt.plot(x1/(np.max(x1)),y, linewidth = 3, label = 'upstream edge')
plt.plot(x2/(np.max(x2)),y, linewidth = 3, label = 'center')
plt.plot(x3/(np.max(x3)),y, linewidth = 3, label = 'downstream edge')

# ax.set_xlim([-0.02, 0.75])
# ax.set_ylim([-0.1, 0.15])
plt.ylabel('$ y/\\delta$', fontsize=40)
plt.xlabel('$u/u_{\\infty}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 40)
ax.legend(fontsize=40)
# plt.savefig('/home/angelo/Scrivania/profiles_{}.png'.format(cavity), dpi=300, edgecolor='black', bbox_inches='tight')
cavity = '6_cavity'

data = ('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/profiles_inside_cavity/{}/'.format(cavity))
y = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,0]*(-1)
x1_6 = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,1]
x2_6 = np.asarray(pd.read_csv(data + 'x2.csv',skiprows=0))[:,1]
x3_6 = np.asarray(pd.read_csv(data + 'x3.csv',skiprows=0))[:,1]


cavity = '11_cavity'

data = ('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/profiles_inside_cavity/{}/'.format(cavity))
y = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,0]*(-1)
x1_11 = np.asarray(pd.read_csv(data + 'x1.csv',skiprows=0))[:,1]
x2_11 = np.asarray(pd.read_csv(data + 'x2.csv',skiprows=0))[:,1]
x3_11 = np.asarray(pd.read_csv(data + 'x3.csv',skiprows=0))[:,1]


fig, ax = plt.subplots(1, 1, figsize=(10, 10))

plt.plot(x1/(np.max(x1)),y, linewidth = 3, label = 'first cavity')
plt.plot(x1_6/(np.max(x1_6)),y, linewidth = 3, label = 'sixth cavity')
plt.plot(x1_11/(np.max(x1_11)),y, linewidth = 3, label = 'eleventh cavity')

# ax.set_xlim([-0.02, 0.75])
# ax.set_ylim([-0.05, 0.05])
plt.ylabel('$ y/\\delta$', fontsize=40)
plt.xlabel('$u/u_{\\infty}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 40)
ax.legend(fontsize=40)

plt.savefig('/home/angelo/Scrivania/profiles_overlapped_1.png'.format(cavity), dpi=300, edgecolor='black', bbox_inches='tight')

fig, ax = plt.subplots(1, 1, figsize=(10, 10))

plt.plot(x2/(np.max(u)),y/delta, linewidth = 3, label = 'first cavity')
plt.plot(x2_6/(np.max(u)),y/delta, linewidth = 3, label = 'sixth cavity')
plt.plot(x2_11/(np.max(u)),y/delta, linewidth = 3, label = 'eleventh cavity')

ax.set_xlim([-0.02, 0.75])
ax.set_ylim([-0.05, 0.05])
plt.ylabel('$ y/\\delta$', fontsize=40)
plt.xlabel('$u/u_{\\infty}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 40)
ax.legend(fontsize=40)

plt.savefig('/home/angelo/Scrivania/profiles_overlapped_2.png'.format(cavity), dpi=300, edgecolor='black', bbox_inches='tight')


fig, ax = plt.subplots(1, 1, figsize=(10, 10))

plt.plot(x3/(np.max(u)),y/delta, linewidth = 3, label = 'first cavity')
plt.plot(x3_6/(np.max(u)),y/delta, linewidth = 3, label = 'sixth cavity')
plt.plot(x3_11/(np.max(u)),y/delta, linewidth = 3, label = 'eleventh cavity')

ax.set_xlim([-0.02, 0.75])
ax.set_ylim([-0.05, 0.05])
plt.ylabel('$ y/\\delta$', fontsize=40)
plt.xlabel('$u/u_{\\infty}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 40)
ax.legend(fontsize=40)

plt.savefig('/home/angelo/Scrivania/profiles_overlapped_3.png'.format(cavity), dpi=300, edgecolor='black', bbox_inches='tight')
