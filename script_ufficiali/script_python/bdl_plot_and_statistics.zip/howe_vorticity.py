# -*- coding: utf-8 -*-
"""
Created on Thu Dec 15 17:16:58 2022

@author: mynames
"""

"Code to assess the flow profile parameters"

"Import python packages"
import numpy as np
import time
import pandas as pd
import matplotlib.pyplot as plt
import cv2
import os
xticks = [0,'$-H$','$-2H$']

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
plt.close('all')

V = '14_1'
ac_source = 'up'

if ac_source == 'up':
    path = '/media/angelo/scanned_geom/Simulations/145/scanned_geom/flow/40vx/downstream/1400/vorticity/'.format(V)
    path_last = '/media/angelo/simulations/Simulations/flow_only/scanned_geom/40vx/vorticity_last/'.format(V)    
    
voxel_size_fine = 2.43e-05 
d = 1.17e-3

if ac_source == 'up':
    path_save = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/'
else:
    path_save = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/'

def fix_coordinate(x,y,z):
    x = x[~pd.isnull(x)]
    x = [x[1:] for x in x]
    x = [x[1:] for x in x]
    x = np.asarray(x).astype(float)
    y = y[~pd.isnull(y)]
    z = z[~pd.isnull(z)]
    z = [z[:-1] for z in z]
    z = np.asarray(z).astype(float)
    return x,y,z

"Import points and fix array of coordinates"
points = pd.read_csv(path + 'xVel_export0.txt',skiprows=6)
x,y,z = np.asarray(points.iloc[:,2]),np.asarray(points.iloc[:,3]),np.asarray(points.iloc[:,4])
x,y,z = fix_coordinate(x,y,z)

"Import data - Acoustic only"
xVac_raw = np.loadtxt(path + 'xVel_export0.txt')[:,1:]
yVac_raw = np.loadtxt(path + 'yVel_export0.txt')[:,1:]

try:
    "Import data - w/ flow"
    xVel_raw = np.loadtxt(path + 'flow/xVel_export0.txt')[:,1:]
    yVel_raw = np.loadtxt(path + 'flow/yVel_export0.txt')[:,1:]
    rho0_raw = np.loadtxt(path + 'flow/density_export0.txt')[:,1:]
except: # No Flow data
    xVel_raw = np.loadtxt(path + 'xVel_export0.txt')[:,1:]
    yVel_raw = np.loadtxt(path + 'yVel_export0.txt')[:,1:]
    rho0_raw = np.loadtxt(path + 'density_export0.txt')[:,1:]
    
"Define time vector"
time_vec = np.linspace(0,np.shape(xVac_raw)[0]-1,np.shape(xVac_raw)[0])

"Create mesh for plot"
X, Y = np.meshgrid(np.unique(x),np.unique(y))
X = np.flip(X,axis=1)
Y = np.flip(Y,axis=0)

"Create arrays to store data over time"
xVac = np.zeros((np.shape(X)[0],np.shape(X)[1],len(time_vec)))
yVac = np.copy(xVac)
xVel = np.copy(xVac)
yVel = np.copy(xVac)
rho0 = np.copy(xVac)

tempo = time.time()
for t in range(len(time_vec)):
    for i in range(np.shape(X)[0]):
        for j in range(np.shape(X)[1]):
            idx = np.intersect1d( np.where(Y[i,0]==y)[0] , np.where(X[0,j]==x)[0] )
            if len(idx) != 0:
                idx = idx[0]
                if Y[i,0] == y[idx] and X[0,j] == x[idx]:
                    xVac[i,j,t] = xVac_raw[t,idx]
                    yVac[i,j,t] = yVac_raw[t,idx]
                    xVel[i,j,t] = xVel_raw[t,idx]
                    yVel[i,j,t] = yVel_raw[t,idx]
                    rho0[i,j,t] = rho0_raw[t,idx]
elapsed = time.time() - tempo
print('It took {:.2f} seconds to load and prepare the data.'.format(elapsed))     
        
"Normalize size of arrows for velocity field plot"
xVel_norm = xVel_raw / np.sqrt(xVel_raw**2 + yVel_raw**2)
yVel_norm = yVel_raw / np.sqrt(xVel_raw**2 + yVel_raw**2)
xVac_norm = xVac_raw / np.sqrt(xVac_raw**2 + yVac_raw**2)
yVac_norm = yVac_raw / np.sqrt(xVac_raw**2 + yVac_raw**2)

"The mean velocity of the flow is the phaselocked velocity field minus the acoustically induced particle velocity"
# yVel = yVel - yVac
# xVel = xVel - xVac

"Plot something"
var = yVac
boundVar = 20

"Calculate the two-dimensional vorticity in the Z direction"
"To derivative along the Y axis, use axis = 0, i.e., derivative along the lines"
"To derivative along the X axis, use axis = 1, i.e., derivative along the columns"
zVor = np.gradient(yVel,X[0,:],axis=1) - np.gradient(xVel,Y[:,0],axis=0)
"Normalize the vorticity values"
zVor = zVor/4.5e5
boundVor = 1

if ac_source == 'up':
    x0 = (4.98e-3-d/2)*1e3
    x1 = (4.98e-3+d/2)*1e3
    x2 = (7.466e-3-d/2)*1e3
    x3 = (7.466e-3+d/2)*1e3
else:
    x0 = (136.906e-3-4.98e-3-d/2)*1e3
    x1 = (136.906e-3-4.98e-3+d/2)*1e3
    x2 = (136.906e-3-7.466e-3-d/2)*1e3
    x3 = (136.906e-3-7.466e-3+d/2)*1e3

"plot Variables"
r = 0.12*0.55

a1 = np.linspace(3/2*np.pi,2*np.pi,26)
a2 = np.linspace(0,np.pi/2,26)
a3 = np.linspace(np.pi/2,np.pi,26)
a4 = np.linspace(np.pi,3/2*np.pi,26)

x_a1 = r*np.cos(a1)
x_a2 = r*np.cos(a2)
x_a3 = r*np.cos(a3)
x_a4 = r*np.cos(a4)

y_a1 = r*np.sin(a1)
y_a2 = r*np.sin(a2)
y_a3 = r*np.sin(a3)
y_a4 = r*np.sin(a4)

#%%¯
"Plot vorticity"
step=10
line = 1
style='dashed'
fig, ax = plt.subplots(1, 1, figsize=(6/.833,2/.833))
plt.axis([np.min(X)*1e3, np.max(X)*1e3, np.min(Y)*1e3, np.max(Y)*1e3])
plt.pcolormesh(X*1e3,Y*1e3,zVor[:,:,0], cmap='bwr',vmin=-boundVor,vmax=boundVor,shading='gouraud')
cbar = plt.colorbar()
cbar.set_label('Normalized Vorticity')
if True == True:
    plt.plot([x0,x0],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x1,x1],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x2,x2],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x3,x3],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([np.min(X)*1e3,x0-r],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([np.min(X)*1e3,x0-r],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot([x1+r,x2-r],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([x1+r,x2-r],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot([x3+r,np.max(X)*1e3],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([x3+r,np.max(X)*1e3],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot(x0-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
    plt.plot(x0-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
    plt.plot(x1+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
    plt.plot(x1+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
    plt.plot(x2-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
    plt.plot(x2-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
    plt.plot(x3+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
    plt.plot(x3+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
# plt.quiver(x[::step]*1e3,y[::step]*1e3,xVel_norm[0,::step],yVel_norm[0,::step],width=1.5e-3)
plt.cla()

for t in range(len(time_vec)):
    plt.pcolormesh(X*1e3,Y*1e3,zVor[:,:,t], cmap='bwr',vmin=-boundVor,vmax=boundVor,shading='gouraud')
    if True == True:
        plt.plot([x0,x0],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x1],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x2,x2],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,x3],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([np.min(X)*1e3,x0],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([np.min(X)*1e3,x0],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x2],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x2],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,np.max(X)*1e3],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,np.max(X)*1e3],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot(x0-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
        plt.plot(x0-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
        plt.plot(x1+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
        plt.plot(x1+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
        plt.plot(x2-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
        plt.plot(x2-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
        plt.plot(x3+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
        plt.plot(x3+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
    # plt.quiver(x[::step]*1e3,y[::step]*1e3,xVel_norm[t,::step],yVel_norm[t,::step],width=1.5e-3)
    plt.xlabel('$x$ Coordinate, mm')
    plt.ylabel('$y$ Coordinate, mm')
    # plt.pause(1e-3)
    # plt.savefig(path_save+'vorticity/flow/png/last/fig{}.png'.format(t),dpi=300)

    
#%%"Plot Var"
step=10
line = 1
style='dashed'
fig, ax = plt.subplots(1, 1, figsize=(6/.833,2/.833))
plt.axis([np.min(X), np.max(X), np.min(Y), np.max(Y)])
plt.pcolormesh(X*1e3,Y*1e3,var[:,:,0], cmap='bwr',vmin=-boundVar,vmax=boundVar,shading='gouraud')
cbar = plt.colorbar()
cbar.set_label('Acoustic Particle\nVelocity, m/s')
if True == True:
    plt.plot([x0,x0],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x1,x1],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x2,x2],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([x3,x3],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
    plt.plot([np.min(X)*1e3,x0],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([np.min(X)*1e3,x0],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot([x1,x2],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([x1,x2],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot([x3,np.max(X)*1e3],[0,0],color='k',linewidth=line,linestyle=style)
    plt.plot([x3,np.max(X)*1e3],[0.55,0.55],color='k',linewidth=line,linestyle=style)
    plt.plot(x0-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
    plt.plot(x0-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
    plt.plot(x1+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
    plt.plot(x1+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
    plt.plot(x2-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
    plt.plot(x2-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
    plt.plot(x3+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
    plt.plot(x3+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
plt.quiver(x[::step]*1e3,y[::step]*1e3,xVac_norm[0,::step],yVac_norm[0,::step],width=1.5e-3)
plt.cla()

for t in range(len(time_vec)):
    plt.pcolormesh(X*1e3,Y*1e3,var[:,:,t], cmap='bwr',vmin=-boundVar,vmax=boundVar,shading='gouraud')
    if True == True:
        plt.plot([x0,x0],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x1],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x2,x2],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,x3],[0+r,0.55-r],color='k',linewidth=line,linestyle=style)
        plt.plot([np.min(X)*1e3,x0],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([np.min(X)*1e3,x0],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x2],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([x1,x2],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,np.max(X)*1e3],[0,0],color='k',linewidth=line,linestyle=style)
        plt.plot([x3,np.max(X)*1e3],[0.55,0.55],color='k',linewidth=line,linestyle=style)
        plt.plot(x0-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
        plt.plot(x0-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
        plt.plot(x1+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
        plt.plot(x1+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
        plt.plot(x2-r+x_a1,0+r+y_a1,color='k',linewidth=line,linestyle=style)
        plt.plot(x2-r+x_a2,0.55-r+y_a2,color='k',linewidth=line,linestyle=style)
        plt.plot(x3+r+x_a4,0+r+y_a4,color='k',linewidth=line,linestyle=style)
        plt.plot(x3+r+x_a3,0.55-r+y_a3,color='k',linewidth=line,linestyle=style)
    plt.quiver(x[::step]*1e3,y[::step]*1e3,xVac_norm[t,::step],yVac_norm[t,::step],width=1.5e-3)
    plt.xlabel('$x$ Coordinate, mm')
    plt.ylabel('$y$ Coordinate, mm')
    #plt.pause(1e-3)
    plt.savefig(path_save+'vorticity/png/fig_{}.svg'.format(t),dpi=300)
    plt.cla()    


"Howe's corollary https://doi.org/10.1121/10.0005133"
"Perform the cross product between [0,0,zVor] and [xVel,yVel,0]"
# FC = xProduct

#%%
import os
import re
import cv2

def natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]

# Define the folder where images are saved
import os
import cv2

# Funzione per ordinare naturalmente le immagini
def natural_sort_key(s):
    import re
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]


image_folder = path_save + 'vorticity/flow/png/'
image_folder_1 = path_save + 'vorticity/png/'

# Definisci il percorso completo e il nome per il video
video_name = path_save + 'vorticity/flow&acoustic.mp4'

# Ottieni l'elenco di tutte le immagini .png nella cartella e ordinale naturalmente
images = [img for img in os.listdir(image_folder) if img.endswith(".png")]
images.sort(key=natural_sort_key)

images_ac = [img for img in os.listdir(image_folder_1) if img.endswith(".png")]
images_ac.sort(key=natural_sort_key)

# Leggi le prime immagini per ottenere le dimensioni del frame
frame = cv2.imread(os.path.join(image_folder, images[0]))
frame_1 = cv2.imread(os.path.join(image_folder_1, images_ac[0]))

# Ottieni le dimensioni per creare un frame affiancato
height, width, layers = frame.shape
height_1, width_1, layers_1 = frame_1.shape

# Imposta il frame rate (es. 10 fps per un video più veloce)
fps = 10

# La larghezza del frame combinato è la somma delle larghezze dei due frame
combined_width = width + width_1

# Crea un oggetto VideoWriter
video = cv2.VideoWriter(video_name, cv2.VideoWriter_fourcc(*'mp4v'), fps, (combined_width, height))

# Loop attraverso tutte le immagini e scrivi i frame combinati nel video
for image, image_ac in zip(images, images_ac):
    # Leggi le immagini da entrambe le cartelle
    img = cv2.imread(os.path.join(image_folder, image))
    img_ac = cv2.imread(os.path.join(image_folder_1, image_ac))
    
    # Ridimensiona le immagini per avere la stessa altezza
    img_ac = cv2.resize(img_ac, (width_1, height))
    
    # Assicurati che entrambe le immagini abbiano lo stesso tipo
    if img.dtype != img_ac.dtype:
        raise ValueError("Le immagini non hanno lo stesso tipo")
    
    # Concatena le immagini orizzontalmente
    combined_img = cv2.hconcat([img, img_ac])
    
    # Scrivi l'immagine combinata nel video
    video.write(combined_img)

# Rilascia il video writer e distruggi tutte le finestre
video.release()
cv2.destroyAllWindows()
