#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 14 11:59:39 2024

@author: angelo
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import csd,welch
from matplotlib.ticker import LogLocator, NullFormatter
import math
import turtle
from scipy.signal import correlate
import statistics
from scipy.integrate import quad
from matplotlib.ticker import LogLocator, FormatStrFormatter
from matplotlib.colors import ListedColormap

# Dati del problema
Tc = 25
Pamb = 101325  # Pressione ambiente (Pa)
sutherland_tref = 273.15  # Temperatura di riferimento di Sutherland
Tk = Tc + sutherland_tref  # Temperatura (Kelvin)
gamma = 1.4  # Rapporto delle capacità termiche (aria secca)
Pr = 0.707  # Numero di Prandtl
Runiv = 8.314462  # Costante dei gas ideali [J/K.mol]
mol_weight = 28.9645 / 1000  # Peso molecolare dell'aria
R = Runiv / mol_weight  # Costante specifica dei gas
c0 = np.sqrt(gamma * R * Tk)  # Velocità del suono
rho = Pamb / (R * Tk)  # Densità
nu = (1.458e-6 * (Tk**1.5) / (110.4 + Tk)) / rho  # Viscosità

def mean(arr):
    return sum(arr) / len(arr)

def cross_correlation(x, y):
    """
    Compute the cross-correlation of two signals.
    
    Parameters:
    x (numpy array): First signal
    y (numpy array): Second signal
    
    Returns:
    numpy array: Cross-correlation of the two signals
    """
    n = len(x)
    mean_x = np.mean(x)
    mean_y = np.mean(y)
    std_x = np.std(x)
    std_y = np.std(y)
    
    # Compute cross-correlation
    result = np.correlate(x - mean_x, y - mean_y, mode='same')
    
    return result / (std_x * std_y * n)
def lawouterreynolds(y,H,utau,nu):
    y_plus = y*utau/nu
    reynolds_stresses_wall = 1.1-0.9*np.log(y/H)-6.06*(y_plus)**(-0.5)
    return reynolds_stresses_wall


# Carica i dati
path = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/time_history/'
path_points = '/home/angelo/Scrivania/PhD/aeroacustica/postprocessing/BDL_points/'
points = np.loadtxt(path_points + 'points_boundarylayer_before.txt', skiprows=1)
points = -points[:-1, 1]
data = np.loadtxt(path + 'bdl_after.txt', skiprows=0)
data_p2 = np.loadtxt(path + 'bdl_after_plane_2.txt', skiprows=0)
data_p3 = np.loadtxt(path + 'bdl_after_plane_3.txt', skiprows=0)
# data = (data + data_p2 + data_p3)/3
data_down = np.loadtxt(path +  'bdl_-0.05.txt', skiprows=0)
velocity_profiles_for_corr = data_down[:5329,1:-1]

# data_ac_up = np.loadtxt(path + '../../flow+acoustic/up/1400/bdl_before.txt', skiprows=0)
# velocity_profiles_ac_up = data_ac_up[:, 1:-1]
# data_ac_dw = np.loadtxt(path + '../../flow+acoustic/down/1400/bdl_before.txt', skiprows=0)
# velocity_profiles_ac_dw = data_ac_dw[:, 1:-1]

y_plus = (points[61:] * 4.12) / nu

# Supponiamo che la prima colonna sia il tempo e le restanti colonne siano i profili di velocità
time = data[:, 0]
velocity_profiles = data[:, 1:-1]
velocity_profiles_p2 = data_p2[:, 1:-1]
velocity_profiles_p3 = data_p3[:, 1:-1]

velocity_profiles_mean = velocity_profiles.mean(axis=0)

# Plot del profilo medio di velocità
plt.figure(figsize=(8, 6))
plt.plot(points, velocity_profiles_mean, 'b-', linewidth=2)
plt.xlabel('Points')
plt.ylabel('Mean Velocity Profiles')
plt.title('Mean Velocity Profiles vs Points')
plt.grid(True)
plt.show()

# Parametri di analisi spettrale
fs = 1 / (time[1] - time[0])  # Frequenza di campionamento
# nperseg = len(time)//6  # Numero di punti per segmento nella PSD

# Allungamento del segnale tramite zero-padding
pad_length = 5 * len(time)  # Doppia la lunghezza del segnale
num_repeats = 1  # Numero di ripetizioni del segnale
x_repeated = np.tile(velocity_profiles[:,1], num_repeats)
nperseg = 512# Calcolo della potenza spettrale
Pxx_matrix = np.zeros((y_plus.shape[0], nperseg//2))
Pxx_matrix_1 = np.zeros((velocity_profiles.shape[1], nperseg//2))
Pxx_matrix_2 = np.zeros((velocity_profiles.shape[1], nperseg//2))

frequencies = np.zeros((y_plus.shape[0], nperseg//2))
frequencies_1 = np.zeros((velocity_profiles.shape[1], nperseg//2))
frequencies_2 = np.zeros((velocity_profiles.shape[1], nperseg//2))

lambda_x = np.zeros((y_plus.shape[0], nperseg//2))
lambda_x_1 = np.zeros((velocity_profiles.shape[1], nperseg//2))
lambda_x_2 = np.zeros((velocity_profiles.shape[1], nperseg//2))

lambda_car = np.zeros((y_plus.shape[0], nperseg//2))
f_peak = np.zeros(nperseg//2)
rms = np.zeros((y_plus.shape[0]))
rms_noac = np.zeros((velocity_profiles.shape[1]))
rms_ac_up = np.zeros((velocity_profiles.shape[1]))
rms_ac_dw = np.zeros((velocity_profiles.shape[1]))
u_prime_squared_mean = np.zeros((y_plus.shape[0]))

std = np.zeros((446))
n = 5
dt = time[1]-time[0]
idx = 61
for i in range(len(y_plus)):
    # Calcolo dello spettro di potenza usando la funzione di Welch
    
    mean_velocity = np.mean(velocity_profiles[:, i + idx])
    mean_velocity_2 = np.mean(velocity_profiles_p2[:, i + idx])
    mean_velocity_3 = np.mean(velocity_profiles_p3[:, i + idx])

   # Sottrae la media dal profilo di velocità
    velocity_minus_mean = velocity_profiles[:, i + idx] - mean_velocity
    velocity_minus_mean_2 = velocity_profiles_p2[:, i + idx] - mean_velocity_2
    velocity_minus_mean_3 = velocity_profiles_p3[:, i + idx] - mean_velocity_3

    # plt.plot(velocity_profiles[:,70])
    # f1,Pxx1 = csd(velocity_profiles[:,70]-np.mean(velocity_profiles[:,70]),velocity_profiles[:,70]-np.mean(velocity_profiles[:,70]), fs=fs, nperseg=1024,scaling='spectrum')
    # fig, ax = plt.subplots(figsize=(10, 10))
    # ax.plot(f1,Pxx1, linewidth=3)
    
    # ax.legend(fontsize=25)
    # # ax.set_xlabel(r'$\lambda_{x}+$', fontsize=30)
    # # ax.set_ylabel('premultiplied spectra', fontsize=30)
    # plt.xscale('log')
    
   # Calcola la densità spettrale di potenza usando Welch
    f, Pxx = csd(velocity_minus_mean,velocity_minus_mean, fs=fs, nperseg=nperseg)
    f_2, Pxx_2 = csd(velocity_minus_mean_2,velocity_minus_mean_2, fs=fs, nperseg=nperseg)
    f_3, Pxx_3 = csd(velocity_minus_mean_3,velocity_minus_mean_3, fs=fs, nperseg=nperseg)

    Pxx = (Pxx + Pxx_2 + Pxx_3)/3
    # f_1,Pxx_1 = welch(velocity_profiles_ac_up[:,i] -np.mean(velocity_profiles_ac_up[:,i]), fs=fs,nperseg=nperseg,scaling='spectrum')
    # f_2,Pxx_2 = welch(velocity_profiles_ac_dw[:,i] -np.mean(velocity_profiles_ac_dw[:,i]), fs=fs,nperseg=nperseg,scaling='spectrum')
    
    u_prime_squared_mean[i] = np.trapz(np.abs(Pxx),f)

    
    # velocity_1 = velocity_profiles[:,i+idx]
    # velocity_2 = velocity_profiles_for_corr[:, i+idx]
    

    # # Calcola la cross-correlazione utilizzando SciPy
    # cross_corr = cross_correlation(velocity_1, velocity_2)

    # # # Calcola i lag
    # lags = np.arange(-len(velocity_1)//2, len(velocity_1)//2)*dt

    # # # Normalizza la cross-correlazione
    # cross_corr /= np.std(velocity_1) * np.std(velocity_2) * len(velocity_1)
    
    # idx_max = np.argmax(cross_corr)
    # t = -lags[idx_max]
    # v_conv = (-0.05+0.005)/t;
    # print("{}".format(v_conv))
   
    v_conv=np.mean(velocity_profiles[:,i]);
    # Escludiamo la frequenza zero per evitare divisioni per zero
    frequencies[i, :] = f[1:]
    lambda_x[i, :] = (v_conv / f[1:])
    if i+idx >= 152:
        lambda_x[i, :] = (13 / f[1:])
    
    Pxx_matrix[i, :] =  (np.abs(Pxx[1:])*(2*np.pi/lambda_x[i,:]))/(4.015)**2
    lambda_x[i, :] = lambda_x[i,:]*4.015/(nu)

    # frequencies_1[i, :] = f_1[1:]
    # lambda_x_1[i, :] = (np.mean(velocity_profiles_ac_up[:,i]) / f_1[1:])
    # Pxx_matrix_1[i, :] =  Pxx_1[1:]
    
    # frequencies_2[i, :] = f_2[1:]
    # lambda_x_2[i, :] = (np.mean(velocity_profiles_ac_dw[:,i]) / f_2[1:])
    # Pxx_matrix_2[i, :] =  Pxx_2[1:]
    
    # Calcolo dell'RMS
    rms[i] = statistics.stdev(velocity_profiles[:, i])
    
    # # Indice della frequenza di picco
    # idx = np.argmax(Pxx)
    # f_peak[i] = f[idx]

# Creazione del contour plot

idx = np.abs(y_plus-15).argmin()
fig, ax = plt.subplots(figsize=(10, 10))
ax.plot(lambda_x[idx,:],Pxx_matrix[idx,:], linewidth=3,label = 'flow only')
ax.plot(lambda_x_1[idx,:]*4.12/nu,Pxx_matrix_1[idx,:],linewidth=3, label = 'flow + acoustic up')
ax.plot(lambda_x_2[idx,:]*4.12/nu,Pxx_matrix_2[idx,:],linewidth=3, label='flow + acoustics down')
ax.legend(fontsize=25)
ax.set_xlabel(r'$\lambda_{x}+$', fontsize=30)
ax.set_ylabel('premultiplied spectra', fontsize=30)
plt.xscale('log')
plt.tick_params(axis='both', labelsize=35)
plt.savefig('/home/angelo/Scrivania/lambda_x_confronto.png', bbox_inches = 'tight', dpi=300)


for i in range(446):
        std[i] = np.std(velocity_profiles[:n,151])
        n = n + 5
        
n_tot = np.arange(5,n,5)       
fig, ax = plt.subplots(figsize=(10, 10))
ax.plot(n_tot, std, 'b-', linewidth=3)
ax.set_xlabel('n frames', fontsize=25)
ax.set_ylabel('std(u)', fontsize=25)
ax.legend(fontsize=25)
plt.tick_params(axis='both', labelsize=25)

ax.grid(True, which='both', linestyle='--', linewidth=0.5)
# plt.savefig('/home/angelo/Scrivania/std_convergence.png', bbox_inches = 'tight', dpi=300)

# Calcolo y+



# Plot del grafico di contorno
X, Y = np.meshgrid(y_plus, lambda_x[0, :])

levels = np.linspace(0,0.1, 100)

plt.figure(figsize=(10, 6))
# Usa la tua mappa di colori personalizzata
contour = plt.contourf(X, Y, Pxx_matrix.T, levels=levels, cmap='RdYlBu_r', vmin=0, vmax=0.1, extend='both')
# Aggiungi le linee di contorno di lambda_car
# contour_lines = plt.contour(Y, F, lambda_car, levels=levels, colors='black', linewidths=3)
# plt.clabel(contour_lines, inline=True, fontsize=10, fmt='%1.1f')  # Aggiungi le etichette alle linee di contorno
cbar = plt.colorbar(contour)
cbar.set_label(r'$k_{x} \Phi_{uu}/u_{\tau}^2 $', fontsize=30)
cbar.ax.tick_params(labelsize=10)
plt.ylabel('$\lambda_{x}^{+}$', fontsize=30)
plt.xlabel('y+', fontsize=30)
plt.tick_params(axis='both', labelsize = 30)
cbar.ax.yaxis.set_major_formatter(FormatStrFormatter('%.0e'))
cbar.ax.tick_params(labelsize=10)

# plt.axhline(14100, color='k', linewidth=3, linestyle='dashed')

# # Impostazione degli intervalli desiderati sulla colorbar
# ticks = np.linspace(0, 2, num=6)  # Esempio di 6 intervalli
# cbar.set_ticks(ticks)

# plt.title('Contour Plot of y+ vs Premultiplied Spectrum', fontsize=16)
plt.yscale('log')
plt.xscale('log')
cbar.ax.tick_params(labelsize=20)

plt.xlim(50, 8e3)
plt.ylim(2e02, 1e5)
# plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.savefig('/home/angelo/Scrivania/y_plus_lambdad_down_upstreamsample.png', bbox_inches = 'tight', dpi=300)
plt.show()


idx = np.abs(Y[1,:]-22.64).argmin()
f, Pxx = csd(velocity_profiles[:,idx],velocity_profiles[:,idx], fs=fs, nperseg=nperseg)
# f_1, Pxx_1 = csd(velocity_profiles[:,idx-5],velocity_profiles[:,idx-5], fs=fs, nperseg=nperseg')
# f_2, Pxx_2 = csd(velocity_profiles[:,idx-10],velocity_profiles[:,idx-10], fs=fs, nperseg=nperseg)
# f_3, Pxx_3 = csd(velocity_profiles[:,idx-20],velocity_profiles[:,idx-20], fs=fs, nperseg=nperseg)
# f_4, Pxx_4 = csd(velocity_profiles[:,idx-50],velocity_profiles[:,idx-50], fs=fs, nperseg=nperseg)
# f_5, Pxx_5 = csd(velocity_profiles[:,80],velocity_profiles[:,80], fs=fs, nperseg=nperseg)

f_r, Pxx_r = csd(velocity_profiles[:,70],velocity_profiles[:,70], fs=fs, nperseg=nperseg)

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(f, np.abs(Pxx), 'b-', linewidth=3, label='y+ =22.64')
ax.plot(f_r, np.abs(Pxx_r), 'k-', linewidth=3, label='y+ = 3e03')
# ax.plot(f_1, np.abs(Pxx_1), 'r-', linewidth=3, label='y+ = 1')
# ax.plot(f_2, np.abs(Pxx_2), 'g-', linewidth=3, label='y+ = 2')
# ax.plot(f_3, np.abs(Pxx_3), 'orange', linewidth=3, label='y+ = 3')
# ax.plot(f_4, np.abs(Pxx_4), 'orange', linewidth=3, label='y+ = 3')
# ax.plot(f_5, np.abs(Pxx_5), 'orange', linewidth=3, label='y+ = 3')

ax.legend(fontsize=30)
ax.set_yscale('log')
ax.set_xscale('log')
ax.set_xlabel('$Frequency [Hz]$', fontsize=30)
ax.set_ylabel( '$Amplitude$', fontsize=30)
plt.savefig('/home/angelo/Scrivania/spectra_confronto.png', bbox_inches = 'tight', dpi=300)

# Plot dello spettro
i = 70


f, Pxx = csd(velocity_profiles[:, i], velocity_profiles[:, i], fs=fs, nperseg=nperseg, scaling='spectrum')
f_peak_idx          = np.where(np.abs(f-2000)==np.min(np.abs(f-2000)))
f_peak_1              = f[f_peak_idx] 

data_down = np.loadtxt(path + 'bdl_middle.txt', skiprows=0)
velocity_profiles_down = data_down[:, 1:-1]

f_bef, Pxx_bef = csd(velocity_profiles[:,i] - np.mean(velocity_profiles[:,i]),velocity_profiles[:,i] - np.mean(velocity_profiles[:,i]), fs=fs, nperseg=len(velocity_profiles), scaling='spectrum')

fig, ax = plt.subplots(figsize=(8, 6))
ax.plot(f, np.abs(Pxx), 'b-', linewidth=3, label='upstream')
ax.plot(f_bef, np.abs(Pxx_bef), 'r-', linewidth=3, label='downstream')



# ax.plot(f[np.where(f>2000)], 50000*f[np.where(f>2000)]**(-5/3), 'r', linewidth=3, label=r'$f^{-5/3}$')

ax.set_yscale('log')
ax.set_xscale('log')
ax.set_xlabel('Frequency [Hz]', fontsize=30)
ax.set_ylabel( 'Amplitude', fontsize=30)
# ax.set_xlim(1e02,5e4)
ax.legend(fontsize=30)
ax.set_title('Spectrum with -5/3 Decay Slope', fontsize=16)
# plt.tick_params(axis='both', labelsize = 30)
ax.grid(True, which='both', linestyle='--', linewidth=0.5)
# plt.savefig('/home/angelo/Scrivania/spectra.png', bbox_inches = 'tight', dpi=300)
plt.show()
#%%


yplus = points*4.12/nu
plt.subplots(figsize=(8, 6))
plt.scatter(y_plus, rms**2/(4.12)**2, linewidth=2)
plt.ylabel('$ u_{rms}/u_{\tau}$', fontsize=35)
plt.xlabel('$y^{+}$',fontsize = 40)
plt.tick_params(axis='both', labelsize = 40)
plt.grid(alpha=0.5)
plt.xlim([5, 1300]) 
plt.ylim([1, 10]) 

plt.xscale('log')

path = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow_only/time_history/'
data_noac = np.loadtxt(path + '../../flow_only/time_history/bdl_before.txt', skiprows=0)

data_noac = np.loadtxt(path + '../../flow_only/time_history/bdl_before.txt', skiprows=0)
velocity_profiles_dw = data_noac[:, 1:-1]
data_ac_up = np.loadtxt(path + '../../flow+acoustic/up/1400/bdl_before.txt', skiprows=0)
velocity_profiles_ac_up = data_ac_up[:, 1:-1]
data_ac_dw = np.loadtxt(path + '../../flow+acoustic/down/1400/bdl_before.txt', skiprows=0)
velocity_profiles_ac_dw = data_ac_dw[:, 1:-1]

data_noac_dw = np.loadtxt(path + '../../flow_only/time_history/bdl_after.txt', skiprows=0)
velocity_profiles_dw = data_noac_dw[:, 1:-1]
data_ac_up_dw = np.loadtxt(path + '../../flow+acoustic/up/1400/bdl_after.txt', skiprows=0)
velocity_profiles_ac_up_dw = data_ac_up_dw[:, 1:-1]
data_ac_dw_dw = np.loadtxt(path + '../../flow+acoustic/down/1400/bdl_last.txt', skiprows=0)
velocity_profiles_ac_dw_dw = data_ac_dw_dw[:, 1:-1]


rms_noac_dw = np.zeros((velocity_profiles.shape[1]))
rms_ac_up_dw = np.zeros((velocity_profiles.shape[1]))
rms_ac_dw_dw = np.zeros((velocity_profiles.shape[1]))


for i in range(velocity_profiles.shape[1]):

    rms_noac [i] = (statistics.stdev(velocity_profiles[:,i]))
    rms_ac_up [i] = (statistics.stdev(velocity_profiles_ac_up[:,i]))
    rms_ac_dw [i] = (statistics.stdev(velocity_profiles_ac_dw[:,i]))
    
    rms_noac_dw [i] = (statistics.stdev(velocity_profiles_dw[:,i]))
    rms_ac_up_dw [i] = (statistics.stdev(velocity_profiles_ac_up_dw[:,i]))
    rms_ac_dw_dw [i] = (statistics.stdev(velocity_profiles_ac_dw_dw[:,i]))
    
fig, ax = plt.subplots(figsize=(8, 10))
reynolds_stresses_wall = lawouterreynolds(points, 0.02, 4.12, nu)
plt.scatter(points / 0.02, rms_noac**2 / (4.015)**2, linewidth=2, edgecolors='b',facecolors='b',label='up. flow only')
plt.scatter(points / 0.02, rms_ac_up**2 / (3.90)**2, linewidth=2,edgecolors='gray',facecolors='gray',label='up. flow+acoustics up')
plt.scatter(points / 0.02, rms_ac_dw**2 / (4.019)**2, linewidth=2, edgecolors='r',facecolors='r',label='up. flow+acoustics down')

plt.scatter(points / 0.02, rms_noac_dw**2 / (3.68)**2, linewidth=2, edgecolors='k',facecolors='k',label='down flow only')
plt.scatter(points / 0.02, rms_ac_up_dw**2 / (3.61)**2, linewidth=2,edgecolors='g',facecolors='g',label='down flow+acoustics up')
plt.scatter(points / 0.02, rms_ac_dw_dw**2 / (3.61)**2, linewidth=2, edgecolors='orange',facecolors='orange',label='down flow+acoustics down')
plt.plot(points[(points > 5e-04) & (points < 1e-02)] / 0.02, reynolds_stresses_wall[(points > 5e-04) & (points < 1e-02)], color='k', linewidth=3)
plt.ylabel('$u^{\prime 2}/u_{\\tau}$', fontsize=35)
plt.xlabel('$y/H$', fontsize=40)
plt.tick_params(axis='both', labelsize=40)
plt.grid(alpha=0.5)
plt.xlim([1e-03,1e0])
plt.ylim([0, 10])
# ax.legend(loc='best', fontsize=30)
plt.xscale('log')
plt.savefig('/home/angelo/Scrivania/fluctuation_outercoordinates.png', bbox_inches = 'tight', dpi=300)


fig, ax = plt.subplots(figsize=(8, 6))
velocity_1 = velocity_profiles[:, 60]
velocity_2 = velocity_profiles_down[:, 60]

# Calcola la cross-correlazione utilizzando SciPy
cross_corr = cross_correlation(velocity_1, velocity_2)

# Calcola i lag
lags = np.arange(-len(velocity_1)//2, len(velocity_1)//2)*2.37e-06

# Normalizza la cross-correlazione
cross_corr /= np.std(velocity_1) * np.std(velocity_2) * len(velocity_1)

# Plot della cross-correlazione
plt.plot(lags, cross_corr)
plt.title('Cross-Correlation between Velocity Point 1 and Point 2')
plt.xlabel('Lag')
plt.ylabel('Cross-Correlation')
plt.grid(True)
plt.show()