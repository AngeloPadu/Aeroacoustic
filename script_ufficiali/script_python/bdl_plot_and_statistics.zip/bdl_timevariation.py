import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import re

def extract_number(filename):
    match = re.search(r'(\d+)', filename)
    return int(match.group(1)) if match else float('inf')


def save_data_to_txt(filename, data):
    with open(filename, 'a') as file:
        for line in data:
            file.write('\t'.join(map(str, line)) + '\n')

def plot_upstream_downstream(upstream_path, downstream_path):
    upstream_files = os.listdir(upstream_path)
    downstream_files = os.listdir(downstream_path)
    
    upstream_files.sort(key=extract_number)
    print("upstream_file {}")
    downstream_files.sort(key=extract_number)
    
    all_data_up = []
    all_data_dw = []
    
    for upstream_file, downstream_file in zip(upstream_files, downstream_files):
        upstream_filepath = os.path.join(upstream_path, upstream_file)
        downstream_filepath = os.path.join(downstream_path, downstream_file)
        
        upstream_df = np.asarray(pd.read_csv(upstream_filepath))
        downstream_df = np.asarray(pd.read_csv(downstream_filepath))
        
        # plt.plot(upstream_df[:,0]*-1, upstream_df[:,1], label='Upstream')
        # plt.plot(downstream_df[:,0]*-1, downstream_df[:,1], label='Downstream')
        
        # plt.xlabel('y')
        # plt.ylabel('U')
        # plt.legend()
        # plt.title('Plot di Upstream e Downstream sovrapposti')
        # plt.show()
        
        # Imposta i limiti degli assi x e y
        plt.xlim([-0.005, 0.03])  # Imposta i limiti dell'asse x
        
        u = upstream_df[:,1]
        y = upstream_df[:,0]*-1
        u_dw = downstream_df[:,1]
        y = np.flip(y)
        u = np.flip(u)
        idx_max_velocita = np.argmax(u)
    
        u_99_percento = 0.99 * u[idx_max_velocita]
        idx_u_99_percento = np.abs(u[:idx_max_velocita] - u_99_percento).argmin()
    
        delta = np.abs(y[idx_u_99_percento])
        # delta = np.interp(u_99_percento, [u[idx_u_99_percento-1],u[idx_u_99_percento]], [y[idx_u_99_percento-1],y[idx_u_99_percento]])

        delt1 = 0
        delt2 = 0
    
        idx_lim_num = np.where(y >= 0.02)[0][-1]
    
        delt1 = np.abs(np.trapz(1-(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento])), y[:idx_u_99_percento]))
        delt2 = np.abs(np.trapz(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento])*(1-(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento]))), y[:idx_u_99_percento]))
    
        all_data_up.append([delta, delt1, delt2])

        u_dw = downstream_df[:,1]
        y_dw = downstream_df[:,0]*-1
      
        y_dw = np.flip(y_dw)
        u_dw = np.flip(u_dw)
        idx_max_velocita = np.argmax(u_dw)
    
        u_99_percento = 0.99 * u[idx_max_velocita]
        idx_u_99_percento = np.abs(u[:idx_max_velocita] - u_99_percento).argmin()
    
        delta = np.abs(y[idx_u_99_percento])
        # delta = np.interp(u_99_percento, [u[idx_u_99_percento-1],u[idx_u_99_percento]], [y[idx_u_99_percento-1],y[idx_u_99_percento]])

        delt1 = 0
        delt2 = 0
    
        idx_lim_num = np.where(y >= 0.02)[0][-1]
    
        delt1 = np.abs(np.trapz(1-(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento])), y[:idx_u_99_percento]))
        delt2 = np.abs(np.trapz(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento])*(1-(u[:idx_u_99_percento]/np.max(u[:idx_u_99_percento]))), y[:idx_u_99_percento]))
    
        all_data_dw.append([delta, delt1, delt2])
        
    save_data_to_txt('output_up.txt', all_data_up)
    save_data_to_txt('output_dw.txt', all_data_dw)
        
    # Plot dei valori
    all_data_dw = np.array(all_data_dw)
    all_data_up = np.array(all_data_up)
    # Applica un filtro media mobile
    window_size = 5
    all_data_dw_smoothed = np.zeros_like(all_data_dw)
    all_data_up_smoothed = np.zeros_like(all_data_up)
    for i in range(3):
        all_data_dw_smoothed[:, i] = np.convolve(all_data_dw[:, i], np.ones(window_size)/window_size, mode='same')
        all_data_up_smoothed[:, i] = np.convolve(all_data_up[:, i], np.ones(window_size)/window_size, mode='same')

    # plt.plot(all_data_dw_smoothed[:, 1], label='Delt1', linestyle='-', marker='o', color='b')
    # plt.plot(all_data_dw_smoothed[:, 2], label='Delt2', linestyle='-', marker='o', color='r')
    # plt.xlabel('Iterazione')
    # plt.ylabel('Valore')
    # plt.legend()
    # plt.title('Valori di delt1 e delt2 per Downstream (Filtro Media Mobile)')
    # plt.show()
    return(all_data_up_smoothed,all_data_dw_smoothed)
upstream_path = "/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow+acoustic/up/1400/before_6_cavity/"
downstream_path = "/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/flow_profile/real_geometry/40vx/flow+acoustic/up/1400/after_6_cavity/"

[data_up,data_down] = plot_upstream_downstream(upstream_path, downstream_path)

#%%

all_data_up = np.array(data_up)
all_data_dw = np.array(data_down)
time = np.arange(0,1,1/len(all_data_dw[:,1]))
plt.plot(time,all_data_up[:, 1], label='before orifice', linestyle='-', marker='o', color='b')
plt.plot(time,all_data_dw[:, 1], label='after orifice', linestyle='-', marker='o', color='r')
plt.xlabel('t/T', fontsize=20)  # Imposta la dimensione del testo sull'asse x
plt.ylabel('$\delta^*$', fontsize=20)  # Imposta la dimensione del testo sull'asse y
plt.legend(fontsize=25)

plt.xlim([0.01, 0.98])
# plt.ylim([1.2, 1.8])
plt.tick_params(axis='both', which='major', labelsize=20)  # Imposta la dimensione dei ticks sugli assi
plt.savefig(upstream_path + '../delta.png')
plt.show()

# Secondo grafico: theta per Downstream
all_data_up = np.array(data_up)
all_data_dw = np.array(data_down)
plt.plot(time,all_data_up[:, 2], label='before orifice', linestyle='-', marker='o', color='b')
plt.plot(time,all_data_dw[:, 2], label='after orifice', linestyle='-', marker='o', color='r')
plt.xlabel('t/T', fontsize=14)  # Imposta la dimensione del testo sull'asse x
plt.ylabel(r'$\theta$', fontsize=20)  # Imposta la dimensione del testo sull'asse y
plt.legend(fontsize=25)

plt.xlim([0.01, 0.98])
# plt.ylim([1.15, 1.6])
plt.tick_params(axis='both', which='major', labelsize=20)  # Imposta la dimensione dei ticks sugli assi
plt.savefig(upstream_path + '../theta.png')
plt.show()

#%%
# pressure = np.asarray(pd.read_csv("/media/angelo/scanned_geom/Simulations/145/scanned_geom/flow/40vx/1400/pressure.csv"))[:-1,1]
# pressure = pressure - np.mean(pressure)
# time = np.arange(0,1,1/len(pressure))

# i = 0

# indx = pressure <= 1e08

# pressure = pressure[indx]
# time = time[indx]

# plt.scatter(time,pressure)