#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 27 15:38:48 2024

@author: angelo
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  4 10:07:43 2023

@author: angelo paduano
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

# Impostazioni globali per Matplotlib
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100

# Variabili comuni
d = 0.9906e-3
xticks = ["-$d$/2", "0", "$d$/2"]
save = 1
frequencies = [1400]
source = 'up'
decomposition = 'acoustic'
resolution = 'fine'
SPL = '145'
Vlim = 30


nFreq           = len(frequencies)
      
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Liner parameters - NASA"
POA                 = 6.3/100                                                  # Percentage of Open Area
cvt_height          = 38.1e-3                                                # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                 # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                # Orifice diameter (m)
orifice_d_ufsc      = 1.169250e-3                                             # Orifice diameter new (m)
nm_orifice          = 8
n_cavities          = 11
cvt_width_m         = 12.446e-3
edge                = 'sharp'
"Flow parameters"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Fluid parameters"
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4            

u_tau               = 4.3

analysis            ='up_vs_dw'

def acousticvelocitytheory(base_path, diameter, rho, c, frequency, sheet_tickness, cvt_height, cvt_width_m):
    folder_path = os.path.join(base_path, str(frequency))
    pressure = np.array(pd.read_csv(os.path.join(folder_path,'first_pressure.csv')))[:,1]
   
    # Rimuovi l'asterisco
    pressure = pressure[:-1]

    # Converti le stringhe in numeri float
    pressure = pressure.astype(float)
    r = d/2
    omega = 2*np.pi*frequency
    Q = 10
    V = cvt_width_m**2*cvt_height
    l = sheet_tickness*0.8*np.sqrt(np.pi*r**2/np.pi)
    omega_h = c*np.sqrt((np.pi*r**2)/l*V)
    
    A = (pressure)/(rho*omega*(sheet_tickness+0.8*diameter))
    B = 1/(np.sqrt(((omega_h/omega)**2-1)**2+(omega_h/omega*Q)))
    
    v_ac = A*B
    

    v_inf = np.max(v_ac)
    v_out = np.abs(np.min(v_ac))
   
    
    return v_inf,v_out



# Funzione per ottenere i profili
def get_profiles(base_path, cvt, pos,flag, norifice,up_vs_down):
    profiles = []
    if up_vs_down == 1:
        for frequency in frequencies:
            folder_path = os.path.join(base_path, str(frequency))
            fcavity = os.path.join(folder_path,'{} {} cavity/{} orifice/'.format(decomposition,cvt,norifice))

            element_list = os.listdir(fcavity)

            numbers_element = np.zeros(np.shape(element_list))

            v_max, v_min = float('-inf'), float('inf')
            n_max, n_min = None, None

            for i in range(5,len(numbers_element) - 1):
                velocity_1 = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, i)), header=0))[:, 1]
                
                if i == 0:
                    n_max = i
                    n_min = i
                    v_max = np.max(velocity_1)
                    v_min = np.min(velocity_1)
                if np.max(velocity_1) > v_max:
                    v_max = np.max(velocity_1)
                    n_max = i
                if np.min(velocity_1) < v_min:
                    v_min = np.min(velocity_1)
                    n_min = i
                
                 
            if flag == 1:
               
                n_max = n_max
                n_min = n_min 
                
            prof_in = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_max)), header=0))[:, :2]
            pos = prof_in[0,0];  
            prof_in[:, 0] = prof_in[:, 0] - pos
            
            print(pos)
            prof_out = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_min)), header=0))[:, :2]
            pos = prof_out[0,0];
            prof_out[:, 0] = prof_out[:, 0] - pos
            print(pos)
            print(n_max,n_min)
            profiles.append((prof_in, prof_out))
    else:
    
        for frequency in frequencies:
            
            print('first orifice')
            
            folder_path = os.path.join(base_path, str(frequency))
            fcavity = os.path.join(folder_path,'{} {} cavity/first orifice/'.format(decomposition,cvt,norifice))
    
            element_list = os.listdir(fcavity)
    
            numbers_element = np.zeros(np.shape(element_list))
    
            v_max, v_min = float('-inf'), float('inf')
            n_max, n_min = None, None
    
            for i in range(0,len(numbers_element) - 1):
                velocity_1 = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, i)), header=0))[:, 1]
                # plt.plot(velocity_1)
                if i == 0:
                    n_max = i
                    n_min = i
                    v_max = np.max(velocity_1)
                    v_min = np.min(velocity_1)
                if np.max(velocity_1) > v_max:
                    v_max = np.max(velocity_1)
                    n_max = i
                if np.min(velocity_1) < v_min:
                    v_min = np.min(velocity_1)
                    n_min = i
                
            
            if flag == 1:
                n_max = n_max
                n_min = n_min 
            prof_in = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_max)), header=0))[:, :2]     
            prof_out = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_min)), header=0))[:, :2]
            
            print(n_max,n_min,v_max,v_min)
            
            
            
            
            fcavity = os.path.join(folder_path,'{} {} cavity/second orifice/'.format(decomposition,cvt))
    
            element_list = os.listdir(fcavity)
            
            
            
            numbers_element = np.zeros(np.shape(element_list))
            
            

            
            v_max_2, v_min_2 = float('-inf'), float('inf')
            n_max_2, n_min_2 = None, None
            
            i=0
            
            for i in range(0,len(numbers_element) - 1):
                
                velocity_2 = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, i)), header=0))[:, 1]
                
                if i == 0:
                    n_max_2 = i
                    n_min_2 = i
                    v_max_2 = np.max(velocity_2)
                    v_min_2 = np.min(velocity_2)
                if np.max(velocity_2) > v_max_2:
                    v_max_2 = np.max(velocity_2)
                    n_max_2 = i
                if np.min(velocity_2) < v_min_2:
                    v_min_2 = np.min(velocity_2)
                    n_min_2 = i
            
            if flag == 1:
                n_max_2 = n_max_2 +4
                n_min_2 = n_min_2 
            
            
            prof_in_2 = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_max_2)), header=0))[:, :2]
    
            pos = prof_in[0,0];  
            prof_in[:, 0] = prof_in[:, 0] - pos
            
            pos = prof_in_2[0,0];  
            
            print(pos)
            prof_in_2[:,0] = prof_in_2[:,0] - pos 
            
           
            prof_out_2 = np.asarray(pd.read_csv(os.path.join(fcavity, '{}{}.csv'.format(cvt, n_min_2)), header=0))[:, :2]
            pos = prof_out[0,0];
            prof_out[:, 0] = prof_out[:, 0] - pos
            pos = prof_out_2[0,0];
    
            prof_out_2[:, 0] = prof_out_2[:, 0] - pos
    
            print(pos)
            
            print(n_max_2,n_min_2,v_max_2,v_min)
            profiles.append((prof_in,prof_in_2,prof_out,prof_out_2))
        
    return profiles

legend_labels = {
    #'solid': 'M = 0',
    
    'solid': 'upstream',
    'dashed': 'downstream',
}


# Plot
if source == 'up':
    cvt = 'first'
else:
    cvt = 'last'

if cvt == 'first':
    pos = 4.985e-3
else:
    pos = 132.0e-3

fig, ax = plt.subplots(1, 1, figsize=(10.5, 10.5))
ax.axhline(0, linestyle='solid', color='k', linewidth=0.5)
ax.axvline(-d / 2, linestyle='solid', color='k', linewidth=0.5)
ax.axvline(d / 2, linestyle='solid', color='k', linewidth=0.5)

color = ['r', 'b', 'k']

path = '/home/angelo/Scrivania/'


if analysis == 'up_vs_dw':
    profiles=get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/145/', 'first', pos, 0, 'first', 1)
    
    
    for k, profile in enumerate(profiles):
        v_inf = max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
        
        ax.plot(profile[0][:, 0]/orifice_d_ufsc, profile[0][:, 1]/u_tau, linestyle='solid', color='r', linewidth=4,label='upstream')
        ax.plot(profile[1][:, 0]/orifice_d_ufsc, profile[1][:, 1]/u_tau, linestyle='solid', color='b', linewidth=4)
    
    pos = 132.0e-3
    
    profiles = get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/down/real_geometry/fine/145/', 'last', pos, 1, 'first',1)
    
    
    
    for profile in profiles:
        v_inf = np.max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
    
        ax.plot(profile[0][:, 0]/orifice_d_ufsc, (profile[0][:, 1])/u_tau, linestyle='dashed', color='r', linewidth=4,label='downstream')
        ax.plot(profile[1][:, 0]/orifice_d_ufsc, (profile[1][:, 1])/u_tau, linestyle='dashed', color='b', linewidth=4)
    
        
    # custom_legend = []
    
    # for linestyle, label in legend_labels.items():
    #     # Aggiungi una linea vuota con lo stile di linea specificato e l'etichetta personalizzata
    #     custom_legend.append(plt.Line2D([], [], linestyle=linestyle, color='gray', linewidth=4, label=label))
    
    # custom_legend.append(plt.Line2D([],[],linestyle='solid',color='b',linewidth=4,label = 'Outflow'))
    # custom_legend.append(plt.Line2D([],[],linestyle='solid',color='r',linewidth=4,label = 'Inflow'))

    # Aggiungi la legenda al grafico
    # ax.legend(handles=custom_legend, loc='best',fontsize = 30)
    # ax.legend(fontsize=30)
    ax.set_xlabel("Orifice Diameter",fontsize=40)
    ax.set_ylabel(r"$\bar{\bar{v}}/u_{\tau}$", fontsize=40)
    ax.set_xticks([0,0.5,1], xticks)
    ax.set_ylim(-20,20)
    # ax.set_xlim(-1.2e-3/2,1.2e-3/2)
    ax.tick_params(axis='both', labelsize = 40)
    ax.grid(alpha=0.5)
    
    # plt.savefig(path + '{}_velocity_{}_up_vs_dw_145.png'.format(decomposition,frequencies[k]), bbox_inches = 'tight', dpi=300)
    

else:
    print('SPL=145dB')
    profiles = get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/145/', cvt, pos, 0, 'first',0)
    #v_inf,v_out = acousticvelocitytheory('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/sharped/fine/145/',d, rho, c0, frequencies[0], fsheet_thick, cvt_height, cvt_width_m)
    
    
    for k, profile in enumerate(profiles):
        v_inf = max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
        
        ax.plot(profile[0][:, 0]/orifice_d_ufsc, profile[0][:, 1]/u_tau, linestyle='solid', color='r', linewidth=4)
        ax.plot(profile[1][:, 0]/orifice_d_ufsc, profile[1][:, 1]/u_tau, linestyle='dashed', color='r', linewidth=4)
    
    print('SPL=130dB')
    profiles = get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/130/', cvt, pos, 1, 'first',0)
    
    for k, profile in enumerate(profiles):
        v_inf = max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
        
        ax.plot(profile[0][:, 0]/orifice_d_ufsc, profile[0][:, 1]/u_tau, linestyle='solid', color='g', linewidth=4)
        ax.plot(profile[1][:, 0]/orifice_d_ufsc, profile[1][:, 1]/u_tau, linestyle='dashed', color='g', linewidth=4)
    
    ax.set_xlabel("Orifice Diameter",fontsize=40)
    ax.set_ylabel(r"$\bar{\bar{v}}/u_{\tau}$", fontsize=40)
    ax.set_xticks([0,0.5,1], xticks)
    ax.set_ylim(-10,15)
    #ax.set_xlim(-1.2e-3/2,1.2e-3/2)
    ax.tick_params(axis='both', labelsize = 40)
    ax.grid(alpha=0.5)
    
    path ='/home/angelo/Scrivania/'
    # plt.savefig(path + '{}_velocity_{}_inflow.png'.format(decomposition,frequencies[k]), bbox_inches = 'tight', dpi=300)
    
    
    
    fig, ax = plt.subplots(1, 1, figsize=(10.5, 10.5))
    ax.axhline(0, linestyle='solid', color='k', linewidth=0.5)
    ax.axvline(-d / 2, linestyle='solid', color='k', linewidth=0.5)
    ax.axvline(d / 2, linestyle='solid', color='k', linewidth=0.5)
    
    color = ['r', 'b', 'k']
    
    
    u_tau = 4.3
    
    profiles = get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/145/', cvt, pos, 0, 'first',0)
    
    
    for k, profile in enumerate(profiles):
        v_inf = max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
        
        ax.plot(profile[2][:, 0]/orifice_d_ufsc, profile[2][:, 1]/u_tau, linestyle='solid', color='r', linewidth=4)
        ax.plot(profile[3][:, 0]/orifice_d_ufsc, profile[3][:, 1]/u_tau, linestyle='dashed', color='r', linewidth=4)
    
    profiles = get_profiles('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/130/', cvt, pos, 1, 'first',0)
    
    for k, profile in enumerate(profiles):
        v_inf = max(profile[0][:,1])
        v_out = max(np.abs(profile[1][:,1]))
        
        ax.plot(profile[2][:, 0]/orifice_d_ufsc, profile[2][:, 1]/u_tau, linestyle='solid', color='g', linewidth=4)
        ax.plot(profile[3][:, 0]/orifice_d_ufsc, profile[3][:, 1]/u_tau, linestyle='dashed', color='g', linewidth=4)
    
    
    # Crea la legenda personalizzata
    custom_legend = []
    
    for linestyle, label in legend_labels.items():
        # Aggiungi una linea vuota con lo stile di linea specificato e l'etichetta personalizzata
        custom_legend.append(plt.Line2D([], [], linestyle=linestyle, color='gray', linewidth=4, label=label))
    
    custom_legend.append(plt.Line2D([],[],linestyle='solid',color='r',linewidth=4,label = 'SPL = 145dB'))
    custom_legend.append(plt.Line2D([],[],linestyle='solid',color='g',linewidth=4,label = 'SPL = 130 dB'))
    
    # Aggiungi la legenda al grafico
    # ax.legend(handles=custom_legend, loc='best',fontsize = 30)
    
    ax.set_xlabel("Orifice Diameter",fontsize=40)
    ax.set_ylabel(r"$\bar{\bar{v}}/u_{\tau}$", fontsize=40)
    ax.set_xticks([0,0.5,1], xticks)
    ax.set_ylim(-15,10)
    #ax.set_xlim(-1.2e-3/2,1.2e-3/2)
    ax.tick_params(axis='both', labelsize = 40)
    ax.grid(alpha=0.5)
    
    
    path ='/home/angelo/Scrivania/'
    # plt.savefig(path + '{}_velocity_{}_outflow.png'.format(decomposition,frequencies[k]), bbox_inches = 'tight', dpi=300)
