#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 15:38:01 2024

@author: angelo
"""
"Import python packages"
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import math
import h5py
from scipy.signal import csd
from datetime import datetime
import pandas as pd
import matplotlib.ticker as ticker
import csv
import os
from matplotlib.ticker import FormatStrFormatter

now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Times New Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'up'
SPL                 = 145
Mach                = 0.3
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'

nFreq           = len(frequencies)
      
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Liner parameters - NASA"
POA                 = 6.3/100                                                  # Percentage of Open Area
cvt_height          = 38.1e-3                                                # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                 # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                # Orifice diameter (m)
nm_orifice          = 8
n_cavities          = 11
cvt_width_m         = 12.446e-3


"Liner parameters - UFSC"
n_cavities_ufsc              = 11                                                        # Number of liner cavities
POA_ufsc                     = 8.75/100                                                   # Percentage of Open Area
cvt_height_ufsc              = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick_ufsc            = 0.55e-3                                                  # Face Sheet thickness (m)
orifice_d_ufsc               = 1.169250e-3                                              # Orifice diameter (m)
orifice_d_min                = 1.05e-3
orifice_d_max                = 1.26e-3                                                 
linerLength_ufsc             = 136.906e-3 


"Flow parameters"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    MeanMach = 0
    BLDT = 0
    
"Fluid parameters"
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                                                   # Variable to plots


######################PATH Definition########################
path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/in_situ'.format(ac_source,geometry,resolution,SPL,frequencies[0])

path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/'

if not os.path.exists(path + '_results'):
    # Se non esiste, creala
    os.makedirs(path + '_results')
    
else:
    print(f'La cartella esiste già in: {path}')

    
path_save = '/home/angelo/Scrivania/PhD/aeroacustica/Figure_paper_AIAA/'
# path_save = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/in_situ_results/'.format(ac_source,geometry,resolution,SPL,frequencies[0])
# =============================================================================
# BEGIN CODE
# =============================================================================

def round_decimals_up(number:float, decimals:int=2):
    """
    Returns a value rounded up to a specific number of decimal places.
    """
    if not isinstance(decimals, int):
        raise TypeError("decimal places must be an integer")
    elif decimals < 0:
        raise ValueError("decimal places has to be 0 or more")
    elif decimals == 0:
        return math.ceil(number)

    factor = 10 ** decimals
    return math.ceil(number * factor) / factor



def impedanceUTAS(rho, nu, c, POA, L, t, d, SPL, freq, M, BLthick):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
    Sm = -0.0000207*k/POA**2
    Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
    Ks = np.sqrt(-1j*omega/nu)
    F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
    Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
    Rcm = M/(POA*(2 + 1.256*BLthick/d))
    Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
    
    Ra = 1;
    Xa = 1;
    Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
    
    fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
    Vp = sp.optimize.fsolve(fun,Vp0)
    Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
    
    Ra = np.real(Z)
    Xa = np.imag(Z)
    return Ra, Xa



def impedanceCrandall(rho, nu, c, POA, L, t, d, SPL, freq,alpha):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    ks = np.sqrt((omega*rho)/nu)
    
    Z = (8 * nu * t) / (rho * c * POA * r**2) * (np.sqrt(1 + ((ks * r)**2) / 32) + (alpha * np.sqrt(2) * ks * r**2) / (2 * t)) + 1j * ((omega * t) / (c * POA) * (1 + (9 + (ks * r)**2 / 2)**(-0.5) + 2 * (8 * r) / (3 * np.pi * t)) - 1 / np.tan(k * L))
    
    Rc = np.real(Z)
    Xc = np.imag(Z)
    return Rc, Xc



media_resistance_list = []
media_reactance_list = []
deviazione_std_resistance_list = []
deviazione_std_reactance_list = []
meanRealZ_UTAS_list = []
meanimageZ_UTAS_list = []


#%%
if Mach == 0.32 or Mach == 0.3:
    fig, ax = plt.subplots(1, 1, figsize=(20,5))
    
    if Mach == 0.3 or Mach == 0:
        #if ac_source == 'up':
            ufsc_exp_realZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
            ufsc_exp_imagZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
            ufsc_exp_realZ_up_145      = ufsc_exp_realZ_up_145.mean(axis=1)
            ufsc_exp_imagZ_up_145      = ufsc_exp_imagZ_up_145.mean(axis=1)
            
            
            kt_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
            kt_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
            
            mm_ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
            mm_ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
            
            
            ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7:9]
            ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,17:19]
            ufsc_exp_realZ_dw      = ufsc_exp_realZ_dw.mean(axis=1)
            ufsc_exp_imagZ_dw      = ufsc_exp_imagZ_dw.mean(axis=1)
    
    if Mach == 0.32:
        #if ac_source == 'up':
            
            path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/in_situ-before_and_after_holes/'
            ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(Mach,SPL),header=0,sep=';'))[:,1]
            ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(Mach,SPL),header=0,sep=';'))[:,5]
            ufsc_exp_realZ_up      = ufsc_exp_realZ_up.mean(axis=1)
            ufsc_exp_imagZ_up      = ufsc_exp_imagZ_up.mean(axis=1)
            
            kt_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
            kt_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
            
            mm_ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
            mm_ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
            
            ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,3]
            ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7]
            ufsc_exp_realZ_dw      = ufsc_exp_realZ_dw.mean(axis=1)
            ufsc_exp_imagZ_dw      = ufsc_exp_imagZ_dw.mean(axis=1)    
    
    
    
    SPL = 130 
    
    if Mach == 0.3 or Mach == 0:
        #if ac_source == 'up':
            ufsc_exp_realZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
            ufsc_exp_imagZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
            ufsc_exp_realZ_up_130      = ufsc_exp_realZ_up_130.mean(axis=1)
            ufsc_exp_imagZ_up_130      = ufsc_exp_imagZ_up_130.mean(axis=1)
            
            ufsc_exp_realZ_dw_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7:9]
            ufsc_exp_imagZ_dw_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,17:19]
            ufsc_exp_realZ_dw_130      = ufsc_exp_realZ_dw_130.mean(axis=1)
            ufsc_exp_imagZ_dw_130      = ufsc_exp_imagZ_dw_130.mean(axis=1)
            
    freqs_UTAS = np.arange(500,3000,100)
    realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
    imagZ_UTAS_ufsc = np.copy(realZ_UTAS_ufsc)   
    realZ_UTAS_ufsc_130 = np.zeros(len(freqs_UTAS))
    imagZ_UTAS_ufsc_130 = np.copy(realZ_UTAS_ufsc)            
    
    
    for i in np.arange(len(realZ_UTAS_ufsc)):
        realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,145,freqs_UTAS[i],MeanMach,BLDT)
        realZ_UTAS_ufsc_130[i], imagZ_UTAS_ufsc_130[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,130,freqs_UTAS[i],MeanMach,BLDT)
        
    
    
###145 Results#########    
    kt_real_fine = np.array([0.99-1.06j,1.29-0.47j,1.05+0.36j])       
            
    mm_real     = np.array([1.73-2.53j,1.31-0.68j,1.05+0.31j])
       
    insitu_fine_145 = np.array([0.49-1.35j,0.46-0.37j,0.4+0.22j])
    
    
    resistance_fine_145_max = np.array([1.42,1.33,1.33])
    
    resistance_fine_145_min = np.array([0.46,0.42,0.38])
    
    reactance_fine_145_max = np.array([-1.26,-0.26,0.40])
    
    reactance_fine_145_min = np.array([-1.61,-0.67,-0.15])
    
    pierce_145 = np.asarray([2.62-3.59j,1.56-0.91j,1.346+0.261j])
   
    pierce_145_blending_05 = np.asarray([2.16-3.47j,1.43-1.04j,1.39+0.25j])
 
    pierce_145_blending_1 = np.asarray([2.62-3.58j,1.32-1.12j,1.47+0.20j])
    
    pierce_costant_flow = np.asarray([0.96-2.42j,1.48-0.54j,1.30+0.08j])
 
    pierce_145_dw = np.asarray([2.20-3.53j,1.96-0.54j,1.05+0.19j])
    
    pierce_145_dw_const = np.asarray([0.28-1.97j,1.25-0.05j,0.96+0.21j])

    
    resistance_145_std = np.array([0.28,0.26,0.23])
    
    reactance_145_std = np.array([0.11143,0.1722,0.2418])
    
    insitu_fine_145_dw = np.array([1.38-1.33j,1.30-0.36j,1.12+0.21j])
    
    
    resistance_fine_145_max_dw = np.array([1.57,1.51,1.33])
    
    resistance_fine_145_min_dw = np.array([0.36,0.40,0.38])
    
    reactance_fine_145_max_dw = np.array([-1.34,-0.20,0.40])
    
    reactance_fine_145_min_dw = np.array([-1.59,-0.67,0.15])
    
    resistance_145_std_dw = np.array([0.42,0.38,0.28])
    
    reactance_145_std_dw = np.array([0.006,0.120,0.14])
    
######results 130 dB#################    
    insitu_fine_130 = np.array([0.46-1.41j,0.52-0.39j,0.4+0.17j])
    
    resistance_130_std = np.array([0.29,0.21,0.20])
    
    reactance_130_std = np.array([0.191,0.2012,0.2312])
    
    resistance_fine_130_max_min_0 = np.array([0.09,0.12,0.02,0.17,0.04,0.1])
    
    reactance_fine_130_max_min_0 = np.array([-1.41,-1.32,-0.38,-0.23,-0.20,0.37])
    
    resistance_fine_130_max = np.array([0.48,1.48,0.58,1.37,0.35,1.25])
    
    reactance_fine_max_min = np.array([-1.61,-1.31,-0.71,-0.25,-0.20,0.37])
    
    insitu_fine_130_dw = np.array([1.31-1.22j,1.37-0.43j,1.12+0.21j])
    
    resistance_fine_130_max_dw = np.array([1.50,1.75,1.32])
    
    resistance_fine_130_min_dw = np.array([0.40,0.26,0.41])
    
    reactance_fine_130_max_dw = np.array([-1.11,-0.26,0.48])
    
    reactance_fine_130_min_dw = np.array([-1.52,-0.81,-0.10])
    
    resistance_130_std_dw = np.array([0.36,0.54,0.29])
    
    reactance_130_std_dw = np.array([0.11,0.14,0.18])
    
    pierce_130 = np.asarray([2.06-2.87j,2.11-1.20j,0.99+0.58j])
    
    pierce_130_constant = np.asarray([0.89-1.83j,1.83-0.86j,0.86+0.44j])

    
    pierce_130_dw = np.asarray([0.12-0.64j,1.54-0.8j,1.12+0.62j])
    
    pierce_130_dw_const = np.asarray([0.46-2.30j,1.09+0.13j,1.03+0.11j])

    
    exp_freqs = np.arange(0.5, 3.1, 0.1)
    freqs_UTAS = np.arange(0.5, 3.0, 0.1)
    
    fig, ax = plt.subplots(1, 1, figsize=(9, 9))
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_up_130, color='g', linestyle='solid', linewidth=3, label='exp. SPL = 130dB')
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. SPL = 145dB')
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc_130, color='g', linestyle='solid', linewidth=3, label='UTAS SPL = 130dB ')
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='r', linestyle='solid', linewidth=3, label='UTAS SPL = 145dB')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_130), edgecolor='g', color='g', s=300, marker='v', facecolor='g', linewidth=3, label='sim. SPL = 130 dB')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_130), resistance_130_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='g', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='g', linewidth=1)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='g', linewidth=1)
        
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. SPL = 145dB')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_145), resistance_145_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='r', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='r', linewidth=1)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='r', linewidth=1)
    
    
    yticks = [0.0, 1.0, 2.0,3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    fig.savefig(path_save + 'insitu_resistance_comparison_differentSPL.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_130, color='g', linestyle='solid', linewidth=3, label='exp. SPL = 130dB')
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. SPL = 145dB')
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc_130, color='g', linestyle='solid', linewidth=3, label='UTAS SPL = 130dB ')
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='r', linestyle='solid', linewidth=3, label='UTAS SPL = 145dB')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_130), edgecolor='g', color='g', s=300, marker='v', facecolor='g', linewidth=3, label='sim. SPL = 130 dB')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. SPL = 145dB')
    
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_130), reactance_130_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='g', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='g', linewidth=1)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='g', linewidth=1)
        
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_145), reactance_145_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='r', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='r', linewidth=1)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='r', linewidth=1)
    
    
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    
    fig.savefig(path_save + 'insitu_reactance_comparison_differentSPL.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. upstream')
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. downstream')
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS POA 8.75%')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_145), resistance_145_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='r', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='r', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='r', linewidth=2)
    
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_145_dw), resistance_145_std_dw)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='b', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='b', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='b', linewidth=2)
    
    
    
    
    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    
    fig.savefig(path_save + 'resistance_up_dw_145.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. upstream')
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. downstream')
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS POA 8.75%')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_145), reactance_145_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='r', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='r', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='r', linewidth=2)
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_145_dw), reactance_145_std_dw)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='b', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='b', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='b', linewidth=2)
    
    
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_up_dw_145.png.png', dpi=300)
    
    colore_azzurro_rgb = (0, 191/255, 255/255)  # (Red, Green, Blue)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_up_130, color='g', linestyle='solid', linewidth=3, label='exp. upstream')
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_dw_130, color=colore_azzurro_rgb, linestyle='solid', linewidth=3, label='exp. downstream')
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc_130, color='k', linestyle='solid', linewidth=3, label='UTAS POA 8.75%')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_130), edgecolor='g', color='g', s=300, marker='v', facecolor='g', linewidth=3, label='sim. up')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_130), resistance_130_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='g', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='g', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='g', linewidth=2)
    
    
    ax.scatter([0.800, 1.400,2.000], np.real(insitu_fine_130_dw), edgecolor=colore_azzurro_rgb, color=colore_azzurro_rgb, s=300, marker='v', facecolor=colore_azzurro_rgb, linewidth=3, label='sim. down')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.real(insitu_fine_130_dw), resistance_130_std_dw)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color=colore_azzurro_rgb, linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors=colore_azzurro_rgb, linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors=colore_azzurro_rgb, linewidth=2)
    
    
    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    fig.savefig(path_save + 'resistance_up_dw_130png', dpi=300)
    
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_130, color='g', linestyle='solid', linewidth=3, label='exp. upstream')
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_dw, color=colore_azzurro_rgb, linestyle='solid', linewidth=3, label='exp. downstream')
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS POA 8.75\%')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_130), edgecolor='g', color='g', s=300, marker='v', facecolor='g', linewidth=3, label='sim. up')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_130), reactance_130_std)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color='g', linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors='g', linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors='g', linewidth=2)
    
    
    
    ax.scatter([0.800, 1.400,2.000], np.imag(insitu_fine_130_dw), edgecolor=colore_azzurro_rgb, color=colore_azzurro_rgb, s=300, marker='v', facecolor=colore_azzurro_rgb, linewidth=3, label='sim. down')
    
    for i, (x, y, err) in enumerate(zip([0.8, 1.4, 2.0], np.imag(insitu_fine_130_dw), reactance_130_std_dw)):
        ax.errorbar(x, y, yerr=err, linestyle='None', color=colore_azzurro_rgb, linewidth=2)
        ax.hlines(y + err, x - 0.05, x + 0.05, colors=colore_azzurro_rgb, linewidth=2)
        ax.hlines(y - err, x - 0.05, x + 0.05, colors=colore_azzurro_rgb, linewidth=2)
    
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_up_dw_130png', dpi=300)
    
    
    
    
    
    #%%#DATI SOVRAPPOSTI DIVERSI METODI 
    
    
    ####################################################SPL 145#################################################################################à
    
    
    freqs_UTAS = np.arange(500,3000,100)
    realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
    imagZ_UTAS_ufsc = np.copy(realZ_UTAS_ufsc)   
    realZ_UTAS_ufsc_130 = np.zeros(len(freqs_UTAS))
    imagZ_UTAS_ufsc_130 = np.copy(realZ_UTAS_ufsc) 
    
    pierce = np.asarray([2.62-3.59j,1.56-0.91j,1.346+0.261j])
    for i in np.arange(len(realZ_UTAS_ufsc)):
        realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,145,freqs_UTAS[i],MeanMach,BLDT)
        
    
    freqs_UTAS = np.arange(0.5, 3.0, 0.1)
    
      
    fig, ax = plt.subplots(1, 1, figsize=(12,12))
    
    ax.plot(exp_freqs, ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
    ax.plot(exp_freqs, kt_ufsc_exp_realZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
    ax.plot(exp_freqs, mm_ufsc_exp_realZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
   
    ax.scatter([0.800, 1.400, 2.000], np.real(kt_real_fine), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
    
    ax.scatter([0.800, 1.400, 2.000], np.real(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')

    
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_145_max, resistance_fine_145_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
        
        
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_145), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce - Myers')
        
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_costant_flow), edgecolor='grey', color='grey', s=300, marker='s', facecolor='grey', linewidth=3, label='sim. Pierce - Myers const.')

    
    yticks = [0.0, 1.0, 2.0,3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 1.00)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    

    fig.savefig(path_save + 'resistace_flow_145.png', dpi=300)
       
    fig, ax = plt.subplots(1, 1, figsize=(12,12))
    
    
    ax.plot(exp_freqs, ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
    ax.plot(exp_freqs, kt_ufsc_exp_imagZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
    ax.plot(exp_freqs, mm_ufsc_exp_imagZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_145_max, reactance_fine_145_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
        
    ax.scatter([0.800, 1.400, 2.000], np.imag(kt_real_fine), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_145), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce - Myers')

    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_costant_flow), edgecolor='grey', color='grey', s=300, marker='s', facecolor='grey', linewidth=3, label='sim. Pierce - Myers const.')

        
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_flow_145.png', dpi=300)
    
    
    #######################################################################UPSTREAM DOWNSTREAM########################################################
    SPL = 145
    freqs_UTAS = np.arange(500,3000,100)
    for i in np.arange(len(realZ_UTAS_ufsc)):
        realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,145,freqs_UTAS[i],MeanMach,BLDT)
       
    
    freqs_UTAS = np.arange(0.5,3.0,0.1)
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')

    ax.scatter(exp_freqs, ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. up')
    
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75% POA')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_145_max, resistance_fine_145_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
    
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_145_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_145_max_dw, resistance_fine_145_min_dw)):
       y=(ma-mi)/2
       yerr=(ma-mi)
       # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
       ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
       ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
       ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)
    
    
    
    
    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    
    fig.savefig(path_save + 'resistance_up_dw_145_fra.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. up')
        
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_145_max, reactance_fine_145_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_145_max_dw, reactance_fine_145_min_dw)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)
    
    
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_up_dw_145_fra.png', dpi=300)
    
    Mach = 0.32

    mm_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,4]
    mm_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,5]

    mm_ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,6]
    mm_ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7]
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, mm_ufsc_exp_realZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')
  
    
    ax.scatter(exp_freqs, mm_ufsc_exp_realZ_up, color='r', linestyle='solid', linewidth=3, label='exp. up')
    

    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_145), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='pierce - myers')
    
    #ax.scatter([0.800, 1.400, 2.000], np.real(pierce_costant_flow), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='pierce - myers costnat flow')

    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_145_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. up')
    
    #ax.scatter([0.800, 1.400, 2.000], np.real(pierce_145_dw_const), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. up')

    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=30)
    ax.tick_params(axis='both', labelsize=40)
    
    fig.savefig(path_save + 'resistance_145_up_dw_pierce_blending.png', dpi=300)

    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, mm_ufsc_exp_imagZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')

  
    ax.scatter(exp_freqs, mm_ufsc_exp_imagZ_up, color='r', linestyle='solid', linewidth=3, label='exp. up')
    
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    
    #ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_145), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim.  up')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_costant_flow), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')

    #ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_145_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_145_dw_const), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')

    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    
    fig.savefig(path_save + 'reactance_145_up_dw_pierce.png', dpi=300)
    
    
    ###########################################################################SPL 130############################################################################
    SPL = 130
    
    Mach = 0.3
    
    if Mach == 0.3 or Mach == 0:
        #if ac_source == 'up':
            in_situ_ufsc_exp_realZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
            in_situ_ufsc_exp_imagZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
            in_situ_ufsc_exp_realZ_up_130      = in_situ_ufsc_exp_realZ_up_130.mean(axis=1)
            in_situ_ufsc_exp_imagZ_up_130      = in_situ_ufsc_exp_imagZ_up_130.mean(axis=1)
            
            in_situ_ufsc_exp_realZ_dw_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7:9]
            in_situ_ufsc_exp_imagZ_dw_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,17:19]
            in_situ_ufsc_exp_realZ_dw_130      = in_situ_ufsc_exp_realZ_dw_130.mean(axis=1)
            in_situ_ufsc_exp_imagZ_dw_130      = in_situ_ufsc_exp_imagZ_dw_130.mean(axis=1)
    
    
            kt_ufsc_exp_realZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
            kt_ufsc_exp_imagZ_up_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
            
            mm_ufsc_exp_realZ_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
            mm_ufsc_exp_imagZ_130      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
    
    freqs_UTAS = np.arange(500,3000,100)
    
    for i in np.arange(len(realZ_UTAS_ufsc)):
        realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,130,freqs_UTAS[i],MeanMach,BLDT)
        
    
    kt_real_fine_130 = np.array([-0.01-1.48j,1.53-0.43j,1.03+0.35j])       
            
    mm_real_130     = np.array([1.84-2.77j,1.29-0.65j,1.01+0.29j])
    
    insitu_fine_130 = np.array([0.46-1.41j,0.52-0.39j,0.4+0.17j])
    
    resistance_130_std = np.array([0.29,0.21,0.20])
    
    reactance_130_std = np.array([0.191,0.2012,0.2312])
    
    
    resistance_fine_130_max = np.array([1.48,1.37,1.25])
    
    resistance_fine_130_min = np.array([0.42,0.5,0.35])
    
    
    reactance_fine_130_max = np.array([-1.31,-0.25,0.37])
    
    reactance_fine_130_min = np.array([-1.61,-0.71,-0.20])
    
    insitu_fine_130_dw = np.array([1.31-1.22j,1.37-0.43j,1.12+0.21j])
    
    resistance_130_std_dw = np.array([0.36,0.54,0.20])
    
    reactance_130_std_dw = np.array([0.11,0.14,0.2312])
    
    freqs_UTAS = np.arange(0.5, 3.0, 0.1)
    
      
    fig, ax = plt.subplots(1, 1, figsize=(12,12))
    
    ax.plot(exp_freqs, in_situ_ufsc_exp_realZ_up_130, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
    ax.plot(exp_freqs, kt_ufsc_exp_realZ_up_130, color='b', linestyle='solid', linewidth=3, label='exp. KT')
    ax.plot(exp_freqs, mm_ufsc_exp_realZ_130, color='g', linestyle='solid', linewidth=3, label='exp. MM')
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
   
    ax.scatter([0.800, 1.400, 2.000], np.real(kt_real_fine_130), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
    
    ax.scatter([0.800, 1.400, 2.000], np.real(mm_real_130), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_130), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_130_max, resistance_fine_130_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
        
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce - Myers')
   
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130_constant), edgecolor='gray', color='gray', s=300, marker='s', facecolor='gray', linewidth=3, label='sim. Pierce - Myers const.')
    
    yticks = [0.0, 1.0, 2.0,3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=30)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 1.00)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    

    fig.savefig(path_save + 'resistace_flow_130.png', dpi=300)
       
    fig, ax = plt.subplots(1, 1, figsize=(12,12))
    
    
    ax.plot(exp_freqs, ufsc_exp_imagZ_up_130, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
    ax.plot(exp_freqs, kt_ufsc_exp_imagZ_up_130, color='b', linestyle='solid', linewidth=3, label='exp. KT')
    ax.plot(exp_freqs, mm_ufsc_exp_imagZ_130, color='g', linestyle='solid', linewidth=3, label='exp. MM')
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_145), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_130_max, reactance_fine_130_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
        
    ax.scatter([0.800, 1.400, 2.000], np.imag(kt_real_fine), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
    

    
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce - Myers')
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130_constant), edgecolor='gray', color='gray', s=300, marker='s', facecolor='gray', linewidth=3, label='sim. Pierce - Myers const.')

        
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_flow_130.png', dpi=300)
    
    
    
    
    
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_dw_130, color='b', linestyle='solid', linewidth=3, label='exp. down')
    
    
    ax.scatter(exp_freqs, ufsc_exp_realZ_up_130, color='r', linestyle='solid', linewidth=3, label='exp. up')
    
    
    
    
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75% POA')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_130), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_130_max, resistance_fine_130_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
    
    
    
    ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_130_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_130_max_dw, resistance_fine_130_min_dw)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)
    
    
    
    
    
    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    
    fig.savefig(path_save + 'resistance_up_dw_130_fra.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_dw_130, color='b', linestyle='solid', linewidth=3, label='exp. down')
    
    
    ax.scatter(exp_freqs, ufsc_exp_imagZ_up_130, color='r', linestyle='solid', linewidth=3, label='exp. up')
    
    
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_130), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. up')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_130_max, reactance_fine_130_min)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
    
    ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_130_dw), edgecolor='b', color='b', s=300, marker='^', facecolor='b', linewidth=3, label='sim. down')
    
    for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_130_max_dw, reactance_fine_130_min_dw)):
        y=(ma-mi)/2
        yerr=(ma-mi)
        # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
        ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
        ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
        ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)
    
    
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_up_dw_130_fra.png', dpi=300)

    Mach = 0.32
    mm_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,4]
    mm_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,5]

    mm_ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,6]
    mm_ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7]
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    
    ax.scatter(exp_freqs, mm_ufsc_exp_realZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')
  
    
    ax.scatter(exp_freqs, mm_ufsc_exp_realZ_up, color='r', linestyle='solid', linewidth=3, label='exp. up')
    ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75% POA')
    
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')
    
    #ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130_constant), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')

    
    ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')
    
    #ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130_dw_const), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. up')


    
    
    yticks = [0.0, 1.0, 2.0, 3.0]
    xticks = [ 1.0, 1.5, 2.0, 2.5]
    ax.set_xlabel("$f, kHz$", fontsize=40)
    ax.set_xlim(0.5, 2.6)
    ax.set_ylim(0.0, 3.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    # ax.legend(numpoints=1, loc='best', fontsize=30)
    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    ax.set_ylabel(r'$\theta$', fontsize=40)
    ax.tick_params(axis='both', labelsize=40)
    
    
    fig.savefig(path_save + 'resistance_up_dw_130_fra_pierce.png', dpi=300)
    
    fig, ax = plt.subplots(1, 1, figsize=(9,9))
    
    ax.scatter(exp_freqs, mm_ufsc_exp_imagZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')

    
    ax.scatter(exp_freqs, mm_ufsc_exp_imagZ_up, color='r', linestyle='solid', linewidth=3, label='exp. up')
    
    
    
    ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
    
    
    
    #ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')
   
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130_constant), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')

   
    #ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')
   
    ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130_dw_const), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')


  
    
    ax.set_xlabel('$f, kHz$',fontsize=40)
    ax.set_xlim(0.5,2.6)
    ax.set_ylim(-4,1.5)
    ax.set_xticks(xticks, xticks)
    yticks = [-3,-2,-1,0,1,2]
    ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=30)
    ax.set_ylabel(r'$\chi$',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    
    fig.savefig(path_save + 'reactance_up_dw_130_fra_pierce.png', dpi=300)
    
    
    
#%%
else:
    
    if SPL == 145:
        in_situ_ufsc_exp_realZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
        in_situ_ufsc_exp_imagZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
        in_situ_ufsc_exp_realZ_up_145      = in_situ_ufsc_exp_realZ_up_145.mean(axis=1)
        in_situ_ufsc_exp_imagZ_up_145      = in_situ_ufsc_exp_imagZ_up_145.mean(axis=1)
    
    
        kt_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
        kt_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
        
        mm_ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
        mm_ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
        
        
        mm_real     = np.array([0.46-2.46j,0.38-0.62j,0.35+0.37j])
        
        kt_real = np.array([0.35-2.31j,0.49-0.59j,0.3+0.61j])
        
        insitu_real = np.array([0.22-1.44j,0.4-0.35j,0.25+0.36j])
        
        resistance_std = np.array([0.08,0.09,0.06])
        reactance_std = np.array([0.02,0.04,0.01])
        
        exp_freqs = np.arange(0.5, 3.1, 0.1)
        
        
        pierce_145 = np.asarray([0.33-2.30j,0.49-0.59j,0.59+0.49j])
        
        resistance_fine_145_max = np.array([0.31,0.46,0.37])
        resisitance_fine_145_min = np.array([0.1,0.22,0.15])
        reactance_fine_145_max = np.array([-1.40,-0.25,0.4])
        reactance_fine_145_min = np.array([-1.47,-0.36,0.26]) 
        
        
        freqs_UTAS = np.arange(500,3000,100)
        realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
        imagZ_UTAS_ufsc = np.copy(realZ_UTAS_ufsc)   
        realZ_UTAS_ufsc_130 = np.zeros(len(freqs_UTAS))
        imagZ_UTAS_ufsc_130 = np.copy(realZ_UTAS_ufsc) 
        
        
        for i in np.arange(len(realZ_UTAS_ufsc)):
            realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,145,freqs_UTAS[i],MeanMach,BLDT)
            realZ_UTAS_ufsc_130[i], imagZ_UTAS_ufsc_130[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,130,freqs_UTAS[i],MeanMach,BLDT)
            
        
        freqs_UTAS = np.arange(0.5, 3.0, 0.1)
        
          
        fig, ax = plt.subplots(1, 1, figsize=(10,10))
        
        ax.plot(exp_freqs, in_situ_ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
        ax.plot(exp_freqs, kt_ufsc_exp_realZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
        ax.plot(exp_freqs, mm_ufsc_exp_realZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
        
        ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
        
       
        ax.scatter([0.800, 1.400, 2.000], np.real(kt_real), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
        
        ax.scatter([0.800, 1.400, 2.000], np.real(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
        
        ax.scatter([0.800, 1.400, 2.000], np.real(insitu_real), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
        
        ax.scatter([0.800, 1.400, 2.000], np.real(pierce_145), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce-Myers')

        
        i = 0
        for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_145_max, resisitance_fine_145_min)):
            y=(ma-mi)/2
            yerr=(ma-mi)
            # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
            ax.plot([x,x],[ma, mi],linestyle='solid',color='r',linewidth=3)
            ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
            ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
            
            
            
        yticks = [0.0,0.25, 0.5,0.75, 1.00]
        xticks = [ 1.0, 1.5, 2.0, 2.5]
        ax.set_xlabel("$f, kHz$", fontsize=40)
        ax.set_xlim(0.5, 2.6)
        ax.set_ylim(0.0, 1.0)
        ax.set_xticks(xticks)
        ax.set_yticks(yticks)
        # ax.legend(numpoints=1, loc='best', fontsize=30)
        ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        ax.set_ylabel(r'$\theta$', fontsize=40)
        ax.tick_params(axis='both', labelsize=40)
        
    
        fig.savefig(path_save + 'resistace_noflow.png', dpi=300)
           
        fig, ax = plt.subplots(1, 1, figsize=(10,10))
        
        
        ax.plot(exp_freqs, in_situ_ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
        ax.plot(exp_freqs, kt_ufsc_exp_imagZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
        ax.plot(exp_freqs, mm_ufsc_exp_imagZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
        
        ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_real), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
        
        for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_145_max, reactance_fine_145_min)):
            y=(ma-mi)/2
            yerr=(ma-mi)
            # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
            ax.plot([x,x],[ma, mi],linestyle='solid',color='r',linewidth=3)
            ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
            ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
            
        ax.scatter([0.800, 1.400, 2.000], np.imag(kt_real), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_145), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce-Myers')

       
            
        ax.set_xlabel('$f, kHz$',fontsize=40)
        ax.set_xlim(0.5,2.6)
        ax.set_ylim(-4,1.5)
        ax.set_xticks(xticks, xticks)
        yticks = [-3,-2,-1,0,1,2]
        ax.set_yticks(yticks, yticks)
        ax.legend(numpoints=1,loc='lower right',fontsize=30)
        ax.set_ylabel(r'$\chi$',fontsize=40)
        ax.tick_params(axis='both', labelsize = 40)
        
        fig.savefig(path_save + 'reactance_noflow.png', dpi=300)
        
    else:
        in_situ_ufsc_exp_realZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
        in_situ_ufsc_exp_imagZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
        in_situ_ufsc_exp_realZ_up_145      = in_situ_ufsc_exp_realZ_up_145.mean(axis=1)
        in_situ_ufsc_exp_imagZ_up_145      = in_situ_ufsc_exp_imagZ_up_145.mean(axis=1)
    
    
        kt_ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
        kt_ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
        
        mm_ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
        mm_ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
        
        
        mm_real     = np.array([0.05-2.4j,0.19-0.4j,0.18+0.37j])
        
        kt_real = np.array([0.11-2.25j,0.17-0.48j,0.1+0.12j])
        
        insitu_real = np.array([0.09-1.27j,0.12-0.27j,0.07+0.43j])
        
        resistance_fine_130_max = np.array([0.12,0.17,0.1])
        
        resistance_fine_130_min = np.array([0.09,0.02,0.04]) 
        
        reactance_fine_130_max = np.array([-1.32,-0.23,0.45])
        
        reactance_fine_130_min = np.array([-1.41,-0.38,0.32])
        
        pierce_130 =np.asarray([0.12-2.22j,0.17-0.53j,0.28+0.53j])
        
        resistance_std = np.array([0.07,0.04,0.06])
        reactance_std = np.array([0.03,0.05,0.02])
        
        exp_freqs = np.arange(0.5, 3.1, 0.1)
        
        
            
        freqs_UTAS = np.arange(500,3000,100)
        realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
        imagZ_UTAS_ufsc = np.copy(realZ_UTAS_ufsc)   
        realZ_UTAS_ufsc_130 = np.zeros(len(freqs_UTAS))
        imagZ_UTAS_ufsc_130 = np.copy(realZ_UTAS_ufsc) 
        
        
        for i in np.arange(len(realZ_UTAS_ufsc)):
            realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,SPL,freqs_UTAS[i],MeanMach,BLDT)
            
        
        freqs_UTAS = np.arange(0.5, 3.0, 0.1)
        
          
        fig, ax = plt.subplots(1, 1, figsize=(10,10))
        
        ax.plot(exp_freqs, in_situ_ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
        ax.plot(exp_freqs, kt_ufsc_exp_realZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
        ax.plot(exp_freqs, mm_ufsc_exp_realZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
        
        ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
        
       
        ax.scatter([0.800, 1.400, 2.000], np.real(kt_real), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
        
        ax.scatter([0.800, 1.400, 2.000], np.real(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
        
        
        ax.scatter([0.800, 1.400, 2.000], np.real(insitu_real), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')

        ax.scatter([0.800, 1.400, 2.000], np.real(pierce_130), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce-Myers')

        for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_130_max, resistance_fine_130_min)):
            y=(ma-mi)/2
            yerr=(ma-mi)
            # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
            ax.plot([x,x],[ma, mi],linestyle='solid',color='r',linewidth=3)
            ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
            ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
            
            
        
        yticks = [0.0,0.25, 0.5,0.75, 1.00]
        xticks = [ 1.0, 1.5, 2.0, 2.5]
        ax.set_xlabel("$f, kHz$", fontsize=40)
        ax.set_xlim(0.5, 2.6)
        ax.set_ylim(0.0, 1.00)
        ax.set_xticks(xticks)
        ax.set_yticks(yticks)
        # ax.legend(numpoints=1, loc='best', fontsize=30)
        ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
        ax.set_ylabel(r'$\theta$', fontsize=40)
        ax.tick_params(axis='both', labelsize=40)
        
    
        fig.savefig(path_save + 'resistace_noflow_130.png', dpi=300)
           
        fig, ax = plt.subplots(1, 1, figsize=(10,10))
        
        
        ax.plot(exp_freqs, in_situ_ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. in situ')
        ax.plot(exp_freqs, kt_ufsc_exp_imagZ_up, color='b', linestyle='solid', linewidth=3, label='exp. KT')
        ax.plot(exp_freqs, mm_ufsc_exp_imagZ, color='g', linestyle='solid', linewidth=3, label='exp. MM')
        
        ax.plot(freqs_UTAS, imagZ_UTAS_ufsc, color='k', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_real), edgecolor='r', color='r', s=300, marker='^', facecolor='r', linewidth=3, label='sim. in situ')
        
        for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_130_max, reactance_fine_130_min)):
            y=(ma-mi)/2
            yerr=(ma-mi)
            # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
            ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
            ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
            ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)
            
        ax.scatter([0.800, 1.400, 2.000], np.imag(kt_real), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. KT')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(mm_real), edgecolor='g', color='g', s=300, marker='o', facecolor='g', linewidth=3, label='sim. MM')
        
        ax.scatter([0.800, 1.400, 2.000], np.imag(pierce_130), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. Pierce-Myers')

       
            
        ax.set_xlabel('$f, kHz$',fontsize=40)
        ax.set_xlim(0.5,2.6)
        ax.set_ylim(-4,1.5)
        ax.set_xticks(xticks, xticks)
        yticks = [-3,-2,-1,0,1,2]
        ax.set_yticks(yticks, yticks)
        ax.legend(numpoints=1,loc='lower right',fontsize=30)
        ax.set_ylabel(r'$\chi$',fontsize=40)
        ax.tick_params(axis='both', labelsize = 40)
        
        fig.savefig(path_save + 'reactance_noflow_130.png', dpi=300)