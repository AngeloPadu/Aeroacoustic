#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 15:01:10 2024

@author: angelo
"""

"Import python packages"
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import csd
import scipy.linalg as LA
import scipy as sp
from matplotlib.ticker import FuncFormatter

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
plt.close('all')
 
 
cm                  = 1/2.54
"File parameters"
frequencies         = [800]
all_freq            = np.array([800,1400,2000])
ac_source           = 'up'
SPL                 = 145
Mach                = 0.3
version             = '14_1'
BCs                 = 'NoSlip'
geom                = 'real_geometry'
resolution          = 'fine'
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'
if BCs == 'Slip':
    W                   = 0.02                                                      # duct width [m]
elif BCs == 'NoSlip':
    W                   = 0.04                                                      # duct width [m]
H                   = 0.01                                                      # duct height [m]                                                   # duct height [m]
 
"Liner parameters - NASA"
n_cavities          = 11                                                        # Number of liner cavities
POA                 = 6.3/100                                                   # Percentage of Open Area
cvt_height          = 38.1e-3                                                 # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                  # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                 # Orifice diameter (m)
linerLength         = 136.906e-3                                                # Liner length in meters [m]
 
#%% =============================================================================
# BEGIN CODE
# =============================================================================
nFreq           = len(frequencies)
cvt_width       = linerLength/11
 
# =============================================================================
# CENTERLINE Medium
# =============================================================================
# =============================================================================
 


path            = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/fine/{}/{}/SPL_centerline/'.format(ac_source,geom,SPL,frequencies[0])

try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[:,0]
P_data_fine          = P_centerline[:,1:]
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_fine)
SPL_centerline_fine  = np.zeros(np.shape(P_data_fine)[1])
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_fine)):    
    f, Sxx              = csd(P_data_fine[:,i],P_data_fine[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_fine[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,20*np.log10(np.sqrt(np.abs(Sxx))/2e-5))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([100,3000])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))

path            = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/noflow/{}/fine/{}/{}/SPL_centerline/'.format(geom,SPL,frequencies[0])

try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[:,0]
P_data_fine_noflow          = P_centerline[5382:6002,1:]
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_fine_noflow)
SPL_centerline_fine_noflow  = np.zeros(np.shape(P_data_fine_noflow)[1])
 
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_fine)):    
    f, Sxx              = csd(P_data_fine_noflow[:,i],P_data_fine_noflow[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_fine_noflow[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))

size        = 5
line        = 3
 
    
# Plot SPL in funzione della distanza
plt.figure(figsize=(8, 8))  # Imposta le dimensioni del grafico
distanze_fine = np.linspace(0,1,len(SPL_centerline_fine));

plt.plot(distanze_fine, SPL_centerline_fine,color='b',linestyle='solid',linewidth=line,label='fine res.',marker='s',markerfacecolor='b',markersize=size )  # Crea il grafico
plt.xlabel('$x/L$', fontsize=30)  # Etichetta dell'asse x
plt.ylabel('$SPL [dB]$', fontsize=30)  # Etichetta dell'asse y
#plt.title('SPL decay along channel',fontsize=30)  # Titolo del grafico
# min_spl = min(min(SPL_centerline_fine), min(SPL_centerline_medium), min(SPL_centerline_veryfine))
# max_spl = max(max(SPL_centerline_fine), max(SPL_centerline_medium), max(SPL_centerline_veryfine))
num_yticks = 5  # Puoi impostare il numero desiderato di ticks equidistanti
# ytick_values = np.linspace(round(min_spl,1), round(max_spl,1), num_yticks)
def format_y_axis(value, _):
    return f'{value:.1f}'  # I
plt.gca().yaxis.set_major_formatter(FuncFormatter(format_y_axis))
 
plt.grid(True)  # Abilita la griglia di sfondo
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.legend(numpoints=1,loc='upper right',fontsize=30)

# plt.show()  # Mostra il grafico

 

ac_source           = 'down'


path            = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/fine/{}/{}/SPL_centerline/'.format(ac_source,geom,SPL,frequencies[0])

try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[:,0]
P_data_145_down          = P_centerline[:,1:]
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_fine)
SPL_centerline_145_down  = np.zeros(np.shape(P_data_145_down)[1])
 
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_fine)):    
    f, Sxx              = csd(P_data_145_down[:,i],P_data_145_down[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_145_down[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))

size        = 5
line        = 3
 
    
# Plot SPL in funzione della distanza
plt.figure(figsize=(8, 8))  # Imposta le dimensioni del grafico
distanze_fine = np.linspace(0,1,len(SPL_centerline_fine));

plt.plot(distanze_fine, SPL_centerline_145_down,color='b',linestyle='solid',linewidth=line,label='fine res.',marker='s',markerfacecolor='b',markersize=size )  # Crea il grafico
plt.xlabel('$x/L$', fontsize=30)  # Etichetta dell'asse x
plt.ylabel('$SPL [dB]$', fontsize=30)  # Etichetta dell'asse y
#plt.title('SPL decay along channel',fontsize=30)  # Titolo del grafico
# min_spl = min(min(SPL_centerline_fine), min(SPL_centerline_medium), min(SPL_centerline_veryfine))
# max_spl = max(max(SPL_centerline_fine), max(SPL_centerline_medium), max(SPL_centerline_veryfine))
num_yticks = 5  # Puoi impostare il numero desiderato di ticks equidistanti
# ytick_values = np.linspace(round(min_spl,1), round(max_spl,1), num_yticks)
def format_y_axis(value, _):
    return f'{value:.1f}'  # I
plt.gca().yaxis.set_major_formatter(FuncFormatter(format_y_axis))
 
plt.grid(True)  # Abilita la griglia di sfondo
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.legend(numpoints=1,loc='upper right',fontsize=30)

# plt.show()  # Mostra il grafico

#%% =============================================================================
# COMPARISON SPL DROP
# =============================================================================
"SPL drop by KT for experimental data processed by me - 145 dB M0.3 upstream"
 
exp_freqs  = all_freq
x_mics_exp = np.array([0.0798065,0.119807,0.159807,0.199807,0.239807,0.279807,0.319807,0.359807])
 


linerLength_exp = 420e-3
if ac_source == 'up':
    "experimental KT for upstream"
    SPL_exp = np.array([[141.65, 141.63, 140.70, 139.60, 139.66, 140.30, 138.92, 136.44],
            [140.56, 139.50, 137.85, 136.44, 134.97, 133.83, 132.03, 131.76],
            [141.14, 139.66, 137.30, 135.72, 133.77, 131.80, 130.67, 128.10]])
else:
    "experimental KT for downstream"
    SPL_exp = np.array([[129.073,131.829,133.607,134.742,136.518,138.663,140.154,141.815],
            [108.141,112.037,116.484,120.545,124.612,129.804,133.882,138.232],
            [112.773,116.738,120.805,124.939,128.12,132.905,136.397,140.052]])
"Import experimental data for only 11 cavities"
 
if SPL == 145:
    exp_11cvts = np.array([[142.263,141.328,140.652,140.766,141.415,142.078],
                                [143.213,141.907,140.734,139.966,140.089,139.966],
                                [143.555,141.211,141.425,142.337,140.847,134.499]])
    
    exp_11cvts_noflow = np.array([[143.769,142.507,141.827,142.351,143.402,144.258],
                                [140.903,138.764,136.632,133.328,127.22,125.651],
                                [143.791,143.692,143.368,142.161,139.426,134.196]])
else:
    exp_11cvts = np.array([[127.304,126.156,125.289,125.539,126.389,127.292],
                              [129.125,128.214,127.078,125.369,124.71,125.887],
                              [129.529,127.323,125.971,126.788,126.757,123.298]])


exp_11cvts_145_down = np.array([[138.938,139.168,139.341,140.077,141.322,142.594],
                            [130.899,132.712,134.635,136.628,138.795,141.347],
                            [133.087,135.957,137.668,138.887,140.532,143.04]])
 
mics_11cvts = np.array([15,35,55,75,95,115])
 
# =============================================================================
# PLOT
# =============================================================================

size        = 15
line        = 2
fsize       = 9.5
 
step_med=140
step_fine=14

fig, ax = plt.subplots(1, 1, figsize=(12,12))
ax.plot(mics_11cvts/(np.max(mics_11cvts)),exp_11cvts[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts[np.where(exp_freqs==frequencies[0])[0][0],:]),color='r',linestyle='dashed',linewidth=line,label='exp. up',marker='x',markersize=size, markeredgewidth=2)
ax.plot(mics_11cvts/(np.max(mics_11cvts)),exp_11cvts_145_down[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts_145_down[np.where(exp_freqs==frequencies[0])[0][0],:]),color='b',linestyle='dashed',linewidth=line,label='exp. down',marker='x',markersize=size, markeredgewidth=2)
ax.plot(mics_11cvts/(np.max(mics_11cvts)),exp_11cvts_noflow[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts_noflow[np.where(exp_freqs==frequencies[0])[0][0],:]),color='k',linestyle='dashed',linewidth=line,label='exp. no flow',marker='x',markersize=size, markeredgewidth=2)
#ax.plot(np.linspace(0,linerLength,np.shape(P_data_medium)[1])[::step_med]*1e3,SPL_centerline_medium[::step_med]/np.max(SPL_centerline_medium[::step_med]),color='r',linestyle='solid',linewidth=line,label='medium res.',marker='o',markerfacecolor='none',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0.1,1.1,np.shape(P_data_fine)[1])[::step_fine],SPL_centerline_fine[::step_fine]/np.max(SPL_centerline_fine[::step_fine]),color='r',linestyle='solid',linewidth=line,label='sim. up',marker='s',markerfacecolor='r',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0.1,1.1,np.shape(P_data_fine_noflow)[1])[::step_fine],SPL_centerline_fine_noflow[::step_fine]/np.max(SPL_centerline_fine_noflow[::step_fine]),color='k',linestyle='solid',linewidth=line,label='sim. no flow',marker='s',markerfacecolor='k',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0.1,1.1,np.shape(P_data_145_down)[1])[::step_fine],SPL_centerline_145_down[::step_fine]/np.max(SPL_centerline_145_down[::step_fine]),color='b',linestyle='solid',linewidth=line,label='sim. down',marker='s',markerfacecolor='b',markersize=size, markeredgewidth=2)
#ax.plot(np.linspace(0,linerLength,np.shape(P_data_veryfine)[1])[::step_fine]*1e3,SPL_centerline_veryfine[::step_fine]/np.max(SPL_centerline_veryfine[::step_fine]),color='k',linestyle='solid',linewidth=line,label='veryfine res.',marker='d',markerfacecolor='none',markersize=size, markeredgewidth=2)
# ax.set_xlim([-0.001,0.125])
# ax.set_xlabel('$x$ Coordinate, mm', fontsize=30)
# ax.set_yticks([105,110,115,120,125,130,135,140],['105','110','115','120','125','130','135','140'])
ax.grid(alpha=0.5)
# ax.set_ylim([105,140])
ax.set_ylabel(r'$\mathrm{SPL}$/$\mathrm{SPL_{max}}$', multialignment="center", fontsize=40)
#axins = ax.inset_axes([0.3, 0.02, 0.5, 0.5])
#axins.plot(mics_11cvts,exp_11cvts_145[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts_145[np.where(exp_freqs==frequencies[0])[0][0],:]),color='k',linestyle='dashed',linewidth=line,label='exp. KT  11 mics',marker='x',markersize=size, markeredgewidth=2)
#axins.plot(np.linspace(0,linerLength,np.shape(P_data_medium)[1])[::step_med]*1e3,SPL_centerline_medium[::step_med]/np.max(SPL_centerline_medium),color='r',linestyle='solid',linewidth=line,label = 'medium res.',marker='o',markerfacecolor='none',markersize=size, markeredgewidth=2)
#axins.plot(np.linspace(0,linerLength,np.shape(P_data_fine)[1])[::step_fine]*1e3,SPL_centerline_fine[::step_fine]/np.max(SPL_centerline_fine),color='b',linestyle='solid',linewidth=line,label='num. results',marker='s',markerfacecolor='none',markersize=size, markeredgewidth=2)
#axins.plot(np.linspace(0,linerLength,np.shape(P_data_veryfine)[1])[::step_fine]*1e3,SPL_centerline_veryfine[::step_fine]/np.max(SPL_centerline_veryfine),color='k',linestyle='solid',linewidth=line,label='veryfine res.',marker='d',markerfacecolor='none',markersize=size, markeredgewidth=2)
#axins.set_xlim(0, linerLength*1e3)
#axins.set_ylim(0.97, 1.005)
#axins.set_xticks([],[])
plt.xticks(fontsize=40)
plt.yticks(fontsize=40)
# ax.set_yticks([0.85,0.90,0.95,1.0],['0.85','0.90','0.95','1.00'])
ax.grid(alpha=0.5)
# ax.set_ylim([0.85,1.01])
# ax.plot(x_mics_exp*1e3,SPL_exp[np.where(exp_freqs==frequencies[0])[0][0]]/np.max(SPL_exp[np.where(exp_freqs==frequencies[0])[0][0]]),color='k',linestyle='solid',linewidth=line,label='exp. KT mics')
ax.set_xticks([0,1],['0','L'])
# fig.savefig('/home/angelo/Scrivania/SPLdrop_MvsF_{}Hz.svg'.format(frequencies[0]))
plt.legend(numpoints=1,loc='lower right',fontsize=30)
 
# path = '/home/angelo/Scrivania/PhD/aeroacustica/figure_paper_JFM/Acoustics/M=0.3/spl decay/'.format(frequencies[0])
path = '/home/angelo/Scrivania/'
plt.savefig(path + 'SPL_decay_comparison_up_dw_{}_{}.svg'.format(SPL,frequencies[0]), bbox_inches = 'tight', dpi=300)
 
#%%PLOT 130 e 145 upstream

exp_11cvts_145 = np.array([[142.263,141.328,140.652,140.766,141.415,142.078],
                             [143.213,141.907,140.734,139.966,140.089,139.966],
                             [143.555,141.211,141.425,142.337,140.847,134.499]])

exp_11cvts_130 = np.array([[127.304,126.156,125.289,125.539,126.389,127.292],
                          [129.125,128.214,127.078,125.369,124.71,125.887],
                          [129.529,127.323,125.971,126.788,126.757,123.298]])

mics_11cvts = np.array([15,35,55,75,95,115])
exp_freqs  = all_freq

size        = 15
line        = 2
fsize       = 9.5
 
step_med=140
step_fine=14

ac_source = 'up'
SPL = 130
geom = 'real_geometry'
frequencies = [2000]
path            = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/fine/{}/{}/SPL_centerline/'.format(ac_source,geom,SPL,frequencies[0])

try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[:,0]
P_data_fine          = P_centerline[:5128,1:]
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_fine)
SPL_centerline_fine  = np.zeros(np.shape(P_data_fine)[1])

"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_fine)):    
    f, Sxx              = csd(P_data_fine[:,i],P_data_fine[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_fine[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f, 20*np.log10(np.sqrt(np.abs(Sxx))/2e-5))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))

SPL = 145

path            = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/fine/{}/{}/SPL_centerline/'.format(ac_source,geom,SPL,frequencies[0])

try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[:,0]
P_data_fine_145         = P_centerline[:,1:]
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_fine_145)
SPL_centerline_fine_145  = np.zeros(np.shape(P_data_fine_145)[1])

"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_fine)):    
    f, Sxx              = csd(P_data_fine_145[:,i],P_data_fine_145[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_fine_145[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))



fig, ax = plt.subplots(1, 1, figsize=(8,8))
ax.plot(mics_11cvts/np.max(mics_11cvts),exp_11cvts_130[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts_130[np.where(exp_freqs==frequencies[0])[0][0],:]),color='green',linestyle='dashed',linewidth=line,label='exp. 130dB',marker='x',markersize=size, markeredgewidth=2)
ax.plot(mics_11cvts/np.max(mics_11cvts),exp_11cvts_145[np.where(exp_freqs==frequencies[0])[0][0],:]/np.max(exp_11cvts_145[np.where(exp_freqs==frequencies[0])[0][0],:]),color='r',linestyle='dashed',linewidth=line,label='exp. 145dB',marker='x',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0.1,1.1,np.shape(P_data_fine)[1])[::step_fine],SPL_centerline_fine[::step_fine]/np.max(SPL_centerline_fine[::step_fine]),color='green',linestyle='solid',linewidth=line,label='sim. 130dB',marker='s',markerfacecolor='green',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0.1,1.1,np.shape(P_data_fine_145)[1])[::step_fine],SPL_centerline_fine_145[::step_fine]/np.max(SPL_centerline_fine_145[::step_fine]),color='r',linestyle='solid',linewidth=line,label='sim. 145dB',marker='s',markerfacecolor='r',markersize=size, markeredgewidth=2)

ax.set_yticks([0.90,0.95,1.0],['0.90','0.95','1.00'])
ax.grid(alpha=0.5)
ax.set_ylim([0.90,1.005])
ax.set_ylabel(r'$\mathrm{SPL}$/$\mathrm{SPL_{max}}$', multialignment="center", fontsize=40)

plt.xticks(fontsize=40)
plt.yticks(fontsize=40)

ax.set_xticks([0,0.5,1],['0','L/2','L'])
plt.legend(numpoints=1,loc='lower left',fontsize=30)
path = '/home/angelo/Scrivania/'
# plt.savefig(path + 'SPL_decay_comparison_130_145_{}.svg'.format(frequencies[0]), bbox_inches = 'tight', dpi=300)

#%%
 
resolution = 'fine'
 
path            = '/home/angelo/Scrivania/aeroacustica/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/NASA_UFSC-V14_1-M0.3-NoSlip_NoSlip/{}/Acoustics/{}/{}/SPL_decay/'.format(resolution,SPL,frequencies[0])
 
try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[1600:,0]
P_data_800          = P_centerline[1600:,1:]-np.mean(P_centerline[1600:,1:])
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_800)
SPL_centerline_800  = np.zeros(np.shape(P_data_800)[1])
 
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_800)):    
    f, Sxx              = csd(P_data_800[:,i],P_data_800[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[0])==np.min(np.abs(f-frequencies[0])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_800[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))
ax.set_ylabel('Spectrum amplitude [dB]',fontsize=30)    
 
path            = '/home/angelo/Scrivania/aeroacustica/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/NASA_UFSC-V14_1-M0.3-NoSlip_NoSlip/{}/Acoustics/{}/{}/SPL_decay/'.format(resolution,SPL,frequencies[1])
 
try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[1600:,0]
P_data_1400          = P_centerline[1600:,1:]-np.mean(P_centerline[1600:,1:])
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_1400)
SPL_centerline_1400  = np.zeros(np.shape(P_data_1400)[1])
 
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_1400)):    
    f, Sxx              = csd(P_data_1400[:,i],P_data_1400[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[1])==np.min(np.abs(f-frequencies[1])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_1400[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))
ax.set_ylabel('Spectrum amplitude [dB]',fontsize=30)   
 
 
path            = '/home/angelo/Scrivania/aeroacustica/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/NASA_UFSC-V14_1-M0.3-NoSlip_NoSlip/{}/Acoustics/{}/{}/SPL_decay/'.format(resolution,SPL,frequencies[2])
 
try:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure')
except:
    P_centerline    = np.loadtxt(path + 'SPL_centerline_pressure.txt')
P_time          = P_centerline[1600:,0]
P_data_2000          = P_centerline[1600:,1:]-np.mean(P_centerline[1600:,1:])
fs              = 1/(P_time[1]-P_time[0])
nperseg         = len(P_data_2000)
SPL_centerline_2000  = np.zeros(np.shape(P_data_2000)[1])
 
"Calculating the Centerline SPL [dB]"
for i in range(len(SPL_centerline_2000)):    
    f, Sxx              = csd(P_data_2000[:,i],P_data_2000[:,i],fs=fs,nperseg=nperseg,scaling='spectrum')
    f_peak_idx          = np.where(np.abs(f-frequencies[2])==np.min(np.abs(f-frequencies[2])))
    f_peak              = f[f_peak_idx]
    SPL_centerline_2000[i]   = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
"plot the spectrum"
fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
ax.plot(f,np.abs(Sxx))
ax.set_yscale('log')
ax.axvline(f[f_peak_idx],color='r',linestyle='dashed')
ax.set_xlim([1e2,3e3])
ax.set_xlabel('frequency [Hz]', fontsize=30)
ax.set_title('Spectrum of {}'.format(resolution))
ax.set_ylabel('Spectrum amplitude [dB]',fontsize=30)
 
# Plot SPL in funzione della distanza
 
fig, ax = plt.subplots(1, 1, figsize=(fsize,fsize))
ax.plot(np.linspace(0,1,np.shape(P_data_800)[1])[::step_fine],SPL_centerline_800[::step_fine],color='r',linestyle='solid',linewidth=line,label='f = 800 Hz',marker='o',markerfacecolor='none',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0,1,np.shape(P_data_1400)[1])[::step_fine],SPL_centerline_1400[::step_fine],color='b',linestyle='solid',linewidth=line,label='f = 1400 Hz',marker='s',markerfacecolor='none',markersize=size, markeredgewidth=2)
ax.plot(np.linspace(0,1,np.shape(P_data_2000)[1])[::step_fine],SPL_centerline_2000[::step_fine],color='k',linestyle='solid',linewidth=line,label='f = 2000 Hz',marker='d',markerfacecolor='none',markersize=size, markeredgewidth=2)
plt.xlabel('$x/L$', fontsize=30)  # Etichetta dell'asse x
plt.ylabel(r'$\mathrm{SPL}/\mathrm{SPL}_\mathrm{max}$', fontsize=30)  # Etichetta dell'asse y
#plt.title('SPL decay along channel',fontsize=30)  # Titolo del grafico
min_spl = min(min(SPL_centerline_800), min(SPL_centerline_1400), min(SPL_centerline_2000))
max_spl = max(max(SPL_centerline_800), max(SPL_centerline_1400), max(SPL_centerline_2000))
num_yticks = 5  # Puoi impostare il numero desiderato di ticks equidistanti
# ytick_values = np.linspace(round(min_spl,1), round(max_spl,1), num_yticks)
 
# def format_y_axis(value, _):
#     return f'{value:.1f}'  # I
# plt.gca().yaxis.set_major_formatter(FuncFormatter(format_y_axis))
# #plt.gca().yaxis.set_major_formatter(FuncFormatter(format_y_axis))
 
plt.grid(True)  # Abilita la griglia di sfondo
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.legend(numpoints=1,loc='upper right',fontsize=30)
# plt.yticks(ytick_values)
 
path = '/home/angelo/Scrivania/aeroacustica/Progetto_ANEMONE/Risultati/images/SPL decay/'.format(frequencies[0])
# plt.savefig(path + 'SPL_decay_comparison_differentfrequencies.png', bbox_inches = 'tight', dpi=300)