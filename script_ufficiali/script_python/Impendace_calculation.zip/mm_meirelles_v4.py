# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 11:40:06 2022

@author: mynames
"""

"Code to calculate the liner impedance by the mode matching method"
"This code uses the H1 estimator through the Cross Spectrum Density"
"Code to process PowerACOUSTICS format"

"Import python packages"
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import csd
from scipy.signal import welch
import scipy.linalg as LA
import h5py
import scipy as sp
import matplotlib.ticker as ticker
from decimal import Decimal
from matplotlib.ticker import FormatStrFormatter


"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
# plt.rcParams.update({'font.size': 12})
# plt.rcParams["figure.dpi"] = 100
xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'down'
SPL                 = 145
Mach                = 0.32
version             = '14_1'
BCs                 = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'


def format_func(value, tick_number):
    # Formatta il valore con due cifre significative
    return f'{value:.2g}'
# =============================================================================
# IMPORT EXPERIMENTAL MM
# =============================================================================
path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/'.format(ac_source,geometry,resolution,SPL,frequencies[0])

# path_save           = '/home/angelo/Scrivania/PhD/aeroacustica/Figure_paper_AIAA'
path_save = '/home/angelo/Scrivania/PhD/aeroacustica/figure_paper_JFM/Acoustics/M=0.3/spl decay/'.format(frequencies[0])
print('sto salvando qui {}'.format(path_save))
#path_save           = path + 'impedance_results'

path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/'
exp_freqs           = np.arange(500,3100,100)
if Mach == 0.3 or Mach == 0:
    if ac_source == 'up' or ac_source == 'noflow':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]
    elif ac_source == 'down':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,5]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,15]
elif Mach == 0.32:
    if ac_source == 'up':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,4]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,5]
    elif ac_source == 'down':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,6]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7]



##DAMIANO's DATA##################

path_dam ='/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/damiano_data/'
#data_dam = np.asarray(pd.read_csv(path_dam + 'probe_11_Z_new.txt',sep=' '))[:,0]


"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'
if BCs == 'Slip':
    W                   = 0.02                                                      # duct width [m]
elif BCs == 'NoSlip':
    W                   = 0.04                                                      # duct width [m]
H                   = 0.01                                                      # duct height [m]                                                   # duct height [m]

"Liner parameters - NASA"
n_cavities          = 11                                                        # Number of liner cavities
POA                 = 6.3/100                                                   # Percentage of Open Area
cvt_height          = 38.1e-3                                                 # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                  # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                 # Orifice diameter (m)
orifice_d_min       = 1.05e-3
orifice_d_max       = 1.26e-3      
linerLength         = 136.906e-3                                                # Liner length in meters [m]


"Liner parameters - UFSC"
n_cavities_ufsc              = 11                                                        # Number of liner cavities
POA_ufsc                     = 8.75/100                                                   # Percentage of Open Area
cvt_height_ufsc              = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick_ufsc            = 0.55e-3                                                  # Face Sheet thickness (m)
orifice_d_ufsc               = 1.169250e-3                                                 # Orifice diameter (m)
linerLength_ufsc             = 136.906e-3 


"Liner parameters - Barrel"
# n_cavities          = 11                                                        # Number of liner cavities
# POA                 = 5.6/100                                                   # Percentage of Open Area
# cvt_height          = 38.5e-3                                                   # Cavity Height (m)
# fsheet_thick        = 0.8e-3                                                    # Face Sheet thickness (m)
# orifice_d           = 1e-3                                                      # Orifice diameter (m)
# linerLength         = 0.11                                                      # Liner length in meters [m]

"Flow parameters"
#MeanMach            = 0.268                                                     # Mean Mach Number
#BLDT                = 0.69e-3                                                   # Turbulent Boundary Layer Displacement Thickness
"Flow parameters - NASA V11_1"
# MeanMach            = 0.292                                                    # Mean Mach Number
# BLDT                = 7.554e-4                                                 # Turbulent Boundary Layer Thickness

"Flow parameters NASA V14"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                  # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    BLDT = 0
    MeanMach = 0

"Fluid parameters"
Pamb                = 101325                                                    # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                    # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                      # Temperature (Kelvin)
gamma               = 1.4                                                       # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                     # Prandtl
Runiv               = 8.314462                                                  # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                              # Mol. Weight of Air
R                   = Runiv/mol_weight                                          # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                       # Sound Speed
rho                 = Pamb/(R*Tk)                                               # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                 # Viscosity
cm                  = 1/2.54                                                    # Variable to plots



#############################PATH DEFINITION###################################
#%%
## =============================================================================
# BEGIN CODE
# =============================================================================
if Mach==0.32 or Mach==0.3:
    num_Mach=0.3
elif Mach==0:
    num_Mach=0

nFreq           = len(frequencies)

path_mics=       path + 'NASA_points/'.format(frequencies[0])
mic_positions   = np.loadtxt(path_mics + 'mm/Pts_MM.txt',skiprows=1)
nMics           = np.shape(mic_positions)[0]                                # Number of microphones

complex_amp     = np.zeros((nFreq,nMics),dtype=complex)
mic_SPLs        = np.zeros((nFreq,nMics))
impedance       = np.zeros(nFreq,dtype=complex)


for i in range(nFreq):
    # if ac_source == 'up':
    #     path                ='/media/angelo/Seagate Hub/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/real_geometry/fine/Acoustics/145/{}/eduction/'.format(frequencies[i])
    # elif ac_source == 'down':
    #     path                = ''
    sim_data            = np.loadtxt(path + 'eduction/mm/mm_pressure')
    
    sim_time            = sim_data[:,0]
    sim_data            = sim_data[:,1:]
    
    # for i in range(len(sim_data)):
    #     sim_data[:,i] = sim_data[i,i]-np.mean(sim_data[i,:])
    
    fs      = 1/(sim_time[1]-sim_time[0])
    nperseg = int(len(sim_data)/1)
    
    if ac_source == 'up' or ac_source == 'noflow':
        ref_mic = sim_data[:,0]
    elif ac_source == 'down':
        ref_mic = sim_data[:,-1]
    
    for mic in np.arange(nMics):
        
        "Calculate SPL on probes"
        # f, Sxx = csd(sim_data[:,mic],sim_data[:,mic],fs=fs,nperseg=nperseg,scaling='spectrum')
        f, Sxx = welch(sim_data[:,mic],fs=fs,nperseg=nperseg,scaling='spectrum')
        f_peak_idx = np.where(np.abs(f-frequencies[i])==np.min(np.abs(f-frequencies[i])))
        f_peak = f[f_peak_idx]
        mic_SPLs[i,mic] = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)
        
        if mic == 0:
            hf = h5py.File(path + 'spectrum.h5', 'w')
            hf.create_dataset('f', data=f)
            hf.create_dataset('spl', data=20*np.log10(np.sqrt(np.abs(Sxx))/2e-5))
            hf.close()
        
        if mic == 0 or mic==43 or mic == 21 or mic==22:
            fig, ax = plt.subplots(1, 1, figsize=(5,5))
            ax.plot(sim_time[:],sim_data[:,mic],color='k',linestyle='solid')
            ax.set_xlabel('Time [s]')
            ax.set_ylabel('Pressure [Pa]')
            ax.set_title('Micrphone n {}'.format(mic))
        # if mic == 0:
        #     freqs_input[i] = f_peak
        
        "Performing the cross spectrum Sxy"
        f, Sxy_mic = csd(ref_mic,sim_data[:,mic],fs=fs,nperseg=nperseg)
        f, Syy_mic = csd(sim_data[:,mic],sim_data[:,mic],fs=fs,nperseg=nperseg)
        f, Syx_mic = csd(sim_data[:,mic],ref_mic,fs=fs,nperseg=nperseg)
        f_ref, Sxx = csd(ref_mic,ref_mic,fs=fs,nperseg=nperseg)
        
        "Estimators"
        H1 = Sxy_mic[f_peak_idx]/Sxx[f_peak_idx]
        HT = (Syy_mic[f_peak_idx]-Sxx[f_peak_idx]+np.sqrt((Sxx[f_peak_idx]-Syy_mic[f_peak_idx])**2+4*np.abs(Sxy_mic[f_peak_idx])**2))/(2*Syx_mic[f_peak_idx])
    
        if estimator == 'H1':
            complex_amp[i,mic] = H1[0]                            # H1 Estimator
        elif estimator == 'HT':
            complex_amp[i,mic] = HT[0]                            # HT Estimator
    
    "plot the spectrum"
    fig, ax = plt.subplots(1, 1, figsize=(5,5))
    ax.scatter(f_peak,20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5),marker = 'x',color='r')
    
    ax.plot(f,20*np.log10(np.sqrt(np.abs(Sxx))/2e-5),color='k',linestyle='solid')
    ax.set_yscale('log')
    
    ax.set_xscale('log')
    ax.set_xlabel("Frequency [Hz]")
    ax.set_ylabel("Spectrum Amplitude [dB]", multialignment="center")
    ax.set_ylim(10,180)
# =============================================================================
# BEGIN FUNCTIONS DEFINITION
# =============================================================================

def cheb(N):
    if N == 0:
        D = 0
        x = 1
    else:
        x = np.cos(np.pi*np.arange(N+1)/N).T
        c = np.hstack((2,np.ones(N-1),2))*(-1)**np.arange(N+1)
        X = np.repeat(x,N+1).reshape(N+1,N+1)
        D_numer = np.dot(c.reshape(N+1,1),1/c.reshape(1,N+1))
        D_denom = (X - X.T) + np.eye(N+1)
        D = D_numer/D_denom
        D -= np.diag(np.sum(D.T,axis=0))
    return D,x

def filterAndSort(kz,omega,M,nModes):
    # Filter eigenvalues
    
    tol = 1e-6
    if M > 0:
    # Remove trivial solution
        mask = np.ones(len(kz), dtype=bool)
        mask[np.logical_and(np.abs(np.real(kz)) <= tol,np.abs(np.imag(kz) + 1/M) <= tol)] = False
        kz = kz[mask]
    
    mask = np.ones(len(kz), dtype=bool)
    mask[np.logical_and(np.abs(np.real(kz)) <= tol,np.abs(np.imag(kz)) <= tol)] = False
    kz = kz[mask]
    if M > 0:
    ## Identification of acoustic modes
        mask = np.ones(len(kz), dtype=bool)
        mask[np.logical_and(np.real(kz) >= omega/M - tol,np.abs(np.imag(kz) <= tol))] = False
        kz = kz[mask]
    
    # Sort eigenvalues
    kz_m = kz[np.imag(kz) > 0]
    kz_p = kz[np.imag(kz) < 0]
    
    kr_m = np.lib.scimath.sqrt((omega - M*kz_m)**2 - kz_m**2)
    kr_p = np.lib.scimath.sqrt((omega - M*kz_p)**2 - kz_p**2)
    
    I = np.argsort(kr_m)
    kr_m = kr_m[I]
    kz_m = kz_m[I]
    
    I = np.argsort(kr_p)
    kr_p = kr_p[I]
    kz_p = kz_p[I]
    
    kz_p = kz_p[:nModes]
    kz_m = kz_m[:nModes]
    
    return kz_p, kz_m

def generalizedEigenvalueProblem(D,M,omega,N):
    A11 = D@D + (omega**2)*np.eye(N+1, dtype=complex)
    A12 = np.zeros([N+1,N+1], dtype=complex)
    
    A21 = np.zeros([N+1,N+1], dtype=complex)
    A22 = np.eye(N+1, dtype=complex)
    
    A = np.concatenate((np.vstack((A11,A21)),np.vstack((A12,A22))),axis=1)
    
    B11 = 2*M*omega*np.eye(N+1, dtype=complex)
    B12  = (1-M**2)*np.eye(N+1, dtype=complex)
    
    B21 = np.eye(N+1, dtype=complex)
    B22 = np.zeros([N+1,N+1], dtype=complex)
    
    B = np.concatenate((np.vstack((B11,B21)),np.vstack((B12,B22))),axis=1)
    
    return A, B

def boundaryConditions(A,B,D,M,omega,N,BC,Z1,Z2,zeta1,zeta2):
    A[0,:] = 0
    A[N,:] = 0
    B[0,:] = 0
    B[N,:] = 0
    
    if Z1 == np.inf:
        A[N,:N+1] = D[N,:]
    else:
        if BC == 'myers1980':
            A[N,:N+1] = -D[N,:]
            A[N,N] = A[N,N] + 1j*omega/Z1
            B[N,N] = 1j*2*M/Z1
            B[N,2*N+1] = (-1j*M**2)/(omega*Z1)
        elif BC == 'auregan2001':
            A[N,:,N+1] = -D[N,:]
            A[N,N] = A[N,N] + 1j*omega/Z1
            B[N,N] = (1j*M/Z1)*(2-zeta1)
            B[N,2*N+1] = ((-1j*M**2)/(omega*Z1))*(1-zeta1)
            
    if Z2 == np.inf:
        A[0,:N+1] = D[0,:]
    else:
        if BC == 'myers1980':
            A[0,:N+1] = -D[0,:]
            A[0,0] = A[0,0] + 1j*omega/Z2
            B[0,0] = 1j*2*M/Z2
            B[0,N+1] = (-1j*M**2)/(omega*Z2)
        elif BC == 'auregan2001':
            A[0,:,N+1] = -D[0,:]
            A[0,0] = A[0,0] + 1j*omega/Z2
            B[0,0] = (1j*M/Z2)*(2-zeta2)
            B[0,N+1] = ((-1j*M**2)/(omega*Z2))*(1-zeta2)
            
    return A, B

def wavenumberCalculator(omega,M,Z1,Z2,BC,zeta1,zeta2,nModes):
    beta = np.sqrt(1-M**2)
    nVector = np.arange(0,nModes)
    
    # Hard wall
    alphaHW = nVector*np.pi/2
    kHWplus = np.zeros(nModes,dtype = complex)
    kHWminus = np.zeros(nModes,dtype = complex)
    for i in range(nModes):
        if np.sign(np.imag(np.lib.scimath.sqrt(omega**2 - (1-M**2)*alphaHW[i]**2))) == 0:
            kHWplus[i] = (np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2) - omega*M)/beta**2
            kHWminus[i] = (-np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2) - omega*M)/beta**2
        else:
            kHWplus[i] = (-np.sign(np.imag(np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2)))*np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2) - omega*M)/beta**2
            kHWminus[i] = (np.sign(np.imag(np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2)))*np.lib.scimath.sqrt(omega**2 - beta**2*alphaHW[i]**2) - omega*M)/beta**2
    
    # Lined wall
    N = 5*nModes
    D, x = cheb(N)
    
    A1, B1 = generalizedEigenvalueProblem(D, M, omega, N)
    A, B = boundaryConditions(A1, B1, D, M, omega, N, BC, Z1, Z2, zeta1, zeta2)
    
    kz, V = LA.eig(A, B)
    
    kzLWplus, kzLWminus = filterAndSort(kz, omega, M, nModes)
    kxLWplus = np.lib.scimath.sqrt( (omega - M*kzLWplus)**2 - kzLWplus**2 )
    kxLWminus = np.lib.scimath.sqrt( (omega - M*kzLWminus)**2 - kzLWminus**2 )
    
    alphaPlus = np.transpose(np.array((alphaHW, kxLWplus, alphaHW)))
    alphaMinus = np.transpose(np.array((alphaHW, kxLWminus, alphaHW)))
    
    kzPlus = np.transpose(np.array((kHWplus, kzLWplus, kHWplus)))
    kzMinus = np.transpose(np.array((kHWminus, kzLWminus, kHWminus)))
    
    return alphaPlus, alphaMinus, kzPlus, kzMinus
    

def computingIntegrals(omega,M,alpha_plus,alpha_minus,k_plus,k_minus,nModes,nSegments,Zw1,Zw2,BC,zeta1,zeta2):
    P_p = np.zeros([nModes, nModes, nSegments], dtype=complex)
    P_m = np.zeros([nModes, nModes, nSegments], dtype=complex)
    M_p = np.zeros([nModes, nModes, nSegments], dtype=complex)
    M_m = np.zeros([nModes, nModes, nSegments], dtype=complex)   
    
    if BC == 'myers1980':
        Zeff_b_p = omega*Zw1/(omega - M*k_plus[:,1])
        Zeff_b_m = omega*Zw1/(omega - M*k_minus[:,1])
        
        Zeff_t_p = omega*Zw2/(omega - M*k_plus[:,1])
        Zeff_t_m = omega*Zw2/(omega - M*k_minus[:,1])
            
    elif BC == 'auregan2001':
        Zeff_b_p = omega*Zw1/(omega - (1-zeta1)*M*k_plus[:,1])
        Zeff_b_m = omega*Zw1/(omega - (1-zeta1)*M*k_minus[:,1])
        
        Zeff_t_p = omega*Zw2/(omega - (1-zeta2)*M*k_plus[:,1])
        Zeff_t_m = omega*Zw2/(omega - (1-zeta2)*M*k_minus[:,1])
    
    if Zw1 == np.inf:
        Zeff_b_p = np.inf*np.ones(np.shape(Zeff_b_p))
        Zeff_b_m = np.inf*np.ones(np.shape(Zeff_b_m))
    elif Zw2 == np.inf:
        Zeff_t_p = np.inf*np.ones(np.shape(Zeff_t_p))
        Zeff_t_m = np.inf*np.ones(np.shape(Zeff_t_m))
        
    for s in range(nSegments):
        if s == 1:
            for m in range(nModes):
                Cm = np.exp(1j*2*alpha_plus[m,0])
                W = lambda y: np.exp(1j*alpha_plus[m,0]*y) + Cm*np.exp(-1j*alpha_plus[m,0]*y)
                
                for n in range(nModes):
                    if Zw2 == np.inf:
                        Cn_p = np.exp(-1j*2*alpha_plus[n,s])
                        Cn_m = np.exp(-1j*2*alpha_minus[n,s])
                    else:
                        Cn_p = -np.exp(-1j*2*alpha_plus[n,s])*(omega - M*k_plus[n,s] - alpha_plus[n,s]*Zeff_t_p[n])/(omega - M*k_plus[n,s] + alpha_plus[n,s]*Zeff_t_p[n])
                        Cn_m = -np.exp(-1j*2*alpha_minus[n,s])*(omega - M*k_minus[n,s] - alpha_minus[n,s]*Zeff_t_m[n])/(omega - M*k_minus[n,s] + alpha_minus[n,s]*Zeff_t_m[n])

                    fun_pressure_p = lambda y: np.exp(-1j*alpha_plus[n,s]*y) + Cn_p*np.exp(1j*alpha_plus[n,s]*y)
                    fun_pressure_m = lambda y: np.exp(-1j*alpha_minus[n,s]*y) + Cn_m*np.exp(1j*alpha_minus[n,s]*y)
                    
                    P_p[m,n,s] = (1 - M**2)*( 2*np.sin(alpha_plus[m,0] - alpha_plus[n,s])/(alpha_plus[m,0] - alpha_plus[n,s])*(1 + Cn_p*Cm) + 2*np.sin(alpha_plus[m,0] + alpha_plus[n,s])/(alpha_plus[m,0] + alpha_plus[n,s])*(Cn_p + Cm) ) + 1j*M**2/(omega - M*k_plus[n,s])*(W(-1)*fun_pressure_p(-1)/Zeff_b_p[n] + W(1)*fun_pressure_p(1)/Zeff_t_p[n])
                                
                    P_m[m,n,s] = (1 - M**2)*( 2*np.sin(alpha_minus[m,0] - alpha_minus[n,s])/(alpha_minus[m,0] - alpha_minus[n,s])*(1 + Cn_m*Cm) + 2*np.sin(alpha_minus[m,0] + alpha_minus[n,s])/(alpha_minus[m,0] + alpha_minus[n,s])*(Cn_m + Cm) ) + 1j*M**2/(omega - M*k_minus[n,s])*(W(-1)*fun_pressure_m(-1)/Zeff_b_m[n] + W(1)*fun_pressure_m(1)/Zeff_t_m[n])
                            
                    M_p[m,n,s] = (1 - M**2)*k_plus[n,s]/(omega - M*k_plus[n,s])*( 2*np.sin(alpha_plus[m,0] - alpha_plus[n,s])/(alpha_plus[m,0] - alpha_plus[n,s])*(1 + Cn_p*Cm) + 2*np.sin(alpha_plus[m,0] + alpha_plus[n,s])/(alpha_plus[m,0] + alpha_plus[n,s])*(Cn_p + Cm) ) - 1j*M/(omega - M*k_plus[n,s])*(W(-1)*fun_pressure_p(-1)/Zeff_b_p[n] + W(1)*fun_pressure_p(1)/Zeff_t_p[n])
                            
                    M_m[m,n,s] = (1 - M**2)*k_minus[n,s]/(omega - M*k_minus[n,s])*( 2*np.sin(alpha_minus[m,0] - alpha_minus[n,s])/(alpha_minus[m,0] - alpha_minus[n,s])*(1 + Cn_m*Cm) + 2*np.sin(alpha_minus[m,0] + alpha_minus[n,s])/(alpha_minus[m,0] + alpha_minus[n,s])*(Cn_m + Cm) ) - 1j*M/(omega - M*k_minus[n,s])*(W(-1)*fun_pressure_m(-1)/Zeff_b_m[n] + W(1)*fun_pressure_m(1)/Zeff_t_m[n])
        else:
            P_p[0,0,s] = (1 - M**2)*8;
            P_m[0,0,s] = (1 - M**2)*8;
            M_p[0,0,s] = (1 - M**2)*k_plus[0,s]/(omega - M*k_plus[0,s])*8;
            M_m[0,0,s] = (1 - M**2)*k_minus[0,s]/(omega - M*k_minus[0,s])*8;
            for n in np.arange(1,nModes):
                P_p[n,n,s] = (1 - M**2)*4;
                P_m[n,n,s] = (1 - M**2)*4;
                M_p[n,n,s] = (1 - M**2)*k_plus[n,s]/(omega - M*k_plus[n,s])*4;
                M_m[n,n,s] = (1 - M**2)*k_minus[n,s]/(omega - M*k_minus[n,s])*4;

    return P_p, P_m, M_p, M_m

def modeMatching(A1_plus,A3_minus,P_p,P_m,M_p,M_m,k_plus,k_minus,z1,z2,z3,nModes):
    X12 = np.concatenate((np.vstack((P_p[:,:,1],M_p[:,:,1])),np.vstack((-P_m[:,:,0],-M_m[:,:,0]))),axis=1)
    X23 = np.concatenate((np.vstack((P_p[:,:,2],M_p[:,:,2])),np.vstack((-P_m[:,:,1],-M_m[:,:,1]))),axis=1)
    Y12 = np.concatenate((np.vstack((P_p[:,:,0],M_p[:,:,0])),np.vstack((-P_m[:,:,1],-M_m[:,:,1]))),axis=1)
    Y23 = np.concatenate((np.vstack((P_p[:,:,1],M_p[:,:,1])),np.vstack((-P_m[:,:,2],-M_m[:,:,2]))),axis=1)

    E21 = np.concatenate((np.vstack((np.eye(nModes),np.zeros([nModes,nModes]))),np.vstack((np.zeros([nModes,nModes]),np.eye(nModes)))),axis=1)
    E32 = np.copy(E21)
    
    E12 = np.concatenate((np.vstack((np.diag(np.exp(-1j*k_plus[:,0]*z1)),np.zeros([nModes,nModes]))),np.vstack((np.zeros([nModes,nModes]),np.diag(np.exp(-1j*k_minus[:,1]*(z1-z2)))))),axis=1)
    E23 = np.concatenate((np.vstack((np.diag(np.exp(-1j*k_plus[:,1]*(z2-z1))),np.zeros([nModes,nModes]))),np.vstack((np.zeros([nModes,nModes]),np.diag(np.exp(-1j*k_minus[:,2]*(z2-z3)))))),axis=1)
    
    T12 = np.linalg.solve(X12@E21,Y12@E12)
    T23 = np.linalg.solve(X23@E32,Y23@E23)
    
    nIter = 5
    A2_minus = np.zeros(nModes)
    
    for j in range(nIter):
        amplitudeVector = T12@np.concatenate((A1_plus, A2_minus))
        A2_plus = amplitudeVector[0:nModes]
        A1_minus = amplitudeVector[nModes:2*nModes]
        
        amplitudeVector = T23@np.concatenate((A2_plus, A3_minus))
        A3_plus = amplitudeVector[0:nModes]
        A2_minus = amplitudeVector[nModes:2*nModes]
        
    return A1_minus,A2_plus,A2_minus,A3_plus

def computeAcousticField(omega,Aplus1,Aminus2,normRefPlane,normRefPos,normPositions,Z1,Z2,M,nMics,BC,zeta1,zeta2,K0):
    nSegments = 3
    nModes = 5
    
    A1_plus = np.zeros(nModes,dtype=complex)
    A3_minus = np.zeros(nModes,dtype=complex)
    
    A1_plus[0] = Aplus1
    A3_minus[0] = Aminus2
    
    z0 = normRefPlane[0]
    z1 = normRefPos[0]
    z2 = normRefPos[1]
    z3 = normRefPlane[1]
    
    alpha_plus,alpha_minus,k_plus,k_minus = wavenumberCalculator(omega,M,Z1,Z2,BC,zeta1,zeta2,nModes)
    P_p,P_m,M_p,M_m = computingIntegrals(omega,M,alpha_plus,alpha_minus,k_plus,k_minus,nModes,nSegments,Z1,Z2,BC,zeta1,zeta2)
    
    k_plus[0,0] = omega*K0/(1+K0*M)
    k_plus[0,2] = omega*K0/(1+K0*M)
    k_minus[0,0] = -omega*K0/(1-K0*M)
    k_minus[0,2] = -omega*K0/(1-K0*M)
    
    A1_minus,A2_plus,A2_minus,A3_plus = modeMatching(A1_plus,A3_minus,P_p,P_m,M_p,M_m,k_plus,k_minus,z1,z2,z3,nModes)
    
    x1 = normPositions[0:int(nMics/2)] - z0
    x3 = normPositions[int(nMics/2):nMics]- z2
    y1 = np.ones(int(nMics/2))
    y3 = np.ones(int(nMics/2))
    
    p1_plus = np.zeros([int(nMics/2),nModes],dtype=complex)
    p1_minus = np.zeros([int(nMics/2),nModes],dtype=complex)
    p3_plus = np.zeros([int(nMics/2),nModes],dtype=complex)
    p3_minus = np.zeros([int(nMics/2),nModes],dtype=complex)
    for i in range(nModes):
        p1_plus[:,i] = A1_plus[i]*(np.exp(1j*alpha_plus[i,0]*y1) + np.exp(-1j*alpha_plus[i,0]*(y1 - 2)))*np.exp(-1j*k_plus[i,0]*x1)
        p1_minus[:,i] = A1_minus[i]*(np.exp(1j*alpha_minus[i,0]*y1) + np.exp(-1j*alpha_minus[i,0]*(y1 - 2)))*np.exp(1j*k_minus[i,0]*(z1 - x1))
        
        p3_plus[:,i] = A3_plus[i]*(np.exp(1j*alpha_plus[i,2]*y3) + np.exp(-1j*alpha_plus[i,2]*(y3 - 2)))*np.exp(-1j*k_plus[i,2]*x3)
        p3_minus[:,i] = A3_minus[i]*(np.exp(1j*alpha_minus[i,2]*y3) + np.exp(-1j*alpha_minus[i,2]*(y3 - 2)))*np.exp(1j*k_minus[i,2]*(z3 - z2 - x3))

    p1 = np.sum(p1_plus + p1_minus,axis = 1)
    p3 = np.sum(p3_plus + p3_minus,axis = 1)
    simPressure = 2*np.concatenate([p1, p3]);

    return simPressure

    
def computeFluidProperties(Tk):
        rho                 = Pamb/(R*Tk)
        nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho
        return rho, nu
    
    
def waveDecomposition(pressure,positions,refPos,kplus,kminus):
    e = np.zeros([np.size(positions),2], dtype=complex)
    e[:,0] = 4*np.exp(-1j*kplus*(positions-refPos))
    e[:,1] = 4*np.exp(-1j*kminus*(positions-refPos))
    Pfinal = sp.linalg.pinv(e)@pressure
    pplus = Pfinal[0]
    pminus = Pfinal[1]
    return pplus, pminus
    
def computeImpedanceGuess(testFrequency, SPL, rho, nu, c0, M, BLDT):
    
    def impedanceUTAS(rho, nu, c0, POA, L, t, d, SPL, freq, M, BLthick):
        r = d/2
        omega = 2*np.pi*freq
        k = omega/c0
        pt = 2e-5*10**(SPL/20)
        epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
        Sm = -0.0000207*k/POA**2
        Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
        Ks = np.sqrt(-1j*omega/nu)
        F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
        Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
        Rcm = M/(POA*(2 + 1.256*BLthick/d))
        Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
        
        Ra = 1;
        Xa = 1;
        Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
        
        fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
        Vp = sp.optimize.fsolve(fun,Vp0)
        Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
        
        Ra = np.real(Z)
        Xa = np.imag(Z)
        return Ra, Xa
        
    ZinitialReal = np.zeros(np.shape(testFrequency))
    ZinitialImag = np.zeros(np.shape(testFrequency))
    
    for i in range(np.size(testFrequency)):
        ZinitialReal[i], ZinitialImag[i] = impedanceUTAS(rho,nu,c0,parameters[0],parameters[1],parameters[2],parameters[3],SPL,testFrequency[i],M,BLDT)
    Zinitial  = ZinitialReal + 1j*ZinitialImag
    return Zinitial

def impedanceUTAS(rho, nu, c, POA, L, t, d, SPL, freq, M, BLthick):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
    Sm = -0.0000207*k/POA**2
    Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
    Ks = np.sqrt(-1j*omega/nu)
    F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
    Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
    Rcm = M/(POA*(2 + 1.256*BLthick/d))
    Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
    
    Ra = 1;
    Xa = 1;
    Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
    
    fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
    Vp = sp.optimize.fsolve(fun,Vp0)
    Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
    
    Ra = np.real(Z)
    Xa = np.imag(Z)
    return Ra, Xa

def costFunctionEduction(x,args):
    k,pressure,nMics,M,normPositions,normRefPlane,normRefPos,normLinerLength,Aplus1,Aminus2,liningType,BC,K0 = args
    Z1 = x[0] + 1j*x[1]
    Z2 = np.inf
    zeta1 = 0
    zeta2 = 0
    simPressure = computeAcousticField(k, Aplus1, Aminus2,normRefPlane,normRefPos,normPositions,Z1,Z2,M,nMics,BC,zeta1,zeta2,K0)
    cost = np.zeros(int(2*nMics))
    count = 0
    for i in range(nMics):
        error = (pressure[i] - simPressure[i])/pressure[i]
        cost[count] = np.abs(np.real(error))
        count += 1
        cost[count] = np.abs(np.imag(error))
        count += 1   
    return cost

def impedanceCrandall(rho, nu, c, POA, L, t, d, SPL, freq,alpha):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    ks = np.sqrt((omega*rho)/nu)
    
    Z = (8 * nu * t) / (rho * c * POA * r**2) * (np.sqrt(1 + ((ks * r)**2) / 32) + (alpha * np.sqrt(2) * ks * r**2) / (2 * t)) + 1j * ((omega * t) / (c * POA) * (1 + (9 + (ks * r)**2 / 2)**(-0.5) + 2 * (8 * r) / (3 * np.pi * t)) - 1 / np.tan(k * L))
    
    Rc = np.real(Z)
    Xc = np.imag(Z)
    return Rc, Xc
# =============================================================================
# END OF FUNCTIONS DEFINITION
# =============================================================================
    
#%% Main code
# NOT NECESSARY TO CHANGE
BC = 'myers1980'     
parameters = [POA, cvt_height, fsheet_thick, orifice_d]
rho, nu = computeFluidProperties(Tk)
r = H*W/(H+W)       # duct hydraulic radius
a = W/2             # radius of the duct
frequencies = np.asarray(frequencies)
normPositions = []

for i in range(len(mic_positions)):
    normPositions.append(mic_positions[i][0]/a)
refPos = np.array([0,linerLength])
normRefPos = refPos/a - normPositions[0]+1
normPositions = np.array(normPositions)-normPositions[0]+1
normRefPlane = [0, int(np.max(normPositions))+1]
normLinerLength = linerLength/a;

MachVector = np.asarray([MeanMach]*nFreq)
Mach_flow = 1*MachVector
M = np.mean(Mach_flow)
if M == 0:
    BLDT = 0

measurements = np.zeros((nFreq,nMics),dtype=complex)
for i in np.arange(nFreq):
    measurements[i,:] = complex_amp[i]

nMicsEachSide = int(nMics/2)

# testFrequency = freqs_input
testFrequency = frequencies
omega = 2*np.pi*testFrequency
k0 = omega*a/c0

Sh = r*np.sqrt(omega/nu)
K0 = 1 + ((1 - 1j)/(Sh*np.sqrt(2)))*(1 + (gamma - 1)/np.sqrt(Pr))
kplus = k0*K0/(1 + K0*Mach_flow)
kminus = -k0*K0/(1 - K0*Mach_flow)

pressure1 = np.transpose(measurements[:,:nMicsEachSide])
pressure2 = np.transpose(measurements[:,nMicsEachSide:nMics])

Aplus1 = np.zeros(nFreq, dtype=complex)
Aminus1 = np.zeros(nFreq, dtype=complex)
Aplus2 = np.zeros(nFreq, dtype=complex)
Aminus2 = np.zeros(nFreq, dtype=complex)
for i in range(nFreq):
    
    pplus1,pminus1 = waveDecomposition(pressure1[:,i],normPositions[:nMicsEachSide],normRefPlane[0],kplus[i],kminus[i])
    pplus2,pminus2 = waveDecomposition(pressure2[:,i],normPositions[nMicsEachSide:nMics],normRefPlane[1],kplus[i],kminus[i])
    
    Aplus1[i] = pplus1
    Aminus1[i] = pminus1
    Aplus2[i] = pplus2
    Aminus2[i] = pminus2

if ac_source =='up':
    # SPL = 20*np.log10(4*np.abs(Aplus1)/20e-6)
    Re = Aminus2/Aplus2
elif ac_source == 'down':
    # SPL = 20*np.log10(4*np.abs(Aminus2)/20e-6)
    Re = Aplus1/Aminus1

Zinitial = computeImpedanceGuess(testFrequency, SPL, rho, nu, c0, M, BLDT)

impedance = np.zeros(np.shape(testFrequency),dtype = complex)
totalCost = np.zeros(np.shape(testFrequency))

initialZ = np.zeros(2)
for i in range(nFreq):  
    initialZ[0] = np.real(Zinitial[i])
    initialZ[1] = np.imag(Zinitial[i])
    args = k0[i],measurements[i,:],nMics,Mach_flow[i],normPositions,normRefPlane,normRefPos,normLinerLength,Aplus1[i],Aminus2[i],'oneLiner',BC,K0[i]
    fun = lambda x: costFunctionEduction(x, args)
    x = sp.optimize.least_squares(fun, initialZ, xtol = 1e-6, ftol = 1e-6)
    impedance[i] = x['x'][0] + 1j*x['x'][1]

    "Plotting the SPL decay"
# =============================================================================
    plot=0
# =============================================================================
    if plot==1:    
        fig, ax = plt.subplots(1, 1, figsize=(4,4))
        ax.plot(normPositions,mic_SPLs[i],color='k')
        ax.axvline(normRefPos[0],color='r')
        ax.axvline(normRefPos[1],color='r')
        ax.set_xlabel('Microphone [-]')
        ax.set_ylabel('SPL [dB]')
        fig.suptitle("SPL decay $|$ {} Hz".format(frequencies[i]))
        
# =============================================================================
# Plots and prints
# =============================================================================
np.set_printoptions(formatter={'float': lambda x: "{:.1f}".format(x)})
print('Microphone SPLs: {}'.format(mic_SPLs[0:,:]))

np.set_printoptions(formatter={'float': lambda x: "{:.2f}".format(x)})
realZ = np.real(impedance)
imagZ = np.imag(impedance)
Z = realZ + imagZ*1j

print('Z: {}'.format(np.around(Z,2)))


#%% =============================================================================
# Estimate Impedance with model
# =============================================================================
freqs_UTAS = np.arange(500,2700,100)
realZ_UTAS = np.zeros(len(freqs_UTAS))
imagZ_UTAS = np.copy(realZ_UTAS)
realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc = np.copy(realZ_UTAS)
imagZ_Crandall = np.copy(realZ_UTAS)
realZ_Crandall = np.zeros(len(freqs_UTAS))
realZ_UTAS_ufsc_min = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_min = np.copy(realZ_UTAS)
realZ_UTAS_ufsc_max = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_max = np.copy(realZ_UTAS)
for i in np.arange(len(realZ_UTAS)):
    realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA,cvt_height,fsheet_thick,orifice_d,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_Crandall[i],imagZ_Crandall[i] = impedanceCrandall(rho, nu, c0, POA_ufsc, cvt_height_ufsc, fsheet_thick_ufsc, orifice_d_ufsc, SPL, freqs_UTAS[i], 2)
    realZ_UTAS_ufsc_min[i], imagZ_UTAS_ufsc_min[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_min,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc_max[i], imagZ_UTAS_ufsc_max[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_max,SPL,freqs_UTAS[i],MeanMach,BLDT)

a = np.zeros((3, len(freqs_UTAS)))

a[0,:] = realZ_UTAS_ufsc_min

a[1,:] = realZ_UTAS_ufsc

a[2,:] = realZ_UTAS_ufsc_max

c = np.zeros((3, len(freqs_UTAS)))

c[0,:] = imagZ_UTAS_ufsc_min

c[1,:] = imagZ_UTAS_ufsc

c[2,:] = imagZ_UTAS_ufsc_max

d = np.std(c, axis =0)

b = np.std(a, axis=0)

#%% =============================================================================
# Coarse Resolution Results V14_1 - NOFLOW 145dB [800,1400,2000]
# =============================================================================
#mm_coarse = np.array([1.27-1.61j, 0.89-0.11j, 0.9 +0.88j])

#mm_rounded = np.array([0.47-2.28j,0.52-0.42j,0.46+0.68j])

#mm_sharped   = np.array([0.26-2.07j,0.26-0.06j,0.23+1.05j])

mm_real_noflow     = np.array([0.46-2.46j,0.38-0.62j,0.35+0.37j])

## FINE RESULTS NOFLOW 130dB [800,1400,2000]

#mm_sharped   = np.array([0.26-2.07j,0.26-0.06j,0.23+1.05j])

# mm_real_noflow     = np.array([0.05-2.401j,0.19-0.4j,0.18+0.37j])


## MEDIUM RESULTS M=0.3 130dB [800,1400,2000]

# mm_sharped   = np.array([3.73-1.94j,3.65+0.32j,3.53+1.01j])

# mm_real_medium     = np.array([1.73-2.89j,1.24-0.87j,0.99+0.4j])

mm_real_fine       = np.array([1.84-2.77j,1.29-0.65j,1.01+0.29j])


# Z = np.array([0.05-2.4j,0.19-0.4j,0.18+0.37j])

## FINE RESULTS M=0.3 145dB [800,1400,2000]

# mm_sharped   = np.array([2.94-2.42j,2.90-0.37j,2.39-0.59j])

# mm_real     = np.array([1.73-2.53j,1.31-0.68j,1.05+0.31j])


# mm_real_medium     = np.array([1.64-2.83j,1.39-0.64j,0.96+0.35j])

mm_real_fine       = np.array([1.73-2.53j,1.31-0.68j,1.04+0.29j])

##FINE RESULTS M=0.3 145dB down

mm_real_fine_down = np.asarray([1.81-3.32j,1.53-0.95j,1.2+0.33j])


##FINE RESULTS M=0.3 130dB down


# mm_real_fine       = np.array([1.84-2.77j,1.29-0.65j,1.01+0.29j])


# mm_real_fine_down = np.asarray([1.69-3.26j,1.36-0.7j,1.16+0.14j])


exp_freqs = np.arange(0.5,3.1,0.1)
freqs_UTAS = np.arange(0.5,2.7,0.1)

ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,4]
ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,5]

Mach = 0
ufsc_exp_realZ_noflow      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
ufsc_exp_imagZ_noflow      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,10]


fig, ax = plt.subplots(1, 1, figsize=(9,9))
ax.scatter(exp_freqs,ufsc_exp_realZ,color='b',linestyle='solid',linewidth=3)
ax.scatter(exp_freqs,ufsc_exp_realZ_up,color='r',linestyle='solid',linewidth=3)
ax.scatter(exp_freqs,ufsc_exp_realZ_noflow,color='k',linestyle='solid',linewidth=3)

# ax.plot(freq_dam/1000,res_dam,color='b',linestyle='solid',linewidth=3,label='NIT Damiano')
# ax.plot(freqs_UTAS,realZ_UTAS,color='b',linestyle='dashed',linewidth=3,label='UTAS 6.3\% POA')
# ax.plot(freqs_UTAS,realZ_UTAS_ufsc,color='k',linestyle='solid', linewidth = 3)
#x.plot(freqs_UTAS,realZ_Crandall,color='b',linestyle='dashed', linewidth = 3,label='Crandall')
#plt.errorbar(freqs_UTAS, realZ_UTAS_ufsc, yerr=b, marker='o', color='r', linestyle='dashed', linewidth=3)

# ax.scatter([0.800,1.400,2.000],np.real(mm_sharped),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3,label='nominal geometry')
#ax.scatter([0.800,1.400,2.000],np.real(mm_rounded),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='rounded edges'.format(resolution))

#ax.scatter([0.800,1.400,2.000],np.real(mm_real_medium),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='medium res.')

ax.scatter([0.800,1.400,2.000],np.real(mm_real_noflow),edgecolor='k',color='k',s=300,marker='s',facecolor='k',linewidth=3)

ax.scatter([0.800,1.400,2.000],np.real(mm_real_fine_down),edgecolor='b',color='b',s=300,marker='s',facecolor='b',linewidth=3)

ax.scatter([0.800,1.400,2.000],np.real(mm_real_fine),edgecolor='r',color='r',s=300,marker='s',facecolor='r',linewidth=3)

# ax.scatter([0.800,1.400,2.000],np.real(Z),edgecolor='r',color='r',s=250,marker='s',facecolor='w',linewidth=3, label='fine resolution')


# yticks = [0.0, 1.0, 2.0, 3.0]
xticks = [ 1.0, 1.5, 2.0, 2.5]
ax.set_xlabel("$f, kHz$", fontsize=40)
ax.set_xlim(0.5, 2.6)
ax.set_ylim(0, 2.5)
ax.set_xticks(xticks)
# ax.set_yticks(yticks)
# ax.legend(numpoints=1, loc='best', fontsize=30)
ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
ax.set_ylabel(r'$\theta$', fontsize=40)
ax.tick_params(axis='both', labelsize=40)

ax.grid(alpha=0.5)
#ax.set_title('Educed Impedance with MM\nM{} $|$ {} dB $|$ {}stream source'.format(Mach,SPL,ac_source),fontsize=30)
fig.savefig(path_save + '/MM_resistance_comparison_{}.svg'.format(SPL), dpi=300)




fig, ax = plt.subplots(1, 1, figsize=(9,9))

ax.scatter(exp_freqs,ufsc_exp_imagZ_noflow,color='k',linestyle='solid',linewidth=3,label='exp no flow')
ax.scatter(exp_freqs,ufsc_exp_imagZ_up,color='r',linestyle='solid',linewidth=3,label='exp. up')

ax.scatter(exp_freqs,ufsc_exp_imagZ,color='b',linestyle='solid',linewidth=3,label='exp. down')

# ax.plot(freq_dam/1000,reac_dam,color='b',linestyle='solid',linewidth=3,label='NIT Damiano')

# ax.plot(freqs_UTAS,imagZ_UTAS,color='b',linestyle='dashed',linewidth=3,label='UTAS 6.3\% POA')
# ax.plot(freqs_UTAS,imagZ_UTAS_ufsc,color='k',linestyle='solid',linewidth = 3,label='UTAS 8.75\% POA')
#ax.plot(freqs_UTAS,imagZ_Crandall,color='b',linestyle='dashed', linewidth = 3,label='Crandall')
#plt.errorbar(freqs_UTAS, imagZ_UTAS_ufsc, yerr=d, marker='o', color='r', linewidth=3,linestyle='dashed')
ax.scatter([0.800,1.400,2.000],np.imag(mm_real_noflow),edgecolor='k',color='k',s=300,marker='s',linewidth=3, facecolor='k',label='sim. no flow')
# ax.scatter([0.800,1.400,2.000],np.imag(mm_sharped),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3,label='nominal geometry')
#ax.scatter([0.800,1.400,2.000],np.imag(mm_rounded),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='rounded edges'.format(resolution))
ax.scatter([0.800,1.400,2.000],np.imag(mm_real_fine),edgecolor='r',color='r',s=300,marker='s',facecolor='r',linewidth=3,label='sim. up')

ax.scatter([0.800,1.400,2.000],np.imag(mm_real_fine_down),edgecolor='b',color='b',s=300,marker='s',facecolor='b',linewidth=3,label='sim. down')
#ax.scatter([0.800,1.400,2.000],np.imag(mm_real_medium),edgecolor='b',color='b',s=250,marker='s',linewidth=3, facecolor='w',label='medium res.')
# ax.scatter([0.800,1.400,2.000],np.imag(mm_real_fine_down),edgecolor='b',color='b',s=300,marker='s',linewidth=3, facecolor='b',label='sim. down')


# ax.scatter([0.800,1.400,2.000],np.imag(Z),edgecolor='r',color='r',s=250,marker='s',linewidth=3, facecolor='w',label='num. results')


ax.set_xlabel('$f, kHz$',fontsize=40)
ax.set_xlim(0.5,2.6)
ax.set_ylim(-4,2)
yticks = [-3,-2,-1,0,1,2]
ax.set_xticks(xticks, xticks)
ax.set_yticks(yticks, yticks)
ax.legend(numpoints=1,loc='lower right',fontsize=30)
ax.set_ylabel(r'$\chi$',fontsize=40)
ax.tick_params(axis='both', labelsize = 40)
ax.grid(alpha=0.5)

fig.savefig(path_save + '/MM_rreactance_comparison_{}.svg'.format(SPL), dpi=300)