# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 11:40:06 2022

@author: mynames
"""

"Code to calculate the liner impedance by the in situ technique"
"This code uses the H1 estimator through the Cross Spectrum Density"
"Code to process PowerACOUSTICS format"

"Import python packages"
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import csd
import scipy as sp
import time
import math
import h5py
from datetime import datetime
from scipy.signal import butter, filtfilt
now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'up'
SPL                 = 145
Mach                = 0
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'

nFreq           = len(frequencies)
# path = 'C:/NASA_V14/'
      
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Liner parameters - NASA"
POA                 = 6.3/100                                                  # Percentage of Open Area
cvt_height          = 38.1e-3                                                # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                 # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                # Orifice diameter (m)
nm_orifice          = 8
n_cavities          = 11

"Flow parameters"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    MeanMach = 0
    BLDT = 0

"Fluid parameters"
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                                                   # Variable to plots

# =============================================================================
# BEGIN CODE
# =============================================================================
def butter_lowpass(cutoff, fs, order=5):
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def butter_lowpass_filter(data, cutoff, fs, order=5):
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = filtfilt(b, a, data)
    return y


def round_decimals_up(number:float, decimals:int=2):
    """
    Returns a value rounded up to a specific number of decimal places.
    """
    if not isinstance(decimals, int):
        raise TypeError("decimal places must be an integer")
    elif decimals < 0:
        raise ValueError("decimal places has to be 0 or more")
    elif decimals == 0:
        return math.ceil(number)

    factor = 10 ** decimals
    return math.ceil(number * factor) / factor

def impedanceUTAS(rho, nu, c, POA, L, t, d, SPL, freq, M, BLthick):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
    Sm = -0.0000207*k/POA**2
    Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
    Ks = np.sqrt(-1j*omega/nu)
    F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
    Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
    Rcm = M/(POA*(2 + 1.256*BLthick/d))
    Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
    
    Ra = 1;
    Xa = 1;
    Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
    
    fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
    Vp = sp.optimize.fsolve(fun,Vp0)
    Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
    
    Ra = np.real(Z)
    Xa = np.imag(Z)
    return Ra, Xa

#%% =============================================================================
# loop in frequencies
# =============================================================================

for i in range(nFreq):
    
    cvt_number = 1
    
    path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/'.format(ac_source,geometry,resolution,SPL,frequencies[0])
    # else:
    #     path = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/down/NASA_UFSC-V14_1-M0.3-NoSlip_NoSlip/fine/Acoustics/145/{}/'.format(frequencies[0])
        
    
    path_mics       = path + 'NASA_points/'
    mic_positions   = np.loadtxt(path_mics + 'in_situ/Pts_contour_top_{}.txt'.format(cvt_number),skiprows=1)
    nMics           = np.shape(mic_positions)[0]                                # Number of microphones
    or_centers      = np.loadtxt(path_mics + 'in_situ/Orifice_centers_{}.txt'.format(cvt_number),skiprows=1)
    
    "Create mesh for plot"
    X, Z = np.meshgrid(np.unique(mic_positions[:,0]),np.unique(mic_positions[:,2]))
    resistance_full = np.zeros((np.shape(X)[0],np.shape(X)[1],n_cavities))
    reactance_full = np.zeros((np.shape(X)[0],np.shape(X)[1],n_cavities))
    spl_full = np.zeros((np.shape(X)[0],np.shape(X)[1],n_cavities))

    for cvt in np.arange(1,2):
        mic_SPLs        = np.zeros((nMics))
        impedance       = np.zeros((nMics),dtype=complex)
        
        print('Working on cavity {}'.format(cvt))
        cvt_number          = cvt
        tempo = time.time()
        fs_data             = np.loadtxt(path + 'in_situ/cvt_{}/cvt_{}_pressure_top_contour'.format(cvt_number,cvt_number))
        elapsed = time.time() - tempo
        print('It took {:.2f} seconds to load face sheet data.'.format(elapsed))   
        fs_time             = fs_data[:,0]
        fs_data             = fs_data[:,1:]
        bp_data             = np.loadtxt(path + 'in_situ/cvt_{}/cvt_{}_pressure_bottom'.format(cvt_number,cvt_number))[:,1]
        path_ref            = path + 'eduction/mm/'
        ref_data            = np.loadtxt(path_ref + 'mm_pressure')
        
        fs      = 1/(fs_time[1]-fs_time[0])
        nperseg = len(fs_data)
        
        if Mach == 0 or Mach == 0.0:
            BLDT = 0
            MeanMach = 0
        
        if ac_source == 'up' or ac_source == 'noflow':
            ref_mic = ref_data[:,1]
        elif ac_source == 'down':
            ref_mic = ref_data[:,-1]
        
        tempo = time.time()
        for mic in np.arange(nMics):

            "Calculating the Face Sheet SPL [dB]"
            f, Sxx_fs = csd(fs_data[:,mic],fs_data[:,mic],fs=fs,nperseg=nperseg,scaling='spectrum')
            f_peak_idx = np.where(np.abs(f-frequencies[i])==np.min(np.abs(f-frequencies[i])))
            f_peak = f[f_peak_idx]
            mic_SPLs[mic] = 20*np.log10(np.sqrt(np.abs(Sxx_fs[f_peak_idx]))/2e-5)
            
            if mic == 2373:
                Sxx_probe = Sxx_fs       
                f_probe = f
            
            "Performing the cross spectrum Sxy"
            f, Sxy_fs = csd(ref_mic,fs_data[:,mic],fs=fs,nperseg=nperseg)
            f, Syy_fs = csd(fs_data[:,mic],fs_data[:,mic],fs=fs,nperseg=nperseg)
            f, Syx_fs = csd(fs_data[:,mic],ref_mic,fs=fs,nperseg=nperseg)
            
            f, Sxy_bp = csd(ref_mic,bp_data,fs=fs,nperseg=nperseg)
            f, Syy_bp = csd(bp_data,bp_data,fs=fs,nperseg=nperseg)
            f, Syx_bp = csd(bp_data,ref_mic,fs=fs,nperseg=nperseg)
            
            f, Sxx = csd(ref_mic,ref_mic,fs=fs,nperseg=nperseg)
            
            "H1 estimators"
            H1_fs = Sxy_fs[f_peak_idx]/Sxx[f_peak_idx]
            HT_fs = (Syy_fs[f_peak_idx]-Sxx[f_peak_idx]+np.sqrt((Sxx[f_peak_idx]-Syy_fs[f_peak_idx])**2+4*np.abs(Sxy_fs[f_peak_idx])**2))/(2*Syx_fs[f_peak_idx])
            
            H1_bp = Sxy_bp[f_peak_idx]/Sxx[f_peak_idx]
            HT_bp = (Syy_bp[f_peak_idx]-Sxx[f_peak_idx]+np.sqrt((Sxx[f_peak_idx]-Syy_bp[f_peak_idx])**2+4*np.abs(Sxy_bp[f_peak_idx])**2))/(2*Syx_bp[f_peak_idx])
        
            "H_pair from Dean's theory"
            if estimator == 'H1':
                H_pair = H1_fs/H1_bp                                                    # H1 Estimator
            elif estimator == 'HT':
                H_pair = HT_fs/HT_bp   
            
            "Calculating cavity impedance"
            k0 = frequencies[i]*2*np.pi/c0   # [m] wavenumber
            impedance[mic] = -1j*H_pair/np.sin(k0*cvt_height)
        
        elapsed = time.time() - tempo
        print('It took {:.2f} seconds to loop all mics and calculate impedance.'.format(elapsed))   

        # =============================================================================
        # PREPARE DATA AND PLOT 
        # =============================================================================
        
        "Create arrays to store data over time"
        resistance = np.zeros((np.shape(X)[0],np.shape(X)[1]))
        reactance = np.zeros((np.shape(X)[0],np.shape(X)[1]))
        spl_mesh = np.zeros((np.shape(X)[0],np.shape(X)[1]))
        
        for ii in range(np.shape(X)[0]):
            for jj in range(np.shape(X)[1]):
                idx = ii*len(X)
                resistance[jj,ii] = np.real(impedance[idx+jj])
                reactance[jj,ii] = np.imag(impedance[idx+jj])
                spl_mesh[jj,ii] = mic_SPLs[idx+jj]
                        
        resistance_full[:,:,cvt-1] = resistance
        reactance_full[:,:,cvt-1] = reactance
        spl_full[:,:,cvt-1] = spl_mesh
#%%     
    cutoff_frequency = 20000  # Frequenza di taglio del filtro in Hz
    sampling_frequency = fs  # Frequenza di campionamento dei dati in Hz
    order = 5  # Ordine del filtro
    path_save = '/home/angelo/Scaricati/'
    
    # Applicazione del filtro passa-basso ai segnali
    fs_filtered = butter_lowpass_filter(fs_data[:4000,2373], cutoff_frequency, sampling_frequency, order=order)
    nperseg = len(fs_filtered)
    f,Sxx = csd(fs_filtered,fs_filtered,fs=fs,nperseg=nperseg)
    plt.loglog(f,Sxx)
    
    bp_filtered = butter_lowpass_filter(bp_data[:4000], cutoff_frequency, sampling_frequency, order=order)    
    fs_filtered_2 = butter_lowpass_filter(fs_data[:4000,7928], cutoff_frequency, sampling_frequency, order=order)
    fig, ax = plt.subplots(1, 1, figsize=(20,10))    
    ax.plot(fs_filtered-np.mean(fs_filtered), linewidth=3, label='Facesheet upstream')
    ax.plot(fs_filtered_2-np.mean(fs_filtered_2), linewidth=3,linestyle='dashed', label='Facesheet downstream')
        # Plot del secondo segnale sovrapposto
    ax.plot(bp_filtered-np.mean(bp_filtered), linewidth = 3, label='Backplate')
    
    # Aggiunta di titolo, legenda e etichette degli assi
    
    xticks = [1000,1500,2000,2500,3000,3500]
    ax.set_xlabel('$time [s]$',fontsize=40)
    ax.set_xlim(500,3900)
    ax.set_ylim(-600,600)
    ax.set_xticks(xticks, xticks)
    # yticks = [-2,-1,0,1,2]
    # ax.set_yticks(yticks, yticks)
    ax.legend(numpoints=1,loc='lower right',fontsize=40)
    ax.set_ylabel(r'p [Pa]',fontsize=40)
    ax.tick_params(axis='both', labelsize = 40)
    # fig.savefig(path_save + '/1.png', dpi=300)
    # Applicazione del filtro passa-basso ai segnali
    # fs_filtered = butter_lowpass_filter(fs_data[:4000,7928], cutoff_frequency, sampling_frequency, order=order)
    # bp_filtered = butter_lowpass_filter(bp_data[:4000], cutoff_frequency, sampling_frequency, order=order)    
    
    
    
    # fig, ax = plt.subplots(1, 1, figsize=(20,10))
    # ax.plot(fs_filtered-np.mean(fs_filtered), linewidth=3, label='Facesheet')

    #     # Plot del secondo segnale sovrapposto
    # ax.plot(bp_filtered-np.mean(bp_filtered), linewidth = 3, label='backplate')
    # # Aggiunta di titolo, legenda e etichette degli assi
    
    # # Aggiunta di titolo, legenda e etichette degli assi
    # ax.set_xlabel('$time [s]$',fontsize=40)
    # ax.set_xlim(500,4000)
    # ax.set_ylim(-600,600)
    # # ax.set_xticks(xticks, xticks)
    # # yticks = [-2,-1,0,1,2]
    # # ax.set_yticks(yticks, yticks)
    # ax.legend(numpoints=1,loc='lower right',fontsize=25)
    # ax.set_ylabel(r'$pressure [Pa]$',fontsize=40)
    # ax.tick_params(axis='both', labelsize = 40)
    # fig.savefig(path_save + '/2.png', dpi=300)
    # =============================================================================
    # save data
    # =============================================================================
    
    # hf = h5py.File(path + 'in_situ/data.h5', 'w')
    # hf.create_dataset('x', data=X)
    # hf.create_dataset('z', data=Z)
    # hf.create_dataset('resistance', data=resistance_full)
    # hf.create_dataset('reactance', data=reactance_full)
    # hf.create_dataset('spl', data=spl_full)
    # hf.close()
    
    # hf = h5py.File(path + 'in_situ/SxxProbe.h5', 'w')
    # hf.create_dataset('spl', data=20*np.log10(np.sqrt(np.abs(Sxx_probe))/2e-5))
    # hf.create_dataset('f', data=f_probe)
    # hf.close()
    


