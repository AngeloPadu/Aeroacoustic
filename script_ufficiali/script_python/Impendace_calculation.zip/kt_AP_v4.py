# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 11:40:06 2022

@author: mynames
"""

"Code to calculate the liner impedance by the Prony-like KT algorithm"
"This code uses the H1 estimator through the Cross Spectrum Density"
"Code to process PowerACOUSTICS format"

"Import python packages"




import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import csd
from scipy import interpolate
from scipy.fft import fft
import scipy as sp
import json
from matplotlib.ticker import FormatStrFormatter

#plt.rcParams.update(plt.rcParamsDefault)



"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'up'
SPL                 = 145
Mach                = 0.32
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'


######################PATH DEFINITION##########################################
path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/'.format(ac_source,geometry,resolution,SPL,frequencies[0])

#path_save           = path + 'impedance_results/'
path_save           = '/home/angelo/Scrivania/PhD/aeroacustica/Figure_paper_AIAA/'
#%%=============================================================================
# IMPORT EXPERIMENTAL KT
# =============================================================================
path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/'
exp_freqs           = np.arange(500,3100,100)
if Mach == 0.3 or Mach == 0:
    #if ac_source == 'up':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,11]
exp_freqs           = np.arange(500,3100,100)
if Mach == 0.32:
    if ac_source == 'up':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]
    elif ac_source == 'down':
        ufsc_exp_realZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2]
        ufsc_exp_imagZ      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,3]
"Case parameters"
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'
if BC == 'Slip':
    W                   = 0.02                                                      # duct width [m]
elif BC == 'NoSlip':
    W                   = 0.04                                                      # duct width [m]
H                   = 0.01                                                      # duct height [m]

"Liner parameters - NASA"
n_cavities          = 11                                                        # Number of liner cavities
POA                 = 6.3/100                                                   # Percentage of Open Area
cvt_height          = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                  # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                 # Orifice diameter (m)
orifice_d_min                = 1.05e-3
orifice_d_max                = 1.26e-3      
linerLength         = 136.906e-3                                                # Liner length in meters [m]

"Liner parameters - UFSC"
n_cavities_ufsc              = 11                                                        # Number of liner cavities
POA_ufsc                     = 8.75/100                                                   # Percentage of Open Area
cvt_height_ufsc              = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick_ufsc            = 0.55e-3                                                  # Face Sheet thickness (m)
orifice_d_ufsc               = 1.169250e-3                                                 # Orifice diameter (m)
linerLength_ufsc             = 136.906e-3                                                # Liner length in meters [m]

"Flow parameters - NASA V11_1"
# MeanMach            = 0.292                                                    # Mean Mach Number
# BLDT                = 7.554e-4                                                 # Turbulent Boundary Layer Thickness

"Flow parameters NASA V14"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    BLDT = 0
    MeanMach = 0

"Fluid parameters"
Pamb                = 101325                                                    # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                    # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                      # Temperature (Kelvin)
gamma               = 1.4                                                       # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                     # Prandtl
Runiv               = 8.314462                                                  # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                              # Mol. Weight of Air
R                   = Runiv/mol_weight                                          # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                       # Sound Speed
rho                 = Pamb/(R*Tk)                                               # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                 # Viscosity
cm                  = 1/2.54                                                    # Variable to plots

#%% =============================================================================
# BEGIN CODE
# =============================================================================
if Mach==0.32 or Mach==0.3:
    num_Mach=0.3
elif Mach==0:
    num_Mach=0

nFreq           = len(frequencies)

path_mics       = path + 'NASA_points/'.format(resolution,frequencies[0])
mic_positions   = np.loadtxt(path_mics + 'kt/Pts_Prony.txt',skiprows=1)
nMics           = np.shape(mic_positions)[0]                                # Number of microphones
deltaMics       = mic_positions[1][0]-mic_positions[0][0]                   # Distance between microphones (m)

complex_amp     = np.zeros((nFreq,nMics),dtype=complex)
mic_SPLs        = np.zeros((nFreq,nMics))
impedance       = np.zeros(nFreq,dtype=complex)



for i in range(nFreq):
    # if ac_source == 'up':
    #     path                ='/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/up/NASA_UFSC-V14_1-M0.3-NoSlip_NoSlip/{}/Acoustics/145/{}/eduction/'.format(resolution,frequencies[0])
    # elif ac_source == 'down':
    #     path                = ''
    sim_data            = np.loadtxt(path + 'eduction/kt/kt_pressure')
    
    sim_time            = sim_data[1000:4000,0]
    sim_data            = sim_data[1000:4000,1:]
    ref_data            = np.loadtxt(path + 'eduction/kt/kt_pressure')
    
    
    fs      = 1/(sim_time[1]-sim_time[0])
    nperseg = len(sim_data)/1
    
    if ac_source == 'up' or ac_source == 'noflow':
        ref_mic = ref_data[:,1]
    elif ac_source == 'down':
        ref_mic = ref_data[:,-1]
    
    for mic in np.arange(nMics):
        
        fig, ax = plt.subplots(1, 1, figsize=(5,5))
        ax.plot(sim_time[:],sim_data[:,mic],color='k',linestyle='solid')
        
        "Calculate SPL on probes"
        f, Sxx = csd(sim_data[:,mic],sim_data[:,mic],fs=fs,nperseg=nperseg,scaling='spectrum')
        f_peak_idx = np.where(np.abs(f-frequencies[i])==np.min(np.abs(f-frequencies[i])))
        f_peak = f[f_peak_idx]
        mic_SPLs[i,mic] = 20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5)

        if mic == 0:
            fig, ax = plt.subplots(1, 1, figsize=(5,5))
            ax.plot(f,20*np.log10(np.sqrt(np.abs(Sxx))/2e-5),color='k',linestyle='solid')
            ax.scatter(f_peak,20*np.log10(np.sqrt(np.abs(Sxx[f_peak_idx]))/2e-5),marker = 'x',color='r')
            ax.set_xscale('log')
            ax.set_xlabel("Frequency [Hz]")
            ax.set_ylabel("Spectrum Amplitude [dB]", multialignment="center")
            np.save('/home/angelo/Scaricati/pressure.npy', Sxx)

        "Performing the cross spectrum Sxy"
        f, Sxy_mic = csd(ref_mic,sim_data[:,mic],fs=fs,nperseg=nperseg)
        f, Syy_mic = csd(sim_data[:,mic],sim_data[:,mic],fs=fs,nperseg=nperseg)
        f, Syx_mic = csd(sim_data[:,mic],ref_mic,fs=fs,nperseg=nperseg)
        f_ref, Sxx = csd(ref_mic,ref_mic,fs=fs,nperseg=nperseg)
       
        "Estimators"
        H1 = Sxy_mic[f_peak_idx]/Sxx[f_peak_idx]
        HT = (Syy_mic[f_peak_idx]-Sxx[f_peak_idx]+np.sqrt((Sxx[f_peak_idx]-Syy_mic[f_peak_idx])**2+4*np.abs(Sxy_mic[f_peak_idx])**2))/(2*Syx_mic[f_peak_idx])
     
        if estimator == 'H1':
            complex_amp[i,mic] = H1[0]                            # H1 Estimator
        elif estimator == 'HT':
            complex_amp[i,mic] = HT[0]                            # HT Estimator
      

    "Plotting the SPL decay"
#%% =============================================================================
    plot=0
# =============================================================================
    
    if plot==1:    
      
        fig, ax = plt.subplots(1, 1, figsize=(4,4))
        ax.plot(mic_positions[:,0]*1e3,mic_SPLs[i,:],color='k')
        ax.set_xlabel('$x$ coordinate [mm]')
        ax.set_ylabel('SPL [dB]')
        fig.suptitle("KT SPL decay $|$ {} Hz $|$ {} dB $|$ M {} $|$ {}".format(frequencies[i],SPL,Mach,ac_source))
        # ax.set_ylim([137,141])
        ax.set_xlim([0,linerLength*1e3])
        
# =============================================================================
# BEGIN FUNCTIONS DEFINITION
# =============================================================================

def impedanceUTAS(rho, nu, c, POA, L, t, d, SPL, freq, M, BLDT):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
    Sm = -0.0000207*k/POA**2
    Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
    Ks = np.sqrt(-1j*omega/nu)
    F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
    Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
    Rcm = M/(POA*(2 + 1.256*BLDT/d))
    Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
    
    Ra = 1;
    Xa = 1;
    Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
    
    fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
    Vp = sp.optimize.fsolve(fun,Vp0)
    Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
    
    Ra = np.real(Z)
    Xa = np.imag(Z)
    return Ra, Xa

def impedanceCrandall(rho, nu, c, POA, L, t, d, SPL, freq,alpha):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    ks = np.sqrt((omega*rho)/nu)
    
    Z = (8 * nu * t) / (rho * c * POA * r**2) * (np.sqrt(1 + ((ks * r)**2) / 32) + (alpha * np.sqrt(2) * ks * r**2) / (2 * t)) + 1j * ((omega * t) / (c * POA) * (1 + (9 + (ks * r)**2 / 2)**(-0.5) + 2 * (8 * r) / (3 * np.pi * t)) - 1 / np.tan(k * L))
    
    Rc = np.real(Z)
    Xc = np.imag(Z)
    return Rc, Xc

class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)
    
    
class SFMimpedaceEduction(object):
    def __init__(self, MeanMach, ac_source, acousticPressure, temperature, testFrequency, algorithm='KT', micArray = 'full', deltaZ = deltaMics, b = W, h = H):
        self.MeanMach = MeanMach
        self.ac_source = ac_source
        self.acousticPressure = acousticPressure
        self.testFrequency = testFrequency
        self.algorithm = algorithm
        self.micArray = micArray
        self.deltaZ = deltaZ
        self.b = b
        self.h = h
        self.r = h*b/(h+b)
        self.a = b/2
        self.temperature = temperature
                
    def computeFluidProperties(self):
        self.c0                 = np.sqrt(gamma*R*Tk)
        self.rho                = Pamb/(R*Tk)
        self.nu = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/self.rho
        
        
    def pronyDecomposition(self, iFreq, mode = 'nominal'):
        if mode == 'nominal':
            measurements = self.acousticPressure
            a = self.a
            deltaZ = self.deltaZ
        else:
            measurements = self.pressureFieldMC
            a = self.aMC
            deltaZ = self.deltaZMC
            
        if self.micArray == 'full':
            mics = np.arange(0, np.size(measurements, axis=0))
        elif self.micArray == 'alternate':
            mics = np.arange(0, np.size(measurements, axis=0), 2)       
            
        pressureField = np.array([measurements[i] for i in mics])
        
        def createMatrices(pressureField, M, L):
            H  = sp.linalg.hankel(pressureField[1:(M-L+1)],pressureField[(M-L):M])
            b = np.transpose(pressureField[:(M-L)])
            return H, b
    
        def findAmplitudes(pressureField, M, rhos):
            LHS = np.zeros([M, np.size(rhos)], dtype = complex)
            for i in range(M):
                LHS[i,:] = np.transpose(rhos)**(i)
            RHS = np.transpose(pressureField[:M])
            A = sp.linalg.pinv(LHS)@RHS
            return A
    
        def findMDL(H,L,M):
            U, Si, Vi = sp.linalg.svd(H)
            V = np.transpose(np.conj(Vi))
            aux = np.shape(H)
            m = aux[0]
            n = aux[1]
            S = np.array([[Si[j] if i==j else 0 for j in range(n)] for i in range(m)])  
            MDL = np.zeros(L)
            diagS = np.diag(S)
            for i in range(L-1):
                MDL[i] = -(L-(i+1))*M*np.log(np.prod((diagS[i+1:L+1]**(1/(L-(i+1)))))/(1/(L-(i+1))*np.sum(diagS[i+1:L+1]))) + (i+1)*(2*L-(i+1))*np.log(M)/2
            Q = np.argmin(MDL)
            Hq = U[:,:Q]@S[:Q,:Q]@np.transpose(np.conj(V[:,:Q]))
            return Hq
        
        M = np.size(pressureField)
        if self.algorithm == 'prony':
            L = int(np.floor(M/1.5))
            H, b = createMatrices(pressureField, M, L)
            c = -sp.linalg.pinv(H)@b
        elif self.algorithm == 'least-squares':
            L = int(np.floor(3*M/8))
            H, b = createMatrices(pressureField, M, L)
            c = -sp.linalg.pinv(H)@b
        elif self.algorithm == 'KT':
            L = int(np.floor(3*M/8))
            H, b = createMatrices(pressureField, M, L)
            Hq = findMDL(H,L,M)
            c, res, rank, s = sp.linalg.lstsq(Hq,-b)
        
        rhos = np.roots(np.append(np.flipud(c), 1))
        # poles = 1/rhos
        KZ = np.log(rhos)/(-1j*deltaZ/a)    
        A = findAmplitudes(pressureField, M, rhos)    
        index = np.argmax(np.abs(A))    
        self.kz = KZ[index]    
        kz = KZ[index]
        return kz
        
    def nominalImpedanceEval(self):
        self.computeFluidProperties()
        k0 = 2*np.pi*self.testFrequency*self.a/self.c0
        Mavg = self.MeanMach
        self.Mavg = Mavg
        self.k0 = k0
        kz = np.zeros(np.size(self.k0), dtype = complex)
        kx = np.zeros(np.size(self.k0), dtype = complex)
        Z = np.zeros(np.size(self.k0), dtype = complex)
        for iFreq in range(np.size(k0)):
            self.pronyDecomposition(iFreq=iFreq)
            kz[iFreq] = self.kz
            kx[iFreq] = ((k0 - Mavg*kz)**2 - kz**2)**(1/2)
            Z[iFreq] = 1j*k0*((1-Mavg*kz/k0)**2)/(kx*np.tan(2*kx))
        self.kz = kz
        self.kx = kx
        self.Z = Z
       
    # def plotNominalImpedance(self):
    #     self.nominalImpedanceEval()
    #     fig, ax = plt.subplots()
    #     ax.plot(self.testFrequency, np.real(self.Z))
    #     ax.plot(self.testFrequency, np.imag(self.Z))

# =============================================================================
# END OF FUNCTIONS DEFINITION
# =============================================================================

#%% Main code

Z_ed         = np.asarray([])
measurements = np.zeros((1,nMics),dtype=complex)

measurements = np.zeros((nFreq,nMics),dtype=complex)
for i in np.arange(nFreq):
    measurements[i,:] = complex_amp[i]

for i in np.arange(nFreq):
    acousticPressure = measurements[i,:]
    impedance = SFMimpedaceEduction(MeanMach,ac_source,acousticPressure,Tk,frequencies[i])
    impedance.nominalImpedanceEval()
    Z_ed = np.append(Z_ed,impedance.Z)

# =============================================================================
# Plots and prints
# =============================================================================
np.set_printoptions(formatter={'float': lambda x: "{:.1f}".format(x)})
print('Microphone SPLs: {}'.format(mic_SPLs[0:,:]))

np.set_printoptions(formatter={'float': lambda x: "{:.2f}".format(x)})
realZ = np.real(Z_ed)
imagZ = np.imag(Z_ed)
Z = realZ + imagZ*1j

print('Z: {}'.format(np.around(Z,2)))

#%% =============================================================================
# Estimate Impedance with model
# =============================================================================
freqs_UTAS = np.arange(500,2700,100)
realZ_UTAS = np.zeros(len(freqs_UTAS))
imagZ_UTAS = np.copy(realZ_UTAS)
realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
imagZ_Crandall = np.copy(realZ_UTAS)
realZ_Crandall = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc = np.copy(realZ_UTAS)
imagZ_UTAS_ufsc_new = np.copy(realZ_UTAS)
realZ_UTAS_ufsc_new = np.copy(realZ_UTAS)

realZ_UTAS_ufsc_min = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_min = np.copy(realZ_UTAS)
realZ_UTAS_ufsc_max = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_max = np.copy(realZ_UTAS)
for i in np.arange(len(realZ_UTAS)):
    realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA,cvt_height,fsheet_thick,orifice_d,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,SPL,freqs_UTAS[i],MeanMach,0.0022)
    realZ_UTAS_ufsc_new[i], imagZ_UTAS_ufsc_new[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,SPL,freqs_UTAS[i],MeanMach,0.0025)

    realZ_Crandall[i],imagZ_Crandall[i] = impedanceCrandall(rho, nu, c0, POA_ufsc, cvt_height_ufsc, fsheet_thick_ufsc, orifice_d_ufsc, SPL, freqs_UTAS[i], 2)
    realZ_UTAS_ufsc_min[i], imagZ_UTAS_ufsc_min[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_min,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc_max[i], imagZ_UTAS_ufsc_max[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_max,SPL,freqs_UTAS[i],MeanMach,BLDT)


a = np.zeros((3, len(freqs_UTAS)))

a[0,:] = realZ_UTAS_ufsc_min

a[1,:] = realZ_UTAS_ufsc

a[2,:] = realZ_UTAS_ufsc_max

c = np.zeros((3, len(freqs_UTAS)))

c[0,:] = imagZ_UTAS_ufsc_min

c[1,:] = imagZ_UTAS_ufsc

c[2,:] = imagZ_UTAS_ufsc_max

d = np.std(c, axis =0)

b = np.std(a, axis=0)
# =============================================================================
# Medium Resolution Results V14_1 - M=0.3 145dB [800,1400,2000]
# =============================================================================
#kt_coarse = np.array([0.91-1.76j,0.96-0.38j,0.95+0.84j])

#kt_sharped = np.array([0.2-1.85j, 0.23+0.29j, 0.32+1.04j])
#kt_rounded = np.array([0.47-2.19j,0.73-0.48j,0.52+0.66j])

#kt_fine = np.array([0.44 -1.05j, 1.91-0.18j,3.64+0.11j])

# =============================================================================

###FINE RESOLUTION M = 0 SPL 130dB [800,1400,2000]
#kt_sharped = np.array([0.2-1.85j, 0.23+0.29j, 0.32+1.04j])

#kt_real = np.array([0.11-2.25j,0.17-0.48j,0.1+0.12j])
# =============================================================================
# Fine Resolution Results V14_1 - M=0 145dB [800,1400,2000]

#kt_real = np.array([0.35-2.31j,0.49-0.59j,0.3+0.61j])
# =============================================================================

# =============================================================================
# Fine Resolution Results V14_1 - M=0 130dB [800,1400,2000]

# kt_sharped = np.array([1.0-1.49j, 2.22-0.66j, 4.11+0.47j])

# kt_real = np.array([0.43-0.89j,1.54-0.69j,0.86+0.54j])
# =============================================================================

# Medium Resolution Results V14_1 - M=0.3 130dB [800,1400,2000]

# kt_real_medium = np.array([-0.43-0.89j,1.54-0.69j,0.86+0.54j])
# kt_real_fine = np.array([-0.01-1.48j,1.53-0.43j,1.03+0.35j])

# Fine Resolution Results V14_1 - M=0 145dB [800,1400,2000]

# kt_sharped = np.array([2.52-2.52j,2.78-0.31j,2.50+0.21j])

# kt_real = np.array([0.99-1.06j,1.29-0.47j,1.03+0.35j])


# kt_real_medium = np.array([1.08-1.58j,1.23-0.47j,0.95+0.42j])
# kt_real_fine = np.array([0.99-1.06j,1.29-0.47j,1.05+0.36j])

##FINE RESULTS M =0.3 SPL 145 dB Down

# kt_real_fine_down = np.array([1.57-2.93j,1.45-1.01j,1.38+0.19j])



##FINE RESULTS M =0.3 SPL 145 dB Down

kt_real_fine = np.array([-0.01-1.48j,1.53-0.43j,1.03+0.35j])

kt_real_fine_down = np.array([1.29-2.83j,1.49-0.97j,1.37+0.19j])


# ==========================================================

exp_freqs = np.arange(0.5,3.1,0.1)
freqs_UTAS = np.arange(0.5,2.7,0.1)

ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,0]
ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,1]

fig, ax = plt.subplots(1, 1, figsize=(9,9))
#ax.plot(exp_freqs,ufsc_exp_imagZ,color='k',linestyle='solid')
ax.scatter(exp_freqs,ufsc_exp_realZ,color='b',linestyle='solid',linewidth = 3)
ax.scatter(exp_freqs,ufsc_exp_realZ_up,color='r',linestyle='solid',linewidth = 3)
ax.scatter(freqs_UTAS,realZ_UTAS_ufsc_new,color='k',linestyle='dashed',linewidth = 3)

#ax.plot(freqs_UTAS,imagZ_UTAS,color='tab:gray',linestyle='dashed')
#ax.plot(freqs_UTAS,realZ_UTAS,color='b',linestyle='dashed', linewidth = 3,label='UTAS 6.3\% POA')
ax.plot(freqs_UTAS,realZ_UTAS_ufsc,color='k',linestyle='solid', linewidth = 3)
#ax.plot(freqs_UTAS,realZ_Crandall,color='b',linestyle='dashed', linewidth = 3,label='Crandall')
#plt.errorbar(freqs_UTAS, realZ_UTAS_ufsc, yerr=b, marker='o', color='r', linestyle='dashed', linewidth=3)

#ax.scatter([0.800,1.400,2.000],np.real(kt_coarse),edgecolor='gray',color='gray',s=250,marker='^',facecolor='w',linewidth=3, label='coarse res.')
#ax.scatter([0.800,1.400,2.000],np.real(kt_sharped),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='nominal geometry')
#ax.scatter([0.800,1.400,2.000],np.real(kt_rounded),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label=' rounded edges')
#ax.scatter([0.800,1.400,2.000],np.real(kt_real_medium),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='medium res.')
ax.scatter([0.800,1.400,2.000],np.real(kt_real_fine),edgecolor='r',color='r',s=300,marker='s',facecolor='r',linewidth=3)
ax.scatter([0.800,1.400,2.000],np.real(kt_real_fine_down),edgecolor='b',color='b',s=300,marker='s',facecolor='b',linewidth=3)

#ax.scatter(frequencies,np.imag(Z),edgecolor='k',color='k',s=80,marker='x',label='veryfine res. - imagZ')

yticks = [0.0, 1.0, 2.0, 3.0]
xticks = [ 1.0, 1.5, 2.0, 2.5]
ax.set_xlabel("$f, kHz$", fontsize=40)
ax.set_xlim(0.5, 2.6)
ax.set_ylim(0.0, 3.5)
ax.set_xticks(xticks)
ax.set_yticks(yticks)
# ax.legend(numpoints=1, loc='best', fontsize=30)
ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
ax.set_ylabel(r'$\theta$', fontsize=40)
ax.tick_params(axis='both', labelsize=40)

# fig.savefig(path_save + '/KT_resistance_comparison.png', dpi=650)


fig, ax = plt.subplots(1, 1, figsize=(9,9))


ax.scatter(exp_freqs,ufsc_exp_imagZ,color='b',linestyle='solid',linewidth = 3, label='exp down')
ax.scatter(exp_freqs,ufsc_exp_imagZ_up,color='r',linestyle='solid',linewidth = 3, label='exp up')

#ax.plot(freqs_UTAS,imagZ_UTAS,color='b',linestyle='dashed',linewidth = 3,label='UTAS 6.3\% POA')
ax.plot(freqs_UTAS,imagZ_UTAS_ufsc,color='k',linestyle='solid',linewidth = 3,label='UTAS 8.75\% POA')
#ax.plot(freqs_UTAS,imagZ_Crandall,color='b',linestyle='dashed', linewidth = 3,label='Crandall')
#plt.errorbar(freqs_UTAS, imagZ_UTAS_ufsc, yerr=d, marker='o', color='r', linewidth=3,linestyle='dashed')

#ax.scatter([0.800,1.400,2.000],np.imag(kt_coarse),edgecolor='gray',color='gray',s=250,marker='^',facecolor='w',linewidth=3, label='coarse res.')
#ax.scatter([0.800,1.400,2.000],np.imag(kt_sharped),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label='nominal geometry')
#ax.scatter([0.800,1.400,2.000],np.imag(kt_rounded),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3, label=' rounded edges')
#ax.scatter([0.800,1.400,2.000],np.imag(kt_real_medium),edgecolor='b',color='b',s=250,marker='s',linewidth=3, facecolor='w',label='medium res.')
ax.scatter([0.800,1.400,2.000],np.imag(kt_real_fine),edgecolor='r',color='r',s=300,marker='s',linewidth=3, facecolor='r',label='sim. up')
ax.scatter([0.800,1.400,2.000],np.imag(kt_real_fine_down),edgecolor='b',color='b',s=300,marker='s',facecolor='b',linewidth=3, label='sim. down')


ax.set_xlabel("$f, kHz$",fontsize=40)

ax.set_ylim(-3,2)
ax.set_xticks(xticks, xticks)
ax.set_xlim(0.5,2.6)
ax.set_ylim(-4,2)
yticks = [-3,-2,-1,0,1,2]
ax.set_yticks(yticks, yticks)
ax.legend(numpoints=1,loc='lower right',fontsize=30)
ax.set_ylabel(r'$\chi$',fontsize=40)
ax.tick_params(axis='both', labelsize = 40)
#ax.grid(True)
#ax.set_title('Educed Impedance with KT\nM{} $|$ {} dB $|$ {}stream source'.format(Mach,SPL,ac_source),fontsize=30)

# fig.savefig(path_save + '/KT_reactance_comparison.png', dpi=650)

