# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 11:40:06 2022

@author: mynames
"""

"Code to calculate the liner impedance by the in situ technique"
"This code uses the H1 estimator through the Cross Spectrum Density"
"Code to process PowerACOUSTICS format"

"Import python packages"
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import math
import h5py
from scipy.signal import csd
from datetime import datetime
import pandas as pd
import matplotlib.ticker as ticker
import csv
import os
from matplotlib.ticker import FormatStrFormatter

now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Times New Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'down'
SPL                 = 145
Mach                = 0.3
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'

nFreq           = len(frequencies)
      
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Liner parameters - NASA"
POA                 = 6.3/100                                                  # Percentage of Open Area
cvt_height          = 38.1e-3                                                # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                 # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                # Orifice diameter (m)
nm_orifice          = 8
n_cavities          = 11
cvt_width_m         = 12.446e-3


"Liner parameters - UFSC"
n_cavities_ufsc              = 11                                                        # Number of liner cavities
POA_ufsc                     = 8.75/100                                                   # Percentage of Open Area
cvt_height_ufsc              = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick_ufsc            = 0.55e-3                                                  # Face Sheet thickness (m)
orifice_d_ufsc               = 1.169250e-3                                              # Orifice diameter (m)
orifice_d_min                = 1.05e-3
orifice_d_max                = 1.26e-3                                                 
linerLength_ufsc             = 136.906e-3 


"Flow parameters"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    MeanMach = 0
    BLDT = 0
    
"Fluid parameters"
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                                                   # Variable to plots


######################PATH Definition########################
path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/in_situ'.format(ac_source,geometry,resolution,SPL,frequencies[0])

path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/'

if not os.path.exists(path + '_results'):
    # Se non esiste, creala
    os.makedirs(path + '_results')
    
else:
    print(f'La cartella esiste già in: {path}')

    
# path_save = '/home/angelo/Scrivania/PhD/aeroacustica/Figure_paper_AIAA/mesh convergence/impedance/145/'
path_save = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/in_situ_results/'.format(ac_source,geometry,resolution,SPL,frequencies[0])
# =============================================================================
# BEGIN CODE
# =============================================================================

def round_decimals_up(number:float, decimals:int=2):
    """
    Returns a value rounded up to a specific number of decimal places.
    """
    if not isinstance(decimals, int):
        raise TypeError("decimal places must be an integer")
    elif decimals < 0:
        raise ValueError("decimal places has to be 0 or more")
    elif decimals == 0:
        return math.ceil(number)

    factor = 10 ** decimals
    return math.ceil(number * factor) / factor



def impedanceUTAS(rho, nu, c, POA, L, t, d, SPL, freq, M, BLthick):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    epsilon = (1 - 0.7*np.sqrt(POA))/(1 + 305*M**3)
    Sm = -0.0000207*k/POA**2
    Cd = 0.80695*np.sqrt(POA**(0.1)/np.exp(-0.5072*t/d))
    Ks = np.sqrt(-1j*omega/nu)
    F = 1 - 2*sp.special.jv(1,Ks*r)/(Ks*r*sp.special.jv(0,Ks*r))
    Zof = 1j*omega*(t + epsilon*d)/(c0*POA)/F
    Rcm = M/(POA*(2 + 1.256*BLthick/d))
    Sr = 1.336541*(1 - POA**2)/(2*c0*Cd**2*POA**2)
    
    Ra = 1;
    Xa = 1;
    Vp0 = pt/(rho*c0*np.sqrt(Xa**2+Ra**2))
    
    fun = lambda x: x - pt/(rho*c0*np.abs(Zof + Sr*x + Rcm + 1j*(Sm*x - (1/np.tan(k*L)))))
    Vp = sp.optimize.fsolve(fun,Vp0)
    Z = Zof + Sr*Vp + Rcm + 1j*(Sm*Vp - (1/np.tan(k*L)))
    
    Ra = np.real(Z)
    Xa = np.imag(Z)
    return Ra, Xa



def impedanceCrandall(rho, nu, c, POA, L, t, d, SPL, freq,alpha):
    r = d/2
    omega = 2*np.pi*freq
    k = omega/c0
    pt = 2e-5*10**(SPL/20)
    ks = np.sqrt((omega*rho)/nu)
    
    Z = (8 * nu * t) / (rho * c * POA * r**2) * (np.sqrt(1 + ((ks * r)**2) / 32) + (alpha * np.sqrt(2) * ks * r**2) / (2 * t)) + 1j * ((omega * t) / (c * POA) * (1 + (9 + (ks * r)**2 / 2)**(-0.5) + 2 * (8 * r) / (3 * np.pi * t)) - 1 / np.tan(k * L))
    
    Rc = np.real(Z)
    Xc = np.imag(Z)
    return Rc, Xc


def trova_punti_circonferenza(raggio, centro):
    # Calcola gli angoli equispaziati
    angoli = np.linspace(0, 2*np.pi, 7, endpoint=False)
    
    # Calcola le coordinate dei punti sulla circonferenza
    punti_x = centro[0] + raggio * np.cos(angoli)
    punti_y = centro[1] + raggio * np.sin(angoli)
    
    # Ritorna le coordinate dei punti
    return list(zip(punti_x, punti_y))


# =============================================================================
# Import data
# =============================================================================



    
or_centers      = np.loadtxt('/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/NASA_points/in_situ/Orifice_centers_1.txt'.format(ac_source,geometry,resolution,SPL,frequencies[0]),skiprows=1)

hf = h5py.File(path + '/data.h5', 'r')
X = np.array(hf.get('x'))
Z = np.array(hf.get('z'))
resistance_full = np.array(hf.get('resistance'))
reactance_full = np.array(hf.get('reactance'))
spl_full = np.array(hf.get('spl'))

# =============================================================================
# Plot entire liner with divisions
# =============================================================================
partition_thick = 0.1
cvt_width = 0.49
scale = 0.975
pad = 1

fig, ax = plt.subplots(1, 1, figsize=(6,1.5))
im = plt.imread("/media/angelo/results/Progetto_ANEMONE/useful_files/liner_empty_for_contour.png")
im=ax.imshow(im)
xLen = im._extent[1]
yLen = im._extent[2]
cvt_len = xLen/11
x0 = partition_thick/2/cvt_width*cvt_len
y0 = partition_thick/2/cvt_width*yLen
deltaX = X[0,1]-X[0,0]
deltaZ = Z[1,0]-Z[0,0]
cvt_len = (cvt_width-partition_thick)/cvt_width*cvt_len*scale
plt.close()

im = plt.imread("/media/angelo/results/Progetto_ANEMONE/useful_files/liner_empty_for_contour.png")

# =============================================================================
# Plot entire liner withOUT divisions
# =============================================================================
partition_thick = 0.1
cvt_width = 0.49
scale = 0.975
pad = 1
linew = 1
lines = 'solid'

# =============================================================================
# Resistance
# =============================================================================

############ PER UN CONFRONTO DIVERSO 
mean_res = np.mean(resistance_full[60,:])
# minLim = -np.mean(resistance_full[60,:])/2
# maxLim = np.mean(resistance_full[60,:])/2

minLim = 0.9*np.min(resistance_full[60,:])
maxLim = 1.005*np.max(resistance_full[60,:])

fig, ax = plt.subplots(1, 1, figsize=(6,1.5))

x0 = 0
y0 = 0
cvt_len = xLen/11


num_ticks = 3
#tick_values = np.linspace(minLim, maxLim, num_ticks, endpoint=True)
tick_values = np.linspace(np.min(resistance_full[60,:,0]),np.max(resistance_full[60,:,0]),3, endpoint=True)
theta_symbol = r'$\theta$'

for kk in range(1,12):
    ctur = ax.pcolormesh(x0+pad+(X/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(Z/np.max(Z)*cvt_len), resistance_full[:,:,kk-1], cmap='bwr',vmin=minLim, vmax=maxLim, shading='gouraud')
    if kk == 1:
        cbar = plt.colorbar(ctur,extend='both',location='bottom',ticks=tick_values)
        cbar.ax.xaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))
        cbar.ax.tick_params(labelsize=12)
        cbar.ax.xaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))
        print("Impedenza min{:.2f} max{:.2f}".format(np.min(resistance_full[60,:,10]), np.max(resistance_full[60,:,10])))
        ################### Imposta il simbolo come etichette
        
        tick_labels = [f"{theta_symbol}{label}" for label in cbar.ax.get_xticks()]
        cbar.ax.set_xticklabels(tick_values)
        cbar.ax.set_xticklabels([r'-$\theta_{mean}$/2',r'$\theta_{mean}$', r'$\theta_{mean}$/2'], minor=False)
        # cbar = plt.colorbar(ctur, extend='both', location='bottom',ticks=np.round(np.linspace(minLim, maxLim, 3, endpoint=True),1))
        # cbar.ax.tick_params(labelsize=12)

        # Formattazione degli assi della barra dei colori
      
        cbar.ax.tick_params(labelsize=12)
    if True == True:
        for orifice_id in np.arange(nm_orifice):
            circle1 = plt.Circle((x0+pad+(or_centers[orifice_id,0]/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(or_centers[orifice_id,2]/np.max(Z)*cvt_len)), radius=orifice_d_ufsc/2/np.max(X)*cvt_len, edgecolor='black', facecolor='black')

            ax.add_patch(circle1)
    
ax.imshow(im,zorder=1)




#ax.set_title('Contour Plot of Resistance \n M{} $|$ {} dB $|$ $|$ {} Hz $|$ {}stream source'.format(Mach,SPL,frequencies[0],ac_source))
ax.axis('off')

plt.savefig(path_save + 'Resistance_counterplot.png', bbox_inches = 'tight', dpi=300)

#%% =============================================================================
# Reactance
# =============================================================================
mean_reac = np.mean(reactance_full[60,:])


# minLim = 1.05*np.min(reactance_full[60,:])
# maxLim = -0.7*np.max(reactance_full[60,:])

minLim = np.mean(reactance_full[60,:])/2
maxLim = -np.mean(reactance_full[60,:])/2

fig, ax = plt.subplots(1, 1, figsize=(6,1.5))


num_ticks = 3
tick_values = np.linspace(minLim, maxLim, num_ticks, endpoint=True)
for kk in range(1,12):
    ctur = ax.pcolormesh(x0+pad+(X/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(Z/np.max(Z)*cvt_len), reactance_full[:,:,kk-1]-np.mean(reactance_full[60,:]),cmap='bwr',vmin=minLim, vmax=maxLim, shading='gouraud')
    if kk ==1:
        cbar = plt.colorbar(ctur,extend='both',location='bottom',ticks=tick_values)
        tick_labels = [f"{theta_symbol}{label}" for label in cbar.ax.get_xticks()]
        cbar.ax.set_xticklabels(tick_labels)
        cbar.ax.set_xticklabels([r'$\chi_{mean}$/2',r'$\chi_{mean}$', r'-$\chi_{mean}$/2'], minor=False)
        print("Impedenza min{:.2f} max{:.2f}".format(np.min(reactance_full[60,:,10]), np.max(reactance_full[60,:,10])))
        # cbar = plt.colorbar(ctur, extend='both', location='bottom',ticks=np.round(np.linspace(minLim, maxLim, 5),1))
        # cbar.ax.tick_params(labelsize=12)

    if True == True:
        for orifice_id in np.arange(nm_orifice):
            circle1 = plt.Circle((x0+pad+(or_centers[orifice_id,0]/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(or_centers[orifice_id,2]/np.max(Z)*cvt_len)), radius=orifice_d_ufsc/2/np.max(X)*cvt_len, edgecolor='black', facecolor='black')

            ax.add_patch(circle1)
    
ax.imshow(im,zorder=1)

ax.axis('off')
#ax.set_title('Contour Plot of Reactance \n M{} $|$ {} dB $|$ {} Hz $|${}stream source'.format(Mach,SPL,frequencies[0],ac_source))



plt.savefig(path_save + 'Reactance_counterplot.png', bbox_inches = 'tight', dpi=300)


#%% =============================================================================
# SPL
# =============================================================================

minLim = 1.005*np.min(spl_full[60,:])
maxLim = 1*np.max(spl_full[60,:])


# minLim = 113
# maxLim = 130

fig, ax = plt.subplots(1, 1, figsize=(6,1.5))

num_ticks = 5
tick_values = np.linspace(minLim, maxLim, num_ticks, endpoint=True)

for kk in range(1,12):
    ctur = ax.pcolormesh(x0+pad+(X/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(Z/np.max(Z)*cvt_len), spl_full[:,:,kk-1], cmap='bwr',vmin=minLim, vmax=maxLim, shading='gouraud')
    if kk == 1:
        cbar = plt.colorbar(ctur,extend='both',location='bottom',ticks=tick_values)
        cbar.ax.xaxis.set_major_formatter(ticker.FormatStrFormatter("%.0f"))
        cbar.ax.tick_params(labelsize=12)
    if True == True:
        for orifice_id in np.arange(nm_orifice):
            circle1 = plt.Circle((x0+pad+(or_centers[orifice_id,0]/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(or_centers[orifice_id,2]/np.max(Z)*cvt_len)), radius=orifice_d_ufsc/2/np.max(X)*cvt_len, edgecolor='black', facecolor='none')

            ax.add_patch(circle1)
ax.imshow(im,zorder=1)

ax.axis('off')
#ax.set_title('Contour Plot of SPL \n M{} $|$ {} dB $|$ {} Hz $|$ {}stream source'.format(Mach,SPL,frequencies[0],ac_source))



plt.savefig(path_save + 'SPL_counterplot.png', bbox_inches = 'tight', dpi=300)

# =============================================================================
# LINE PLOTS
# =============================================================================

# Z for line plot is index 60
idx = 50
idx1 = 83

meas_x_idx = 23
meas_x_idx_1 = 77
meas_x_idx_after = len(X)-meas_x_idx
meas_z_idx = int(len(Z)/2)

fig, ax = plt.subplots(1, 1, figsize=(6,1.5))
ax.imshow(im)
for kk in range(1,12):
    for orifice_id in np.arange(nm_orifice):
        circle1 = plt.Circle((x0+pad+(or_centers[orifice_id,0]/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(or_centers[orifice_id,2]/np.max(Z)*cvt_len)), radius=orifice_d/2/np.max(X)*cvt_len, color='k')
        ax.add_patch(circle1)
#ax.axhline(y0+pad+(Z[idx,0]/np.max(Z)*cvt_len),color='k')
#ax.axhline(y0+pad+(Z[idx1,0]/np.max(Z)*cvt_len),color='green')
ax.scatter(X[0,meas_x_idx]/np.max(X)*cvt_len,Z[meas_z_idx,0]/np.max(X)*cvt_len,s=40,color='r',marker='s')
ax.scatter(X[0,meas_x_idx_1]/np.max(X)*cvt_len,Z[meas_z_idx,0]/np.max(X)*cvt_len,s=40,color='b',marker='^')
#ax.scatter((X[0,len(X)-meas_x_idx]+10*cvt_width_m)/np.max(X)*cvt_len,Z[meas_z_idx,0]/np.max(X)*cvt_len,s=100,color='r',marker='x')
# plt.show()
ax.axis('off')



plt.savefig(path_save + 'where_sample.png', bbox_inches = 'tight', dpi=300)

# =============================================================================
# Resistance Line Plot
# =============================================================================

cvt_width_mm = cvt_width*25.4
partition_thick_mm = 0.1*25.4
linerLength = 136.906
xticks = ['$0$','$L/2$','$L$']
xticks_loc = [0,linerLength/2,linerLength]
linew = 0.5
alpha=0.5

fig, ax = plt.subplots(1, 1, figsize=(20,5))
ax.grid(alpha=alpha)



y_min = 0.005*np.min(resistance_full[60,:])
y_max = 1.2*np.max(resistance_full[60,:])  # Assumendo che linerLength sia definito altrove nel codice
yticks_loc = np.linspace(y_min, y_max, num_ticks)


with open('resistance.txt', 'w') as file:
    for kk in range(1,12):
        
        "estimate with UTAS for the cavity spl"
        realZ_UTAS = np.zeros(len(X))
        imagZ_UTAS = np.copy(realZ_UTAS)
    
        for i in np.arange(len(X)):
            realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height,fsheet_thick_ufsc,orifice_d_ufsc,spl_full[60,i,kk-1],frequencies[0],MeanMach,BLDT)
            
        
        if kk == 1:
            ax.scatter(np.mean(X[60, :] * 1e3 + (kk - 1) * cvt_width_mm), np.mean(resistance_full[60, :, kk - 1]), marker='o',s=200, color='k', zorder=0, label='Mean value simulation ')
            #ax.scatter(np.mean(X[83, :] * 1e3 + (kk - 1) * cvt_width_mm), np.mean(resistance_full[83, :, kk - 1]), marker='o', color='green', zorder=0, label='Mean Value Simulation Data line 2')
            ax.plot(X[60, :] * 1e3 + (kk - 1) * cvt_width_mm, resistance_full[60, :, kk - 1], color='r', zorder=0, linewidth =3, label='Simulation data')
            ax.plot(X[60, :] * 1e3 + (kk - 1) * cvt_width_mm, realZ_UTAS, color='b', zorder=0, linewidth =3, label='Semi-empirical model')
        else:
            ax.scatter(np.mean(X[60,:]*1e3+(kk-1)*cvt_width_mm),np.mean(resistance_full[60,:,kk-1]),marker='o',s=200,color='k',zorder=0)
            #ax.scatter(np.mean(X[83, :] * 1e3 + (kk - 1) * cvt_width_mm), np.mean(resistance_full[83, :, kk - 1]), marker='o', color='green', zorder=0)
            ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,resistance_full[60,:,kk-1],color='r',zorder=0, linewidth =3)
            ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,realZ_UTAS,color='b',zorder=0, linewidth =3)
            ax.axvspan((kk-1)*cvt_width_mm, partition_thick_mm+(kk-1)*cvt_width_mm, color='w', zorder=2, linewidth =3)
            ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2, linewidth =3)
            ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
            ax.axvline((kk-1)*cvt_width_mm+partition_thick_mm,color='k',zorder=2,linewidth=linew)
   
    kk = 12
    ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2)
    ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
    ax.set_xlim(0,linerLength)
    ax.set_ylim(0.005*np.min(resistance_full[60,:]),1.2*np.max(resistance_full[60,:]))
    #ax.set_yticks([1,1.5,2,2.5], ['1.0','1.5','2.0','2.5'])
    ax.set_ylabel(r'$\theta$',fontsize=30)
    ax.set_xlabel('$x$ Coordinate',fontsize=30)
    ax.set_xticks(xticks_loc, xticks)
    yticks_labels = ['{:.2f}'.format(y) for y in yticks_loc]

    # Impostare i ticks sull'asse x
    plt.yticks(yticks_loc, yticks_labels, fontsize=30)
    ax.legend(numpoints=1,loc='lower left',fontsize=25)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
   

   

    plt.savefig(path_save + 'In-Situ_resistance.png', bbox_inches = 'tight', dpi=300)
   
    # file.write(f'kk = {kk}\n')
    # file.write('X values:\n')
    # np.savetxt(file, X[60, :])
    # file.write('Resistance values:\n')
    # np.savetxt(file, resistance_full[60, :, kk - 1])
    # file.write('RealZ_UTAS values:\n')
    # np.savetxt(file, realZ_UTAS)
    # file.write('\n')


# Apri il file CSV in modalità scrittura

# Close the file
# =============================================================================
# Reactance Line Plot
# =============================================================================

fig, ax = plt.subplots(1, 1, figsize=(20,5))
ax.grid(alpha=alpha)

num_ticks = 5

# Generare un intervallo di valori sull'asse x
y_min = np.min(reactance_full[60,:])
y_max = 0.9*np.max(reactance_full[60,:])  # Assumendo che linerLength sia definito altrove nel codice
yticks_loc = np.linspace(y_min, y_max, num_ticks)

# Convertire i valori in stringhe per le etichette dei ticks


with open('reactance.txt', 'w') as file:
    for kk in range(1,12):
       "estimate with UTAS for the cavity spl"
       realZ_UTAS = np.zeros(len(X))
       imagZ_UTAS = np.copy(realZ_UTAS)
       for i in np.arange(len(X)):
           realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA,cvt_height,fsheet_thick_ufsc,orifice_d_ufsc,spl_full[60,i,kk-1],frequencies[0],MeanMach,BLDT)
       
        
       if kk == 1:
           ax.scatter(np.mean(X[60,:]*1e3+(kk-1)*cvt_width_mm),np.mean(reactance_full[60,:,kk-1]),marker='o',s=200,color='k',zorder=0,label = 'Mean value simulation')
           #ax.scatter(np.mean(X[83, :] * 1e3 + (kk - 1) * cvt_width_mm), np.mean(reactance_full[83, :, kk - 1]), marker='o', color='green', zorder=0, label='Mean Value Simulation Data line 2')
           ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,reactance_full[60,:,kk-1],color='r',zorder=0, label = 'Simulation data', linewidth =3)
           ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,imagZ_UTAS,color='b',zorder=0, label = 'Semi-empirical model', linewidth =3)
       else:
           ax.scatter(np.mean(X[60,:]*1e3+(kk-1)*cvt_width_mm),np.mean(reactance_full[60,:,kk-1]),marker='o',s=200,color='k',zorder=0, linewidth =3)
           #ax.scatter(np.mean(X[83, :] * 1e3 + (kk - 1) * cvt_width_mm), np.mean(reactance_full[83, :, kk - 1]), marker='o', color='green', zorder=0)
           ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,reactance_full[60,:,kk-1],color='r',zorder=0, linewidth =3)
           ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,imagZ_UTAS,color='b',zorder=0, linewidth =3)
           ax.axvspan((kk-1)*cvt_width_mm, partition_thick_mm+(kk-1)*cvt_width_mm, color='w', zorder=2, linewidth =3)
           ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2, linewidth =3)
           ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
           ax.axvline((kk-1)*cvt_width_mm+partition_thick_mm,color='k',zorder=2,linewidth=linew)
    kk = 12
    ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2)
    ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
    ax.set_xlim(0,linerLength)
    ax.set_ylim(np.min(reactance_full[60,:]),0.9*np.max(reactance_full[60,:]))
    ax.set_ylabel(r'$\chi$',fontsize=30)
    ax.set_xlabel('$x$ Coordinate',fontsize=30)
    ax.set_xticks(xticks_loc, xticks)
    yticks_labels = ['{:.2f}'.format(y) for y in yticks_loc]

    # Impostare i ticks sull'asse x
    plt.yticks(yticks_loc, yticks_labels, fontsize=30)
    ax.legend(numpoints=1,loc='upper left',fontsize=25)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    
    
    # file.write(f'kk = {kk}\n')
    # file.write('X values:\n')
    # np.savetxt(file, X[60, :])
    # file.write('Reactance values:\n')
    # np.savetxt(file, reactance_full[60, :, kk - 1])
    # file.write('imagZ_UTAS values:\n')
    # np.savetxt(file, imagZ_UTAS)
    # file.write('\n')

plt.savefig(path_save + 'In-Situ_reactance.png', bbox_inches = 'tight', dpi=300)

# =============================================================================
# SPL Line Plot
# =============================================================================

fig, ax = plt.subplots(1, 1, figsize=(20,5))
ax.grid(alpha=alpha)
with open('spl.txt', 'w') as file:
    for kk in range(1,12):   
        
        if kk == 1:
            ax.scatter(np.mean(X[60,:]*1e3+(kk-1)*cvt_width_mm),np.mean(spl_full[60,:,kk-1]),marker='o',s=200,color='k',zorder=0, label = 'Mean Value Simulation Data')
            ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,spl_full[60,:,kk-1],color='r',zorder=0, linewidth =3, label = 'Simulation aata')
        else:
            ax.scatter(np.mean(X[60,:]*1e3+(kk-1)*cvt_width_mm),np.mean(spl_full[60,:,kk-1]),marker='o',s=200,color='k',zorder=0, linewidth =3)
            ax.plot(X[60,:]*1e3+(kk-1)*cvt_width_mm,spl_full[60,:,kk-1],color='r',zorder=0, linewidth =3)
            ax.axvspan((kk-1)*cvt_width_mm, partition_thick_mm+(kk-1)*cvt_width_mm, color='w', zorder=2, linewidth =3)
            ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2, linewidth =3)
            ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
            ax.axvline((kk-1)*cvt_width_mm+partition_thick_mm,color='k',zorder=2,linewidth=linew)
    kk = 12
    ax.axvspan((kk-1)*cvt_width_mm-partition_thick_mm, (kk-1)*cvt_width_mm, color='w',zorder=2)
    ax.axvline((kk-1)*cvt_width_mm-partition_thick_mm,color='k',zorder=2,linewidth=linew)
    ax.set_xlim(0,linerLength)
    ax.set_ylabel('SPL, dB',fontsize=30)
    ax.set_ylim(1.005*np.min(spl_full[60,:]),np.max(spl_full[60,:]))
    ax.set_yticks([130,135,140,145], ['130','135','140','145'])
    ax.set_xlabel('$x$ Coordinate, mm',fontsize=30)
    ax.set_xticks(xticks_loc, xticks)
    ax.legend(numpoints=1,loc='best',fontsize=25)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)


    # file.write(f'kk = {kk}\n')
    # file.write('X values:\n')
    # np.savetxt(file, X[60, :])
    # file.write('SPL values:\n')
    # np.savetxt(file, spl_full[60, :, kk - 1])
    # #file.write('imagZ_UTAS values:\n')
    # #np.savetxt(file, imagZ_UTAS)
    # file.write('\n')
plt.savefig(path_save + 'In-Situ_SPL_decay.png', bbox_inches = 'tight', dpi=300)


# csv_file_path = 'resistance_data.csv'
# with open(csv_file_path, 'w', newline='') as csv_file:
#     csv_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

#     # Scrivi l'intestazione
#     csv_writer.writerow(['X values', 'Resistance values', 'RealZ_UTAS values', 'KK'])

#     # Itera attraverso i valori di kk
#     for kk in range(1, 12):
#         realZ_UTAS = np.zeros(len(X))
#         imagZ_UTAS = np.copy(realZ_UTAS)

#         # Calcola i valori di realZ_UTAS e immagZ_UTAS
#         for i in np.arange(len(X)):
#             realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho, nu, c0, POA, cvt_height, fsheet_thick, orifice_d, spl_full[60, i, kk-1], frequencies[0], MeanMach, BLDT)

#         # Salva i dati nel file CSV
#         for i in range(len(realZ_UTAS)):
#             x_value = X[i] * 1e3 + (kk - 1) * cvt_width_mm
#             resistance_value = resistance_full[60, :, kk - 1][i]
#             reactance_value = reactance_full[60,:,kk-1][i]
#             spl_value = spl_full[60,:,kk-1][i]

#             csv_writer.writerow([x_value, resistance_value, reactance_value,spl_value, kk])

# =============================================================================
# save impedance
# =============================================================================
selected_indices_x = []
selected_indices_z = []
if ac_source == 'up' or ac_source == 'noflow':
    
    for col_idx in range(len(X)):
        # Calcola la differenza rispetto al valore fissato
            diff = abs(X[0,col_idx] - X[0,meas_x_idx])
        # Verifica se la differenza è minore di 0.0016
            if diff < 0.0008:
                selected_indices_x.append((0, col_idx))

    for row_idx in range(len(X)):
        diff = abs(Z[row_idx,0] - Z[meas_z_idx,0])
        if diff < 0.0008:        
            selected_indices_z.append((row_idx,0))
    
    # Converti le liste di indici in un array NumPy
    selected_indices_x = np.array(selected_indices_x)
    selected_indices_z = np.array(selected_indices_z)
    
    col_idx = selected_indices_x[:, 1]
    row_idx = selected_indices_z[:, 0]
    
    resistance_upstream = np.zeros(np.array(len(col_idx)))
    reactance_upstream  = np.zeros(np.array(len(col_idx)))
    
    
    indice_l = len(col_idx)
    
    for i in range(1,indice_l): 
        resistance_upstream[i] = resistance_full[row_idx[i], col_idx[i],0]
        reactance_upstream[i] = reactance_full[row_idx[i], col_idx[i],0]

    resistance_upstream = np.mean(resistance_upstream[:])
    reactance_upstream  = np.mean(reactance_upstream[:])
    
    max_resistance = np.max(resistance_full[60,:,0])
    min_resistance = np.min(resistance_full[60,:,0])
    
    max_reactance = np.max(reactance_full[60,:,0])
    min_reactance = np.min(reactance_full[60,:,0])
    
    fig, ax = plt.subplots(1, 1, figsize=(6,1.5))
    ax.imshow(im)
    for kk in range(1,2):
        for orifice_id in np.arange(nm_orifice):
            circle1 = plt.Circle((x0+pad+(or_centers[orifice_id,0]/np.max(X)*cvt_len)+(kk-1)*cvt_len, y0+pad+(or_centers[orifice_id,2]/np.max(Z)*cvt_len)), radius=orifice_d/2/np.max(X)*cvt_len, color='k')
            ax.add_patch(circle1)
   
    
    
    csv_file_path = path_save + 'insitu_M_{}_SPL_{}_f_{}.csv'.format(Mach,SPL,frequencies)
    with open(csv_file_path, mode='w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

        # Scrivi l'intestazione
        csv_writer.writerow(['X values', 'Z values', 'Resistance values', 'Reactance values','SPL','SPL start', 'SPL end'])
    
        raggio = 1.2e-3;
        centro = (0.0051,0.006223);
        
        punti_circonferenza = trova_punti_circonferenza(raggio, centro)
        punti_circonferenza = np.asarray(punti_circonferenza)
        for i in range(len(punti_circonferenza[:,0])):
            x = np.isclose(X[0,:],punti_circonferenza[i,0],atol=1e-4)
            z = np.isclose(Z[:,0],punti_circonferenza[i,1],atol=1e-4)
            x = np.where(x==True)[0]
            z = np.where(z==True)[0]
            resistance_1 = resistance_full[z[0],x[0],0]
            reactance_1 = reactance_full[z[0],x[0],0]
            if i ==0:
               
                csv_writer.writerow([punti_circonferenza[i,0],punti_circonferenza[i,1], resistance_1, reactance_1,spl_full[x[0],z[0],0],np.mean(spl_full[60,:,0]),np.mean(spl_full[60,:,10])]) 
            csv_writer.writerow([punti_circonferenza[i,0],punti_circonferenza[i,1], resistance_1, reactance_1,spl_full[x[0],z[0],0]]) 
            ax.scatter(X[0,x[0]]/np.max(X)*cvt_len,Z[z[0],0]/np.max(X)*cvt_len,s=2,color='r',marker='x')
    
        ax.set_xlim(0,180)
    plt.savefig(path_save + 'where_sampled_insitu_first_orifce',  bbox_inches = 'tight', dpi=300)
# Formattazione con 2 cifre decimali
print("Impedenza upstream {:.2f} {:.2f}j".format(resistance_upstream, reactance_upstream))
print("min and max impedance first cavity {:.2f} {:.2f}j {:.2f} {:.2f}j".format(min_resistance,min_reactance,max_resistance, max_reactance))



    
selected_indices_x = []
selected_indices_z = []
if ac_source == 'up' or ac_source == 'noflow'  or ac_source =='down':
    
    for col_idx in range(len(X)):
        # Calcola la differenza rispetto al valore fissato
            diff = abs(X[0,col_idx] - X[0,meas_x_idx_after])
        # Verifica se la differenza è minore di 0.0016
            if diff < 0.0008:
                selected_indices_x.append((0, col_idx))

    for row_idx in range(len(X)):
        diff = abs(Z[row_idx,0] - Z[meas_z_idx,0])
        if diff < 0.0008:        
            selected_indices_z.append((row_idx,0))
    
    # Converti le liste di indici in un array NumPy
    selected_indices_x = np.array(selected_indices_x)
    selected_indices_z = np.array(selected_indices_z)
    
    col_idx = selected_indices_x[:, 1]
    row_idx = selected_indices_z[:, 0]
    
    resistance_downstream = np.zeros(np.array(len(col_idx)))
    reactance_downstream  = np.zeros(np.array(len(col_idx)))
    
    
    indice_l = len(col_idx)
    
    for i in range(1,indice_l): 
        resistance_downstream[i] = resistance_full[row_idx[i], col_idx[i],10]
        reactance_downstream[i] = reactance_full[row_idx[i], col_idx[i],10]

    resistance_downstream = np.mean(resistance_downstream[:])
    reactance_downstream  = np.mean(reactance_downstream[:])
    
    
# Formattazione con 2 cifre decimali
print("Impedenza downstream {:.2f} {:.2f}j".format(resistance_downstream, reactance_downstream))
    # hf.create_dataset('spl_after', data=spl_full[meas_z_idx,meas_x_idx_after,0])
    # hf.close()

# Seleziona i dati relativi a questa superficie
resistance_surface = resistance_full[60, :, 0]
reactance_surface = reactance_full[60, :, 0]

# Calcola il valore medio per questa superficie
media_resistance = np.mean(resistance_surface)
media_reactance = np.mean(reactance_surface)

# Calcola la deviazione standard per questa superficie
deviazione_std_resistance = np.std(resistance_surface - resistance_downstream)
deviazione_std_reactance = np.std(reactance_surface - reactance_downstream)


print("std up {:.2f} {:.2f}j".format(deviazione_std_resistance, deviazione_std_reactance))
#elif ac_source == 'down':
#     hf = h5py.File(path + 'insitu.h5', 'w')
#     hf.create_dataset('x_after', data=X[0,meas_x_idx_after]+10*cvt_width_m)
#     hf.create_dataset('z_after', data=Z[meas_z_idx,0])
#     hf.create_dataset('resistance_after', data=resistance_full[meas_z_idx,meas_x_idx_after,10])
#     hf.create_dataset('reactance_after', data=reactance_full[meas_z_idx,meas_x_idx_after,10])
#     hf.create_dataset('spl_after', data=spl_full[meas_z_idx,meas_x_idx_after,10])
    
#     hf.create_dataset('x', data=X[0,meas_x_idx]+10*cvt_width_m)
#     hf.create_dataset('z', data=Z[meas_z_idx,0])
#     hf.create_dataset('resistance', data=resistance_full[meas_z_idx,meas_x_idx,10])
#     hf.create_dataset('reactance', data=reactance_full[meas_z_idx,meas_x_idx,10])
#     hf.create_dataset('spl', data=spl_full[meas_z_idx,meas_x_idx,10])
#     hf.close()
#%%
##Plot

media_resistance_list = []
media_reactance_list = []
deviazione_std_resistance_list = []
deviazione_std_reactance_list = []
meanRealZ_UTAS_list = []
meanimageZ_UTAS_list = []

fig, ax = plt.subplots(1, 1, figsize=(20,5))

if Mach == 0.3 or Mach == 0:
    #if ac_source == 'up':
        ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
        ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
        ufsc_exp_realZ_up      = ufsc_exp_realZ_up.mean(axis=1)
        ufsc_exp_imagZ_up      = ufsc_exp_imagZ_up.mean(axis=1)
        
        ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7:9]
        ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,17:19]
        ufsc_exp_realZ_dw      = ufsc_exp_realZ_dw.mean(axis=1)
        ufsc_exp_imagZ_dw      = ufsc_exp_imagZ_dw.mean(axis=1)

if Mach == 0.32:
    #if ac_source == 'up':
        
        path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/in_situ-before_and_after_holes/'
        ufsc_exp_realZ_up      = np.asarray(pd.read_csv(path_experimental + 'M0{}_{}.csv'.format(Mach,SPL),header=0,sep=';'))[:,1]
        ufsc_exp_imagZ_up      = np.asarray(pd.read_csv(path_experimental + 'M0{}_{}.csv'.format(Mach,SPL),header=0,sep=';'))[:,5]
        ufsc_exp_realZ_up      = ufsc_exp_realZ_up.mean(axis=1)
        ufsc_exp_imagZ_up      = ufsc_exp_imagZ_up.mean(axis=1)
        
        ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,3]
        ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7]
        ufsc_exp_realZ_dw      = ufsc_exp_realZ_dw.mean(axis=1)
        ufsc_exp_imagZ_dw      = ufsc_exp_imagZ_dw.mean(axis=1)        

l = int((frequencies[0] - 500 )/100)

exp_result = (ufsc_exp_realZ_up[l],ufsc_exp_imagZ_up[l])
num_yticks = 5  # Puoi impostare il numero desiderato di ticks equidistanti
ytick_values = np.linspace(0.5, 2.5, num_yticks)
     #%%            
for kk in range(0,11):
    
    "estimate with UTAS for the cavity splnp.array([0.728335333333333 -0.173984j]"
    realZ_UTAS = np.zeros(len(X))
    imagZ_UTAS = np.copy(realZ_UTAS)
    
    for i in np.arange(len(X)):
        realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA,cvt_height,fsheet_thick,orifice_d,spl_full[60,i,kk-1],frequencies[0],MeanMach,BLDT)
    
    
    mnRealZ_UTAS = np.mean(realZ_UTAS)
    mnimagZ_UTAS = np.mean(imagZ_UTAS)
    
    # Seleziona i dati relativi a questa superficie
    resistance_surface = resistance_full[:, :, kk]
    reactance_surface = reactance_full[:, :, kk]

    # Calcola il valore medio per questa superficie
    media_resistance = np.mean(resistance_surface)
    media_reactance = np.mean(reactance_surface)

    # Calcola la deviazione standard per questa superficie
    deviazione_std_resistance = np.std(resistance_surface)
    deviazione_std_reactance = np.std(reactance_surface)
    
    # Aggiungi i risultati alle liste
    meanRealZ_UTAS_list.append(mnRealZ_UTAS)
    meanimageZ_UTAS_list.append(mnimagZ_UTAS)
    media_resistance_list.append(media_resistance)
    media_reactance_list.append(media_reactance)
    deviazione_std_resistance_list.append(deviazione_std_resistance)
    deviazione_std_reactance_list.append(deviazione_std_reactance)
#%%
# Valori delle superfici (da 1 a 11)
superfici = np.arange(1, 12)
x = np.linspace(exp_result[0],exp_result[0],len(superfici))
# Plotta i punti medi con le barre di errore
plt.scatter(superfici, media_resistance_list, marker='o', s=200, color='k',label='mean value resistance')
plt.plot(superfici, meanRealZ_UTAS_list, marker = 's',linewidth=3, color = 'b', markersize=20, label = 'semi-empirical model')
plt.plot(superfici,x,marker = 'x', color = 'k', linewidth = 3,markersize=20, label = 'Experimental results');
plt.errorbar(superfici, media_resistance_list, yerr=deviazione_std_reactance_list, marker='o', color='k', linewidth=3, label='Standard deviation')


plt.xlabel('Cavity number [-]',fontsize=30)
#plt.title('Resistance along liner \nM{} $|$ {} dB $|$ $|$ {} [Hz] $|$ {}stream source'.format(Mach,SPL,frequencies[0],ac_source))    

plt.ylabel(r'$\theta$',fontsize=30)

plt.legend(numpoints=1,loc='upper right',fontsize=25)
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.yticks(ytick_values)


plt.savefig(path_save + 'resistance_standardeviation.png', bbox_inches = 'tight', dpi=300)

num_yticks = 5  # Puoi impostare il numero desiderato di ticks equidistanti
ytick_values = np.linspace(-0.25, 0.4, num_yticks)
fig, ax = plt.subplots(1, 1, figsize=(20,5))
x = np.linspace(exp_result[1],exp_result[1],len(superfici))
plt.scatter(superfici, media_reactance_list, marker='o', s=200, color='k',label='mean value resistance')
plt.errorbar(superfici, media_reactance_list, yerr=deviazione_std_reactance_list, marker='o',linewidth=3, color='k', label='Standard deviation')
plt.plot(superfici,x,marker = 'x', color = 'k', linewidth=3,markersize=20, label = 'Experimental results');
plt.plot(superfici, meanimageZ_UTAS_list, marker = 's',linewidth=3,markersize=20, color = 'b', label = 'semi-empirical model') 
# Imposta l'etichetta dell'asse x
plt.xlabel('cavity number [-]',fontsize = 30)
    
# Imposta l'etichetta dell'asse y
plt.ylabel(r'$\chi$',fontsize = 30)
#plt.title('Reactance along liner \nM{} $|$ {} dB $|$ $|$ {} [Hz] $|$ {}stream source'.format(Mach,SPL,frequencies[0],ac_source))    
# Aggiungi una legenda
plt.legend(numpoints=1,loc='upper right',fontsize=25)
plt.xticks(fontsize=30)
plt.yticks(fontsize=30)    
plt.yticks(ytick_values)


plt.savefig(path_save + 'reactance_standardeviation.png', bbox_inches = 'tight', dpi=300)


#%%
# insitu_veryfine = np.array([1.5606273331253853-1.4715906576336923j, 1.451689762330236-0.30973318865781857j, 1.3723984386200294+0.41883431414716976j])
# =============================================================================
# Fine Resolution Results V14_1 - M=0.3 145dB [800,1400,2000]
# 

insitu_sharped = np.array([1.45-1.39j,1.41-0.23j,1.38+0.45j])
insitu_new = np.array([0.49-1.35j,0.46-0.37j,0.4+0.22j])

insitu_medium = np.array([0.42-1.32j,0.44-0.32j, 0.37+0.19j])
insitu_fine = np.array([0.49-1.35j,0.46-0.37j,0.4+0.22j])
## Fine resolution M = 0.3 SPL 145 dB down

insitu_fine_dw = np.array([1.38-1.33j,1.30-0.36j,1.12+0.21j])


## Fine resolution Results 
# =============================================================================
# Medium Resolution Results V14_1 - M=0.3 145dB [800,1400,2000]
#%% =============================================================================
# insitu_rounded = np.array([0.36-1.27j,0.55-0.22j,0.36+0.43j])

# ======================================================
# Fine Resolution M = 0 SPL = 130 dB [800, 1400, 2000]
#insitu_new = np.array([0.09-1.27j,0.12-0.27j, 0.07+0.43j])


# ======================================================
# Fine Resolution M = 0 SPL = 145 dB [800, 1400, 2000]
# insitu_new = np.array([0.22-1.35j,0.4-0.35j, 0.25+0.36j])




# ======================================================
# Medium Resolution M = 0.3 SPL = 130 dB [800, 1400, 2000]
# insitu_medium = np.array([0.59-1.26j,0.45-0.41j, 0.37+0.29j])
# insitu_fine = np.array([0.46-1.41j,0.52-0.39j,0.4+0.17j])
# insitu_sharped =np.array([1.92-1.17j,2.01-0.25j,1.56-0.33j])

exp_freqs           = np.arange(500,3100,100)




freqs_UTAS = np.arange(500,3000,100)
realZ_UTAS = np.zeros(len(freqs_UTAS))
imagZ_UTAS = np.copy(realZ_UTAS)
realZ_UTAS2 = np.zeros(len(freqs_UTAS))
imagZ_UTAS2 = np.copy(realZ_UTAS)
realZ_Crandall = np.zeros(len(freqs_UTAS))
realZ_UTAS_ufsc = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc = np.copy(realZ_UTAS)
realZ_UTAS_ufsc_min = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_min = np.copy(realZ_UTAS)
realZ_UTAS_ufsc_max = np.zeros(len(freqs_UTAS))
imagZ_UTAS_ufsc_max = np.copy(realZ_UTAS)
imagZ_Crandall = np.copy(realZ_Crandall)
for i in np.arange(len(realZ_UTAS)):
    realZ_UTAS[i], imagZ_UTAS[i] = impedanceUTAS(rho,nu,c0,POA,cvt_height,fsheet_thick,orifice_d,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS2[i], imagZ_UTAS2[i] = impedanceUTAS(rho,nu,c0,0.09918427299499137,cvt_height,fsheet_thick,orifice_d+(2*fsheet_thick*0.2),SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc[i], imagZ_UTAS_ufsc[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_ufsc,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc_min[i], imagZ_UTAS_ufsc_min[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_min,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_UTAS_ufsc_max[i], imagZ_UTAS_ufsc_max[i] = impedanceUTAS(rho,nu,c0,POA_ufsc,cvt_height_ufsc,fsheet_thick_ufsc,orifice_d_max,SPL,freqs_UTAS[i],MeanMach,BLDT)
    realZ_Crandall[i],imagZ_Crandall[i] = impedanceCrandall(rho, nu, c0, POA, cvt_height, fsheet_thick, orifice_d, spl_full[60,i,kk-1], freqs_UTAS[i], 2                                                                                                                                                                       )


a = np.zeros((3, len(freqs_UTAS)))

a[0,:] = realZ_UTAS_ufsc_min

a[1,:] = realZ_UTAS_ufsc

a[2,:] = realZ_UTAS_ufsc_max

c = np.zeros((3, len(freqs_UTAS)))

c[0,:] = imagZ_UTAS_ufsc_min

c[1,:] = imagZ_UTAS_ufsc

c[2,:] = imagZ_UTAS_ufsc_max

d = np.std(c, axis =0)

b = np.std(a, axis=0)
# fig, ax = plt.subplots(1, 1, figsize=(9.5,9.5))

# ax.plot(exp_freqs,ufsc_exp_imagZ,color='k',linestyle='solid')
# ax.plot(exp_freqs,ufsc_exp_realZ,color='k',linestyle='solid',label='UFSC')

# ax.plot(freqs_UTAS,imagZ_UTAS,color='tab:gray',linestyle='dashed')
# ax.plot(freqs_UTAS,realZ_UTAS,color='tab:gray',linestyle='dashed',label='UTAS 6.3 POA')

# ax.plot(freqs_UTAS,imagZ_Crandall,color='k',linestyle='dashed')
# ax.plot(freqs_UTAS,realZ_Crandall,color='k',linestyle='dashed',label='Crandall 6.3 POA')


# ax.scatter([800,1400,2000],np.real(insitu_medium),edgecolor='b',color='b',s=80,marker='o',facecolor='w',label=' medium res. - realZ')
# ax.scatter([800,1400,2000],np.imag(insitu_medium),edgecolor='b',color='b',s=80,marker='x',label='medium res. - imagZ')



# ax.scatter([800,1400,2000],np.real(insitu_fine),edgecolor='r',color='r',s=80,marker='o',facecolor='w',label=' fine res. - realZ')
# ax.scatter([800,1400,2000],np.imag(insitu_fine),edgecolor='r',color='r',s=80,marker='x',label='fine res. - imagZ')


# ax.scatter([800,1400,2000],np.real(insitu_veryfine),edgecolor='k',color='k',s=80,marker='o',facecolor='w',label='veryfine res. - realZ')
# ax.scatter([800,1400,2000],np.imag(insitu_veryfine),edgecolor='k',color='k',s=80,marker='x',label='veryfine res. - imagZ')

# ax.set_xlabel("Frequency [Hz]", fontsize = 30)
# ax.set_xlim(700,2200)
# #ax.set_ylim(-2.7,1)
# ax.legend(numpoints=1,loc='lower right',fontsize=25)
# plt.xticks(fontsize=30)
# plt.yticks(fontsize=30)
# ax.set_ylabel("Normalized Impedance", fontsize = 30)


# path = '/home/angelo/Scrivania/aeroacustica/Progetto_ANEMONE/Risultati/images/impedance/In situ/'
# plt.savefig(path + 'In-situ_comparison.png', bbox_inches = 'tight', dpi=300)

# xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
# exp_freqs = np.arange(0.5,3.1,0.1)
# freqs_UTAS = np.arange(0.5,3.0,0.1)

# fig, ax = plt.subplots(1, 1, figsize=(9, 9))

# ax.scatter(exp_freqs, ufsc_exp_realZ_up, color='k', linestyle='solid', linewidth=3, label='exp. UFSC')
# ax.plot(freqs_UTAS, realZ_UTAS_ufsc, color='r', linestyle='solid', linewidth=3, label='UTAS 8.75\% POA')

# ax.scatter([0.800, 1.400, 2.000], np.real(insitu_medium), edgecolor='blue', color='blue', s=300, marker='o', facecolor='b', linewidth=3, label='sim. medium')
# ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine), edgecolor='red', color='red', s=300, marker='^', facecolor='r', linewidth=3, label='sim. fine')

# yticks = [0.0, 1.0, 2.0, 3.0]
# xticks = [ 1.0, 1.5, 2.0, 2.5]
# ax.set_xlabel("$f, kHz$", fontsize=40)
# ax.set_xlim(0.5, 2.6)
# ax.set_ylim(0.0, 3.5)
# ax.set_xticks(xticks)
# ax.set_yticks(yticks)
# ax.legend(numpoints=1, loc='best', fontsize=30)
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
# ax.set_ylabel(r'$\theta$', fontsize=40)
# ax.tick_params(axis='both', labelsize=40)

# plt.show()


# # ax.scatter([0.800,1.400,2.000],np.real(insitu_fine_dw),edgecolor='b',color='b',s=250,marker='s',facecolor='b',linewidth=3, label='sim. down')



# yticks = [0.0,1.0,2.0,3.0,4.0]
# ax.set_xlabel("$f, kHz$",fontsize=40)
# ax.set_xlim(0.5,2.6)
# ax.set_ylim(0.0,4.5)
# #y_labels = ['0.25','0.50','0.75','1.00','1.25','1.50']
# ax.set_xticks(xticks, xticks)
# ax.set_yticks(yticks, yticks)
# ax.legend(numpoints=1,loc='best',fontsize=25)
# #ax.set_yticklabels(y_labels)
# ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
# ax.set_ylabel(r'$\theta$',fontsize=40)
# ax.tick_params(axis='both', labelsize = 40)


# fig.savefig(path_save + 'insitu_resistance_comparison.png', dpi=300)




# fig, ax = plt.subplots(1, 1, figsize=(9,9))


# ax.scatter(exp_freqs,ufsc_exp_imagZ_up,color='k',linestyle='solid',linewidth=3,label='exp. UFSC')
# # ax.plot(exp_freqs,ufsc_exp_imagZ_dw,color='b',linestyle='solid',linewidth=3,label='UFSC down')
# # ax.plot(freqs_UTAS,imagZ_UTAS,color='b',linestyle='dashed',linewidth=3,label='UTAS 6.3\% POA')
# ax.plot(freqs_UTAS,imagZ_UTAS_ufsc,color='r',linestyle='solid',linewidth = 3,label='UTAS 8.75\% POA')
# #plt.errorbar(freqs_UTAS, imagZ_UTAS_ufsc, yerr=d, marker='o', color='r', linewidth=3,linestyle='dashed')

# # ax.scatter([0.800,1.400,2.000],np.imag(insitu_sharped),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3,label='nominal geometry')
# #ax.scatter([0.800,1.400,2.000],np.imag(insitu_rounded),edgecolor='b',color='b',s=250,marker='s',facecolor='w',linewidth=3,label='rounded edges')

# ax.scatter([0.800,1.400,2.000],np.imag(insitu_medium),edgecolor='b',color='b',s=300,marker='o',facecolor='b',linewidth=3,label='sim. medium')
# ax.scatter([0.800,1.400,2.000],np.imag(insitu_fine),edgecolor='r',color='r',s=300,marker='^',facecolor='r',linewidth=3,label='sim. fine')

# # ax.scatter([0.800,1.400,2.000],np.imag(insitu_fine_dw),edgecolor='b',color='b',s=250,marker='s',facecolor='b',linewidth=3, label='sim. down')



# ax.set_xlabel('$f, kHz$',fontsize=40)
# ax.set_xlim(0.5,2.6)
# ax.set_ylim(-4,1.5)
# ax.set_xticks(xticks, xticks)
# yticks = [-3,-2,-1,0,1,2]
# ax.set_yticks(yticks, yticks)
# ax.legend(numpoints=1,loc='lower right',fontsize=30)
# ax.set_ylabel(r'$\chi$',fontsize=40)
# ax.tick_params(axis='both', labelsize = 40)
# #ax.grid(True)

# fig.savefig(path_save + 'insitu_reactance_comparison.png', dpi=300)





# # %%

# # #%%Before and after holes

# exp_path = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/in_situ-before_and_after_holes/'


# ## LOAD EXPERIMENTAL RESULTS
# ufsc_exp_realZ_bef = np.asarray(pd.read_csv(exp_path + 'M032_145dB.csv',header=0,sep=';'))[:,1]
# ufsc_exp_realZ_aft = np.asarray(pd.read_csv(exp_path + 'M032_145dB.csv',header=0,sep=';'))[:,2]

# ufsc_exp_imgZ_bef = np.asarray(pd.read_csv(exp_path + 'M032_145dB.csv',header=0,sep=';'))[:,5]
# ufsc_exp_imgZ_aft = np.asarray(pd.read_csv(exp_path + 'M032_145dB.csv',header=0,sep=';'))[:,6]


# ## LOAD NUMERICAL RESULTS

# fine_before     = [0.49-1.35j,0.46-0.37j,0.40+0.22j]
# fine_after      = [1.21-1.44j,1.24-0.63j,1.11-0.12j]
# if ac_source == 'up' or ac_source == 'noflow':
# # veryfine_before = [1.56-1.68j,1.45-0.309j,1.37+0.42j]
# # veryfine_after  = [2.26-1.68j,2.18 -0.75j,2.18 -0.21j]

# # veryfine_before_mean = [1.39-1.34j,1.33-0.28j,1.26+0.36j]
# # veryfine_after_mean = [2.12-1.56j, 2.01-0.68j, 1.98-0.15j]

# fig, ax = plt.subplots(1, 1, figsize=(10,10))


# ax.plot(exp_freqs,ufsc_exp_realZ_bef,color='r',linestyle='solid',linewidth=3,label='Before orifices')

# ax.plot(exp_freqs,ufsc_exp_realZ_aft,color='b',linestyle='dashed',linewidth=3,label='After orifices')


# ax.scatter([0.800,1.400,2.000], np.real(fine_before), color='r', s=250, marker='s', facecolor='r', linewidth=3, label='fine res. before')
# # # ax.scatter([0.800,1.400,2.000], np.real(veryfine_before), color='k', s=250, marker='x', linewidth=3, label='veryfine res. before')
# ax.scatter([0.800,1.400,2.000], np.real(fine_after), edgecolor='b', color='b', s=250, marker='^', facecolor='b', linewidth=3, label='fine res. after')
# # # ax.scatter([0.800,1.400,2.000], np.real(veryfine_after), edgecolor='k', color='k', s=250, marker='^', facecolor='w', linewidth=3, label='veryfine res. after')
# # # ax.scatter([0.800,1.400,2.000], np.real(veryfine_after_mean), edgecolor='b', color='b', s=250, marker='o', facecolor='w', linewidth=3, label='veryfine res. after mean')
# # # ax.scatter([0.800,1.400,2.000], np.real(veryfine_before_mean), edgecolor='r', color='r', s=250, marker='o', facecolor='w', linewidth=3, label='veryfine res. before mean')

# ax.set_xlabel('$f, kHz$',fontsize=40)
# ax.set_xlim(0.5,2.6)
# ax.set_ylim(0,3.5)
# ax.set_xticks(xticks, xticks)
# #ax.legend(numpoints=1,loc='lower right',fontsize=25)
# ax.set_ylabel(r'$\theta$',fontsize=40)
# ax.tick_params(axis='both', labelsize = 40)
# # ax.grid(True)


# fig.savefig(path + 'insitu_resistance_before_after_comparison.png', dpi=300)

# # ##REACTANCE PLOT


# fig, ax = plt.subplots(1, 1, figsize=(10,10))


# ax.plot(exp_freqs,ufsc_exp_imgZ_bef,color='r',linestyle='solid',linewidth=3,label='exp. before')

# ax.plot(exp_freqs,ufsc_exp_imgZ_aft,color='b',linestyle='dashed',linewidth=3,label='exp. after')


# ax.scatter([0.800,1.400,2.000], np.imag(fine_before), color='r', s=200, marker='s',  facecolor='r', linewidth=3, label='sim. before')
# # # ax.scatter([0.800,1.400,2.000], np.imag(veryfine_before), color='k', s=200, marker='x', linewidth=2, label='veryfine res. before')
# ax.scatter([0.800,1.400,2.000], np.imag(fine_after), edgecolor='b', color='r', s=200, marker='^', facecolor='b', linewidth=3, label='sim. after')
# # # ax.scatter([0.800,1.400,2.000], np.imag(veryfine_after), edgecolor='k', color='k', s=200, marker='^', facecolor='w', linewidth=2, label='veryfine res. after')
# # # ax.scatter([0.800,1.400,2.000], np.imag(veryfine_after_mean), edgecolor='b', color='b', s=250, marker='o', facecolor='w', linewidth=3, label='veryfine res. after mean')
# # # ax.scatter([0.800,1.400,2.000], np.imag(veryfine_before_mean), edgecolor='r', color='r', s=250, marker='o', facecolor='w', linewidth=3, label='veryfine res. before mean')

# ax.set_xlabel('$f, kHz$',fontsize=40)
# ax.set_xlim(0.5,2.6)
# ax.set_ylim(-2,1.0)
# ax.set_xticks(xticks, xticks)
# ax.legend(numpoints=1,loc='lower right',fontsize=25)
# ax.set_ylabel(r'$\chi$',fontsize=40)
# ax.tick_params(axis='both', labelsize = 40)
# # ax.grid(True)


# fig.savefig(path + 'insitu_reactance_before_after_comparison.png', dpi=300)
