#!/usr/bin/env python

import sys, os, math, subprocess

import numpy as np
workdir = os.getcwd()
"NASA liner"
"Script to extract pressure time histories for the eduction methods"

newdir 	= workdir+"/eduction/"
os.makedirs(newdir)

newdir 	= workdir+"/eduction/mm/"
os.makedirs(newdir)

project0 = app.newProject()
calculation0 = project0.createCalculation()
calculation0.calcFunction = "Sample"
calculation0.name = "MM"
calculation0.inputTab.filename = workdir+"/ac_plane1_stream_inst.snc"
calculation0.outputTab.filename = workdir+"/eduction/mm/MM.calc"
calculation0.outputTab.outputFormat = "ImportPoints"
calculation0.outputTab.ptfileOptions.filename = workdir+"/NASA_points/mm/Pts_MM.txt"
calculation0.apply()
exportData0 = project0.calculations["MM"].createExportData()
exportData0.name = "MM"
exportData0.filename = workdir+"/eduction/mm/mm_pressure"
exportData0.apply()
 
newdir 	= workdir+"/eduction/kt/"
os.makedirs(newdir)

calculation1 = project0.createCalculation()
calculation1.name = "KT"
calculation1.calcFunction = "Sample"
calculation1.inputTab.filename = workdir+"/ac_plane1_stream_inst.snc"
calculation1.outputTab.filename = workdir+"/eduction/kt/KT.calc"
calculation1.outputTab.outputFormat = "ImportPoints"
calculation1.outputTab.ptfileOptions.filename = workdir+"/NASA_points/kt/Pts_Prony.txt"
calculation1.apply()
exportData1 = project0.calculations["KT"].createExportData()
exportData1.name = "KT"
exportData1.filename = workdir+"/eduction/kt/kt_pressure"
exportData1.apply()

project0.save(workdir+"/eduction/Export_eduction.pap")
project0.queueAll(True)
