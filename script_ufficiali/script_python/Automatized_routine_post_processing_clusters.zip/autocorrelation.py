# -*- coding: utf-8 -*-
"""
Created on Mon Aug 15 11:22:23 2022

@author: mynames
"""

"Import python packages"
import numpy as np
import pandas as pd
from scipy.signal import csd
from scipy import interpolate
from scipy.fft import fft
import matplotlib.pyplot as plt
import matplotlib as mpl
import scipy as sp
import warnings
warnings.filterwarnings("ignore")


"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Latin Modern Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
plt.close('all')
mpl.rcParams['text.usetex'] = False
cm = 1/2.54

"File parameters"
frequencies         = [2000]
ac_source           = 'up'
SPL                 = 145
Mach                = 0.3
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
time_step           =  1.422536e-05

path                = '../'



sim_data            = np.asarray(pd.read_csv(path + 'point_outside_bdl.csv'))[1:-1,:]
sim_data            = sim_data.astype(float)
sim_time            = sim_data[:,0]
sim_data            = sim_data[:,1]

#Seleziona i valori maggiori di 10^7

i = 0

indx = sim_data <= 1e08

sim_data = sim_data[indx]
sim_time = sim_time[indx]


# if ac_source == 'up':
#     sim_data = sim_data[:,0]
# elif ac_source == 'down':
#     sim_data = sim_data[:,-1]    

sim_data = sim_data-np.mean(sim_data)
# =============================================================================
# BEGIN CODE
#%%## =============================================================================
"Plot time signal"
#fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
#ax.plot(np.arange(len(sim_data)),sim_data,color='k',linestyle='solid')
#ax.set_xlabel("Frame [-]")
#ax.set_ylabel("Pressure [Pa]", multialignment="center")
#ax.set_title('Time signal outside TBL')
#sim_time_1 = sim_time[1]*time_step
#sim_time_0 = sim_time[0]*time_step
fs      = 1/(sim_time[1]-sim_time[0])
nperseg = len(sim_data)

"Performing autocorrelation"
ref_f, Sxx = csd(sim_data,sim_data,fs=fs,nperseg=nperseg)

#fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
#ax.loglog(ref_f,np.abs(Sxx),color='k',linestyle='solid')
#ax.scatter(ref_f[np.where(np.abs(Sxx)==np.max(np.abs(Sxx)))],np.max(np.abs(Sxx)),color='r')
#ax.set_xlabel("Frames [-]")
#ax.set_title('Largest peak of $S_{xx}$ is the number of frames per cycle')

a=1/ref_f[np.where(np.abs(Sxx)==np.max(np.abs(Sxx)))][0]
print('The number of frames per cycle is: {}'.format(a))



"Performing autocorrelation"
ref_f, Sxx = csd(sim_data,sim_data,fs=fs,nperseg=nperseg)

#fig, ax = plt.subplots(1, 1, figsize=(15*cm, 15*cm))
#ax.loglog(ref_f,np.abs(Sxx),color='k',linestyle='solid')
#ax.scatter(ref_f[np.where(np.abs(Sxx)==np.max(np.abs(Sxx)))],np.max(np.abs(Sxx)),color='r')
#ax.set_xlabel("Frequency [Hz]")
#ax.set_title('First peak of $S_{xx}$ is the frequency of the AC wave')

b=ref_f[np.where(np.abs(Sxx)==np.max(np.abs(Sxx)))][0]
print('The frequency is: {:.2f}'.format(b))

print('Use {} frames per cycle'.format(a-(a/b*frequencies[0]-a)))

with open('results_autocorrelations.txt', 'x') as file:
    # Scrivi i risultati nel file
    file.write(f'Results obtained at SPL = {SPL}, M = {Mach}, f = {frequencies}, resolution={resolution}\n')
    file.write(f'The number of frames per cycle is: {a}\n')
