# Percorso del nuovo file
file_path = 'optydb_fieldcomb.i'


with open('../MachNumber.ascii', 'r') as file_risultati:
    lines = file_risultati.readlines()
    
    line = lines[33]
    density = line.split()[1]  # Assumendo che il valore sia nella settima colonna
    
    line = lines[34]
    mach = line.split()[2]
    
    line   = lines[35]
    pressure  = line.split()[2]


# Scrivi nel nuovo file con la stessa struttura del file di esempio
with open(file_path, 'w') as file:
    file.write('2 ................................ Number of imported solutions\n')
    file.write('../ac_plane1_stream_inst_avg.snc ........................ Name of the 1st imported solution$\n')
    file.write('../ac_plane1_stream_avg_sum.snc ........................ Name of the 2nd imported sol$\n')
    file.write(f'{pressure} ......................... Mean-flow pressure (Pa)\n')
    file.write(f'{density} .......................... Mean-flow denisty (kg/m^3)\n')
    file.write('1.4 .............................. Gas specific heats ratio\n')
    file.write('287.057 .......................... Gas constant\n')
    file.write(f'{mach} ........................ Mean-flow Mach number along x\n')
    file.write('0.0 .............................. Mean-flow Mach number along y\n')
    file.write('0.0 .............................. Mean-flow Mach number along z\n')
    file.write('========================= FIELD CORRECTION SECTION =========================\n')
    file.write('../ac_plane1_stream_PL.snc ......................... Name of the exported solution file\n')

