#!/bin/bash

#PBS -j oe

#PBS -N rt_postprocess

#PBS -l nodes=1:ppn=36:typek,walltime=12:00:00

#PBS -q fpt-gpu

#PBS -M angelo.paduano@polito.it

source /home/lmeirellespere/bash_profile

set -e

echo Job started on `uname -n` at `date`

ulimit -a

cd $PBS_O_WORKDIR

./stopAction 7200 &

(
for host in `cat $PBS_NODEFILE | sort -u -V`
do
     count=`grep $host $PBS_NODEFILE | wc -l`
     echo $count $host
done

echo cp `head -1 $PBS_NODEFILE`
) > $PBS_JOBID.mpifile

module load python

export EXACORP_LICENSE=27030@flexserv1.tudelft.nl
export PATH=/home/everybody/PowerFLOW/6-2022-R1/bin:$PATH

poweracoustics -force -no_gui -wait -script Extract_data_eduction.py

poweracoustics -force -no_gui -wait -script Extract_data_Deans.py

powerviz --no_gui --no_display get_timehistory_for_autocorrelation.pvs

source /home/lmeirellespere/miniconda3/etc/profile.d/conda.sh

conda activate post_pro

python autocorrelation.py

conda deactivate

nframepercicle=$(awk 'NR==2 {print $8}' results_autocorrelations.txt)

optydb_phaselock -i ../ac_plane1_stream_inst.snc -o ../ac_plane1_stream_avg.log -s $nframepercicle 

exa_meas_copy --sum --first 0 --units mks ../ac_plane1_stream_inst_avg.snc ../ac_plane1_stream_avg_sum.snc

powerviz --no_gui --no_display get_mean_for_optydb_fieldcomb.pvs

conda activate post_pro

python fieldcomb_generate.py

source /home/everybody/OptydB/2022R1/bin/LINUX-gcc-8.3.1/zoptydb_env.sh

optydb_fieldcomb -i optydb_fieldcomb.i -o optydb_fieldcomb.log


mkdir ../phaselock_velocity

powerviz --no_gui --no_display generate_vc_phaselock.pvs

mkdir ../ac_velocity

powerviz --no_gui --no_display generate_ac_velocity.pvs


## Para rodar esse script no cluster: qsub -q fpt-large PF_decomp_run.sh



