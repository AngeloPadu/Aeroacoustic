#!/usr/bin/env python

import sys, os, math, subprocess

import numpy as np
workdir = os.getcwd()
"NASA liner"
"Script to extract pressure time histories for the Dean's method"

newdir = os.makedirs(workdir+"/in_situ/")

for i in np.arange(11):
	newdir 	= workdir+"/in_situ/cvt_{}/".format(i+1)
	os.makedirs(newdir)
	
	project0 = app.newProject()
	calculation0 = project0.createCalculation()
	calculation0.calcFunction = "Sample"
	calculation0.name = "Backplate"
	calculation0.inputTab.filename = workdir+"/ac_backplate_inst.snc"
	calculation0.outputTab.filename = workdir+"/in_situ/cvt_{}/Backplate.calc".format(i+1)
	calculation0.outputTab.outputFormat = "ImportPoints"
	calculation0.outputTab.ptfileOptions.filename = workdir+"/NASA_points/in_situ/Pts_bottom_{}.txt".format(i+1)
	calculation0.apply()
	exportData0 = project0.calculations["Backplate"].createExportData()
	exportData0.name = "Backplate"
	exportData0.filename = workdir+"/in_situ/cvt_{}/cvt_{}_pressure_bottom".format(i+1,i+1)
	exportData0.apply()
  
	calculation1 = project0.createCalculation()
	calculation1.name = "Facesheet_contour"
	calculation1.calcFunction = "Sample"
	calculation1.inputTab.filename = workdir+"/ac_liner_surface_inst.snc"
	calculation1.outputTab.filename = workdir+"/in_situ/cvt_{}/Facesheet_contour.calc".format(i+1)
	calculation1.outputTab.outputFormat = "ImportPoints"
	calculation1.outputTab.ptfileOptions.filename = workdir+"/NASA_points/in_situ/Pts_contour_top_{}.txt".format(i+1)
	calculation1.apply()
	exportData1 = project0.calculations["Facesheet_contour"].createExportData()
	exportData1.name = "Facesheet_contour"
	exportData1.filename = workdir+"/in_situ/cvt_{}/cvt_{}_pressure_top_contour".format(i+1,i+1)
	exportData1.apply()
  
	calculation2 = project0.createCalculation()
	calculation2.name = "Facesheet_discrete"
	calculation2.calcFunction = "Sample"
	calculation2.inputTab.filename = workdir+"/ac_liner_surface_inst.snc"
	calculation2.outputTab.filename = workdir+"/in_situ/cvt_{}/Facesheet_discrete.calc".format(i+1)
	calculation2.outputTab.outputFormat = "ImportPoints"
	calculation2.outputTab.ptfileOptions.filename = workdir+"/NASA_points/in_situ/Pts_discrete_top_{}.txt".format(i+1)
	calculation2.apply()
	exportData2 = project0.calculations["Facesheet_discrete"].createExportData()
	exportData2.name = "Facesheet_discrete"
	exportData2.filename = workdir+"/in_situ/cvt_{}/cvt_{}_pressure_top_discrete".format(i+1,i+1)
	exportData2.apply()

	project0.save(workdir+"/in_situ/cvt_{}/Export_Deans_cvt{}.pap".format(i+1,i+1))
	project0.queueAll(True)






