
# -*- coding: utf-8 -*-

import subprocess
import os

def read_value_from_file(file_path, keyword):
    with open(file_path, 'r') as file:
        for index, line in enumerate(file, start=1):  # Enumerate inizia a contare da 1
            if keyword in line:
                # Restituisci la riga trovata e il suo indice
                return index

def update_value_in_file(input_file, output_file, bc_inlet_line, bc_outlet_line, wave_propagation_line, liner_bc_blending_parameter_line):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    # Modifica le linee con i nuovi valori
    lines[mean_flow_line-1] = mean_flow + ' ................ Uniform material/mean flow\n'
    lines[bc_inlet_line -1] = 'xmin     ' + bc_inlet + '\n'
    lines[bc_outlet_line -1] = 'xmax     ' + bc_outlet + '\n'
    lines[wave_propagation_line - 1] = wave_propagation + ' ............. Source coordinates OR plane wave unit propagation vector OR freeastream unit propagation vector (xs, ys, zs)\n'
    lines[liner_bc_blending_parameter_line - 1] = new_value + ' ................................................. Liner BC blending parameter \n'
    
    # Scrivi le righe modificate nel nuovo file
    with open(output_file, 'w') as f:
        f.writelines(lines)

# Ottieni il percorso assoluto dello script
script_directory = os.path.dirname(os.path.abspath(__file__))

# File da cui leggere il nuovo valore
file_path = os.path.join(script_directory, 'overrides_angelo')

# Leggi il nuovo valore
# Leggi i nuovi valori utilizzando awk
bc_inlet = subprocess.check_output("awk 'NR==1 {print $1, $2}' " + file_path, shell=True).decode().strip()
bc_outlet = subprocess.check_output("awk 'NR==2 {print $1, $2}' " + file_path, shell=True).decode().strip()
wave_propagation = subprocess.check_output("awk 'NR==3 {print $1, $2, $3}' " + file_path, shell=True).decode().strip()
new_value = subprocess.check_output("awk 'NR==4 {print $1}' " + file_path, shell=True).decode().strip()
mean_flow = subprocess.check_output("awk 'NR==5 {print $1}' " + file_path, shell=True).decode().strip()

# File da modificare
input_file = 'gfit.i'

# Leggi le righe di interesse
bc_inlet_line = read_value_from_file(input_file, 'xmin')
bc_outlet_line = read_value_from_file(input_file, 'xmax')
mean_flow_line = read_value_from_file(input_file, 'Uniform material/mean flow')
wave_propagation_line = read_value_from_file(input_file, 'Source coordinates OR plane wave unit propagation vector OR freeastream unit propagation vector (xs, ys, zs)')
liner_bc_blending_parameter_line = read_value_from_file(input_file, 'Liner BC blending parameter')

# Chiamata alla funzione per aggiornare il file con le linee lette dal file Python precedente
update_value_in_file(input_file, input_file, int(bc_inlet_line), int(bc_outlet_line), int(wave_propagation_line), int(liner_bc_blending_parameter_line))
print("Il file 'gfit.i' è stato aggiornato con successo con le linee lette dal file Python precedente.")

