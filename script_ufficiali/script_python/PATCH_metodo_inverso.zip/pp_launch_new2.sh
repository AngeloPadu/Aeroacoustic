#!/bin/bash

# BY DOWNLOADING THIS FILE (“DOWNLOAD”) YOU AGREE TO THE FOLLOWING TERMS:

# THIS DOWNLOAD IS MADE AVAILABLE ON AN "AS IS" BASIS WITHOUT WARRANTY OF ANY KIND, 
# WHETHER EXPRESS OR IMPLIED, ORAL OR WRITTEN, INCLUDING, WITHOUT LIMITATION, 
# ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE OR NON-INFRINGEMENT.

# DASSAULT SYSTEMES SIMULIA CORP., ANY OF IT AFFILIATES (COLLECTIVELY “DS:”), 
# AND ITS LICENSORS SHALL HAVE NO LIABILITY FOR DIRECT, INDIRECT, INCIDENTAL, 
# CONSEQUENTIAL OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION CLAIMS FOR LOST PROFITS, 
# BUSINESS INTERRUPTION AND LOSS OF DATA, THAT IN ANY WAY RELATE TO THIS DOWNLOAD, 
# WHETHER OR NOT DS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES AND NOTWITHSTANDING 
# THE FAILURE OF THE ESSENTIAL PURPOSE OF ANY REMEDY. 
 
# YOUR USE OF THIS DOWNLOAD SHALL BE AT YOUR SOLE RISK.
# SUPPORT OF THE DOWNLOAD, IF ANY, IS PROVIDED ON A DISCRETIONARY BASIS BY DS’ SOLE OPTION.


###########################################################################
################ INSTRUCTIONS
###########################################################################

# Define PowerFLOW install folder in an environmental variable:
#export EXA_CODE=/home/everybody/PowerFLOW/6-2022-R3
#export POWER_FLOW_PATH=/home/everybody/PowerFLOW/6-2022-R3
export EXA_CODE=$POWER_FLOW_PATH

# Define PowerACOUSTICS install folder in an environmental variable:
#export PA_CODE=/home/everybody/PowerACOUSTICS/6-2022-R1
export PA_CODE=/scratch/code/code/PowerACOUSTICS/2022-R4-orig

# Remember to source the OptydB environment setup script BEFORE launching this script
#source /home/everybody/OptydB/2024_R2_beta/bin/LINUX-gcc-10.2.1/zoptydb_env.sh
source /cust/polito/zoptydb_dav.sh

# Remember to source the OptydB environment setup script BEFORE launching this script
# set THREADS variable to define number of cores to use in optydb_fieldmod (can be larger than the actual available cores number)
export THREADS=6
export THREADS_FIELDMOD=6

# De-comment the line you want to use: 1) optydb mpirun 2) PowerFLOW mpirun:
export MPI_PATH=$EXA_CODE/dist/x86_linux/server/x86_64/impi/intel64/bin

# Select a suffix for the acoustic run:
export AC_SIM_SUFFIX=

###########################################################################
################ SCRIPT BEGINS
###########################################################################


if [ -z "$THREADS" ]
then
    export THREADS=1
fi
if [ -z "$THREADS_FIELDMOD" ]
then
    export THREADS_FIELDMOD=10
fi

PATH=$PATH:$MPI_PATH

export SIM_SEED_PATH=00.FLOW_SEED
export SIM_FLOW_PATH=01.FLOW_SIM
export SIM_AC_PATH=02.AC_SIM$AC_SIM_SUFFIX

$EXA_CODE/bin/exapython << EOF
import GFIT_lib_r32
GFIT_lib_r33.print_disclaimer()
GFIT_lib_r33.get_version()
EOF
echo ''
echo 'Please Select a Task:'
options=("Prepare casefiles" "Prepare Init fnc" "Launch Impedance Eduction" "Quit")
#select opt in "${options[@]}"
for opt in "Launch Impedance Eduction"
do
    #echo $opt
    case $opt in
        "Prepare casefiles")
			echo "Preparing casefiles..."
			if [ -d "./$SIM_SEED_PATH" ] && [ -d "./$SIM_FLOW_PATH" ]; then
				echo 'Flow simulation data present. Delete?'
				options2=("Yes" "No")
				select opt2 in "${options2[@]}"
				do
					case $opt2 in
						"Yes")
							export SIM_FLOW_CLEAN=1
							break
							;;
						"No")
							export SIM_FLOW_CLEAN=0
							break
							;;
						*) echo "invalid option";;
					esac
				done
			else
				export SIM_FLOW_CLEAN=1
			fi
			$EXA_CODE/bin/powercase -script launcher.py -expose_nu_over_t
			break
            ;;
        "Prepare Init fnc")
			if [ -f "./$SIM_FLOW_PATH/GFIT_flow.ckpt.fnc" ]; then
				echo "Generating input for optydb_fieldmod from flow sim solution using $THREADS_FIELDMOD cores in lowmem status (serial calculation)"
				cat <<EOF> _py_submit.py
import GFIT_lib_r33
import os
workdir=os.getcwd()
GFIT_lib_r33.prepare_fieldmod("%s/$SIM_FLOW_PATH/GFIT_flow.ckpt.fnc" % workdir,"%s/$SIM_AC_PATH/seed.fnc" % workdir)
EOF
				$EXA_CODE/bin/exapython _py_submit.py
				cd $SIM_AC_PATH
				$MPI_PATH/mpirun -n $THREADS_FIELDMOD optydb_fieldmod -i optydb_fieldmod.i -o optydb_fieldmod.log -s lowmem
				break
			elif [ -f "./$SIM_AC_PATH/GFIT.ckpt.fnc" ]; then
				echo "Generating input for optydb_fieldmod from ac sim initial frame using $THREADS_FIELDMOD cores in lowmem status (serial calculation)"
				cat <<EOF> _py_submit.py
import GFIT_lib_r33
import os
workdir=os.getcwd()
GFIT_lib_r33.prepare_fieldmod("%s/$SIM_AC_PATH/GFIT.ckpt.fnc" % workdir,"%s/$SIM_AC_PATH/seed.fnc" % workdir)
EOF
				$EXA_CODE/bin/exapython _py_submit.py
				cd $SIM_AC_PATH
				$MPI_PATH/mpirun -n $THREADS_FIELDMOD optydb_fieldmod -i optydb_fieldmod.i -o optydb_fieldmod.log -s lowmem
				break
			else
				echo "error: flow/ac seed file do not exists!"
				echo ""
			fi
            ;;
        "Launch Impedance Eduction")
           echo "Launching Impedance Eduction Loop... (this may take a while)"
		    educt_folder_list=($(find . -name 'eduction_*'))
		    new_folder_num=$((${#educt_folder_list[@]}))
			new_folder_name=eduction_$(printf %03d $new_folder_num)
		    mkdir $new_folder_name
			
			ln -s ../$SIM_AC_PATH/GFIT.cdi $new_folder_name/GFIT.cdi
			ln -s ../$SIM_AC_PATH/midplane_meas_hf.snc $new_folder_name/midplane_meas_hf.snc
			
	        $EXA_CODE/bin/exapython << EOF
import GFIT_lib_r33
import os
GFIT_lib_r33.pre_processing('%s/$new_folder_name' % os.getcwd())
EOF
	        $EXA_CODE/bin/exapython << EOF

import os
import shutil
import subprocess

restart_folder = '%s/$new_folder_name/RESTART' % os.getcwd()
if os.path.exists(restart_folder):
    shutil.rmtree(restart_folder)
    
current_directory = os.getcwd()
gfit_regenerate = os.path.join(current_directory,'gfit_regenerate.py')

# Execute gfit_regenerate.py from the eduction_ directory
subprocess.Popen(['python', gfit_regenerate], cwd=os.path.join(os.getcwd(), "$new_folder_name"))


import simplex
import os
import shutil
import subprocess
import time
import threading
import simplex

def monitor_restart_folder():
    monitoring_active = True
    restart_folder = os.path.join(os.getcwd(), "$new_folder_name", "simplex_001", "RESTART")
    print("Sto cercando la cartella di restart in:", restart_folder)

    while monitoring_active:
        if os.path.exists(restart_folder):
            restart_folder = os.path.join(restart_folder, "..","..","simplex_000", "RESTART")
            shutil.copytree(restart_folder, os.path.join(os.getcwd(), "..", "RESTART"))
            monitoring_active = False
        else:
            time.sleep(10)

monitor_thread = threading.Thread(target=monitor_restart_folder)
monitor_thread.start()

simplex.run('%s/$new_folder_name' % os.getcwd()) 




EOF
			break
            ;;
        "Quit")
            break
            ;;
        *) echo "invalid option";;
    esac
done

