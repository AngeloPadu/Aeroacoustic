import GFIT_lib_r33 as GFIT

case = newCase("3D internal turbulence thermal gas no_particle_modeling single_precision vehicle_simulation_off high_subsonic_mach_regime disable_blt_model no_water_vapor_transport disable_bc_import_from_meas")
case.setPreferredUnitSet("mks")

GFIT.case0 = case
GFIT.prepare_case()
