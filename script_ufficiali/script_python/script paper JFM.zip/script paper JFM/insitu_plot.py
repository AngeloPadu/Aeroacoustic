#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 23 10:55:10 2024

@author: angelo
"""
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import math
import h5py
from scipy.signal import csd
from datetime import datetime
import pandas as pd
import matplotlib.ticker as ticker
import csv
import os
from matplotlib.ticker import FormatStrFormatter

now = datetime.now()
current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

"Set packages parameters"
plt.rcParams['text.usetex'] = True
plt.rcParams["font.family"] = ["Times New Roman"]
plt.rcParams['figure.constrained_layout.use'] = True
plt.rcParams['axes.formatter.use_locale'] = True
plt.rcParams['axes.formatter.useoffset'] = False
plt.rcParams.update({'font.size': 12})
plt.rcParams["figure.dpi"] = 100
xticks = [0.800,1.100,1.400,1.700,2.000,2.300]
plt.close('all')

"File parameters"
frequencies         = [1400]
ac_source           = 'up'
SPL                 = 130
Mach                = 0.3
version             = '14_1'
BC                  = 'NoSlip'
resolution          = 'fine'
geometry            = 'real_geometry'

nFreq           = len(frequencies)
      
"Case parameters"
Tc                  = 25                                                        # Temperature in Celsius
estimator           = 'H1'

"Liner parameters - NASA"
POA                 = 6.3/100                                                  # Percentage of Open Area
cvt_height          = 38.1e-3                                                # Cavity Height (m)
fsheet_thick        = 0.635e-3                                                 # Face Sheet thickness (m)
orifice_d           = 0.9906e-3                                                # Orifice diameter (m)
nm_orifice          = 8
n_cavities          = 11
cvt_width_m         = 12.446e-3


"Liner parameters - UFSC"
n_cavities_ufsc              = 11                                                        # Number of liner cavities
POA_ufsc                     = 8.75/100                                                   # Percentage of Open Area
cvt_height_ufsc              = 38.1e-3                                                   # Cavity Height (m)
fsheet_thick_ufsc            = 0.55e-3                                                  # Face Sheet thickness (m)
orifice_d_ufsc               = 1.169250e-3                                              # Orifice diameter (m)
orifice_d_min                = 1.05e-3
orifice_d_max                = 1.26e-3                                                 
linerLength_ufsc             = 136.906e-3 


"Flow parameters"
MeanMach            = 0.293                                                     # Mean Mach Number
BLDT                = 1.338e-3                                                   # Turbulent Boundary Layer Displacement Thickness

if Mach == 0:
    MeanMach = 0
    BLDT = 0
    
"Fluid parameters"
Pamb                = 101325                                                   # Ambient Pressure (Pa)
sutherland_tref     = 273.15                                                   # Sutherland Ref. Temperature  
Tk                  = Tc + sutherland_tref                                     # Temperature (Kelvin)
gamma               = 1.4                                                      # Heat Capacity Ratio (dry air)
Pr                  = 0.707                                                    # Prandtl
Runiv               = 8.314462                                                 # Ideal Gas Constant [J/K.mol]
mol_weight          = 28.9645/1000                                             # Mol. Weight of Air
R                   = Runiv/mol_weight                                         # Specific Gas Constant
c0                  = np.sqrt(gamma*R*Tk)                                      # Sound Speed
rho                 = Pamb/(R*Tk)                                              # Density
nu                  = ( 1.458e-6*(Tk**1.5) / (110.4 + Tk) )/rho                # Viscosity
mm                  = 1/25.4                                                   # Variable to plots


######################PATH Definition########################
path                = '/media/angelo/results/Progetto_ANEMONE/Cases/0-TUD_UFSC/NoSlip_NoSlip Cases/Liner NASA/{}/{}/{}/{}/{}/in_situ'.format(ac_source,geometry,resolution,SPL,frequencies[0])

path_experimental = '/media/angelo/results/Progetto_ANEMONE/Risultati/file txt/experimental_data/NASA/'

path_save = '/home/angelo/Scrivania/PhD/aeroacustica/figure_paper_JFM/Acoustics/M=0.3/impedance results/'.format(frequencies[0])




if Mach == 0.3:
    #if ac_source == 'up':
        ufsc_exp_realZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
        ufsc_exp_imagZ_up_145      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
        ufsc_exp_realZ_up_145      = ufsc_exp_realZ_up_145.mean(axis=1)
        ufsc_exp_imagZ_up_145      = ufsc_exp_imagZ_up_145.mean(axis=1)
        



        ufsc_exp_realZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,7:9]
        ufsc_exp_imagZ_dw      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,17:19]
        ufsc_exp_realZ_dw      = ufsc_exp_realZ_dw.mean(axis=1)
        ufsc_exp_imagZ_dw      = ufsc_exp_imagZ_dw.mean(axis=1)






Mach = 0

in_situ_ufsc_exp_realZ_noflow      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,2:4]
in_situ_ufsc_exp_imagZ_noflow      = np.asarray(pd.read_csv(path_experimental + 'ufsc{}_M{}.csv'.format(SPL,Mach),header=0,sep=';'))[:,12:14]
in_situ_ufsc_exp_realZ_noflow   = in_situ_ufsc_exp_realZ_noflow.mean(axis=1)
in_situ_ufsc_exp_imagZ_noflow   = in_situ_ufsc_exp_imagZ_noflow.mean(axis=1)

 
 
exp_freqs = np.arange(0.5, 3.1, 0.1) 
freqs_UTAS = np.arange(0.5,3.0,0.1)

#### IMPEDANCE RESULTS ################
if SPL == 145:
    insitu_fine_up = np.array([0.49-1.35j,0.46-0.37j,0.4+0.22j])
    
    
    resistance_fine_up_max = np.array([1.42,1.33,1.33])
    
    resistance_fine_up_min = np.array([0.46,0.42,0.38])
    
    reactance_fine_up_max = np.array([-1.26,-0.26,0.40])
    
    reactance_fine_up_min = np.array([-1.61,-0.67,-0.15])
     
    insitu_fine_dw = np.array([1.38-1.33j,1.30-0.36j,1.12+0.21j])
    
    
    resistance_fine_dw_max = np.array([1.57,1.51,1.33])
    
    resistance_fine_dw_min = np.array([0.36,0.40,0.38])
    
    reactance_fine_dw_max = np.array([-1.34,-0.20,0.40])
    
    reactance_fine_dw_min = np.array([-1.59,-0.67,0.15]) 
    
    
    insitu_fine_noflow = np.array([0.22-1.33j,0.38-0.34j,0.31+0.28j])
    
    resistance_fine_noflow_max = np.array([0.31,0.45,0.38])
    
    resistance_fine_noflow_min = np.array([0.02,0.25,0.30])
    
    reactance_fine_noflow_max = np.array([-1.40,-0.27,0.44])
    
    reactance_fine_noflow_min = np.array([-1.46,-0.47,0.15])

else:
    
    insitu_fine_up = np.array([0.46-1.41j,0.52-0.39j,0.4+0.17j])
    
    resistance_fine_up_max = np.array([1.48,1.37,1.25])
    
    resistance_fine_up_min = np.array([0.46,0.58,0.35])
    
    reactance_fine_up_max = np.array([-1.58,-0.26,0.40])
    
    reactance_fine_up_min = np.array([-1.31,-0.67,-0.15])
     
   
    
    insitu_fine_dw = np.array([1.31-1.22j,1.37-0.43j,1.12+0.21j])
    
    resistance_fine_dw_max = np.array([1.50,1.75,1.32])
    
    resistance_fine_dw_min = np.array([0.40,0.26,0.41])
    
    reactance_fine_dw_max = np.array([-1.11,-0.26,0.48])
    
    reactance_fine_dw_min = np.array([-1.52,-0.81,-0.10]) 
    
    
    
    insitu_fine_noflow = np.array([0.09-1.27j,0.12-0.28j,0.10+0.75j])
    
    resistance_fine_noflow_max = np.array([0.18,0.17,0.15])
    
    resistance_fine_noflow_min = np.array([0.0,0.02,0.05])
    
    reactance_fine_noflow_max = np.array([-1.32,-0.23,0.8])
    
    reactance_fine_noflow_min = np.array([-1.41,-0.38,0.55])


fig, ax = plt.subplots(1, 1, figsize=(9,9))

ax.scatter(exp_freqs, in_situ_ufsc_exp_realZ_noflow, color='k', linestyle='solid', linewidth=3, label='exp. noflow')

ax.scatter(exp_freqs, ufsc_exp_realZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. up')

ax.scatter(exp_freqs, ufsc_exp_realZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')

ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_noflow), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. noflow')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_noflow_max, resistance_fine_noflow_min)):
    y=(ma-mi)/2
    yerr=(ma-mi)
    # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
    ax.plot([x,x],[mi,ma],linestyle='solid',color='k',linewidth=3)
    ax.hlines(ma, x - 0.05, x + 0.05, colors='k', linewidth=3)
    ax.hlines(mi, x - 0.05, x + 0.05, colors='k', linewidth=3)

ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_up), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_up_max, resistance_fine_up_min)):
    y=(ma-mi)/2
    yerr=(ma-mi)
    # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
    ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
    ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
    ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)



ax.scatter([0.800, 1.400, 2.000], np.real(insitu_fine_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], resistance_fine_dw_max, resistance_fine_dw_min)):
   y=(ma-mi)/2
   yerr=(ma-mi)
   # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
   ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
   ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
   ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)




yticks = [0.0,0.5, 1.0,1.5, 2.0,2.5 ]
xticks = [ 1.0, 1.5, 2.0, 2.5]
ax.set_xlabel("$f, kHz$", fontsize=40)
ax.set_xlim(0.5, 2.6)
ax.set_ylim(0.0, 2.5)
ax.set_xticks(xticks)
ax.set_yticks(yticks)
# ax.legend(numpoints=1, loc='best', fontsize=30)
ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
ax.set_ylabel(r'$\theta$', fontsize=40)
ax.tick_params(axis='both', labelsize=40)
ax.grid(alpha=0.5)  


fig.savefig(path_save + 'resistance_in_situ_{}.svg'.format(SPL), dpi=300)

fig, ax = plt.subplots(1, 1, figsize=(9,9))

ax.scatter(exp_freqs, in_situ_ufsc_exp_imagZ_noflow, color='k', linestyle='solid', linewidth=3, label='exp. noflow')

ax.scatter(exp_freqs, ufsc_exp_imagZ_up_145, color='r', linestyle='solid', linewidth=3, label='exp. up')

ax.scatter(exp_freqs, ufsc_exp_imagZ_dw, color='b', linestyle='solid', linewidth=3, label='exp. down')

ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_noflow), edgecolor='k', color='k', s=300, marker='s', facecolor='k', linewidth=3, label='sim. noflow')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_noflow_max, reactance_fine_noflow_min)):
    y=(ma-mi)/2
    yerr=(ma-mi)
    # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
    ax.plot([x,x],[mi,ma],linestyle='solid',color='k',linewidth=3)
    ax.hlines(ma, x - 0.05, x + 0.05, colors='k', linewidth=3)
    ax.hlines(mi, x - 0.05, x + 0.05, colors='k', linewidth=3)

ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_up), edgecolor='r', color='r', s=300, marker='s', facecolor='r', linewidth=3, label='sim. up')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_up_max, reactance_fine_up_min)):
    y=(ma-mi)/2
    yerr=(ma-mi)
    # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
    ax.plot([x,x],[mi,ma],linestyle='solid',color='r',linewidth=3)
    ax.hlines(ma, x - 0.05, x + 0.05, colors='r', linewidth=3)
    ax.hlines(mi, x - 0.05, x + 0.05, colors='r', linewidth=3)



ax.scatter([0.800, 1.400, 2.000], np.imag(insitu_fine_dw), edgecolor='b', color='b', s=300, marker='s', facecolor='b', linewidth=3, label='sim. down')

for i, (x, ma,mi) in enumerate(zip([0.8, 1.4, 2.0], reactance_fine_dw_max, reactance_fine_dw_min)):
   y=(ma-mi)/2
   yerr=(ma-mi)
   # ax.errorbar(x, y, yerr, linestyle='None', color='r', linewidth=3)
   ax.plot([x,x],[mi,ma],linestyle='solid',color='b',linewidth=3)
   ax.hlines(ma, x - 0.05, x + 0.05, colors='b', linewidth=3)
   ax.hlines(mi, x - 0.05, x + 0.05, colors='b', linewidth=3)


ax.set_xlabel('$f, kHz$',fontsize=40)
ax.set_xlim(0.5,2.6)
ax.set_ylim(-4,1.5)
ax.set_xticks(xticks, xticks)
yticks = [-3,-2,-1,0,1,2]
ax.set_yticks(yticks, yticks)
ax.legend(numpoints=1,loc='lower right',fontsize=30)
ax.set_ylabel(r'$\chi$',fontsize=40)
ax.tick_params(axis='both', labelsize = 40)
ax.grid(alpha=0.5)  

fig.savefig(path_save + 'reactance_up_dw_{}.svg'.format(SPL), dpi=300)
