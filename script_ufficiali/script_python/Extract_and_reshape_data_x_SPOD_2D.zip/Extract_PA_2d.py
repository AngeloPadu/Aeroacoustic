#  -*- coding: utf-8 -*-

# Inputs

import sys, os, math, subprocess

import numpy as np

InputFile = "/media/angelo/Expansion/Sharp_SingleT_1000Hz_130dB/plane_duct.snc"
workdir = os.getcwd()

newdir 	= workdir+"/Export_x_SPOD/"

os.makedirs(newdir)

Xmin        = -0.003
Xmax        = 0.003
Ymin        = -0.005
Ymax        = 0.005
Z           = 8.784485e-10


NumPointsX  = 10
NumPointsY  = 10
NumPointsZ  = 10

StartFrame  = 850
EndFrame    = 860

#

	
project0 = app.newProject()
calculation0 = project0.createCalculation()
calculation0.calcFunction = "Sample"
calculation0.inputTab.filename = InputFile
variable0 = calculation0.inputTab.createVariable()
variable0.name = "XVelocity"
variable1 = calculation0.inputTab.createVariable()
variable1.name = "YVelocity"
variable2 = calculation0.inputTab.createVariable()
variable2.name = "ZVelocity"
calculation0.inputTab.autoSelectFrames = False
calculation0.inputTab.start = StartFrame
calculation0.inputTab.end = EndFrame
calculation0.outputTab.outputFormat = "Rake2D"
calculation0.outputTab.rake2DOptions.lengthUnit = "m"
calculation0.outputTab.rake2DOptions.cornerA.x = Xmin
calculation0.outputTab.rake2DOptions.cornerA.y = Ymin
calculation0.outputTab.rake2DOptions.cornerA.z = Z
calculation0.outputTab.rake2DOptions.cornerB.x = Xmin
calculation0.outputTab.rake2DOptions.cornerB.y = Ymax
calculation0.outputTab.rake2DOptions.cornerB.z = Z
calculation0.outputTab.rake2DOptions.cornerC.x = Xmax
calculation0.outputTab.rake2DOptions.cornerC.y = Ymax
calculation0.outputTab.rake2DOptions.cornerC.z = Z
calculation0.outputTab.rake2DOptions.maxProjectionDistance = 0.01
calculation0.outputTab.rake2DOptions.ABGridsize.numPoints = NumPointsY
calculation0.outputTab.rake2DOptions.BCGridsize.numPoints = NumPointsX
calculation0.apply()
project0.save(newdir+"/Extract_PA_0.pap")
project0.calculations["Calc_0"].queue()
exportData0 = project0.calculations["Calc_0"].createExportData()
exportData0.apply()
project0.calculations["Calc_0"].exportDatas[newdir+"Export_z_planes_0"].queue()
