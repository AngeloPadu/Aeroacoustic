function Output = Extract_data_PA_2D(filename)

data = importdata(filename);
data_1 = readmatrix(filename,'Delimiter', ' ', 'CommentStyle', '#');

% Espressione regolare per trovare valori tra parentesi
pattern = '\((-?\d+(?:\.\d+)?(?:e[-+]?\d+)?),(-?\d+(?:\.\d+)?(?:e[-+]?\d+)?),(-?\d+(?:\.\d+)?(?:e[-+]?\d+)?)\),';

% Pattern per estrarre i nomi delle variabili
pattern_var = 'ExtractSignal\s+([^,]+)';

% Espressione regolare per trovare il numero nella terza riga
number_pattern = '# Number of variables = (\d+)';

% Inizializza una cella per i valori estratti
Output = struct();
extractedValues = {};
x = [];
y = [];
z = [];
j = 1;
num_lines_with_hash = 0;
num_variables = [];
extracted_text = [];

% Estrai i valori tra parentesi da ogni riga
for i = 1:numel(data)
    % Controlla se la riga contiene '#'
    if contains(data{i}, '#')
        num_lines_with_hash = num_lines_with_hash + 1;
    end
    
    % Trova i valori tra parentesi
    matches = regexp(data{i}, pattern, 'tokens');
    if ~isempty(matches)

        extractedValues{j} = cellfun(@str2double, matches{1});
        
        x(j) = extractedValues{j}(1);
        y(j) = extractedValues{j}(2);
        z(j) = extractedValues{j}(3);
        
        matches_var{j} = regexp(data{i}, pattern_var, 'tokens', 'once');
        
        j = j + 1;
    end

    % Se siamo sulla terza riga, estrai il numero di variabili
    if i == 3
        number_match = regexp(data{i}, number_pattern, 'tokens');
        if ~isempty(number_match)

            num_variables = str2double(number_match{1}{1});

        end
    end
end

matches_var = vertcat(matches_var{:});
matches_var = unique(matches_var);

num_lines_with_hash = num_lines_with_hash +1;

% Crea una griglia di punti
[X, Y] = meshgrid(unique(x), unique(y));

% Visualizza la griglia
% scatter(X(:), Y(:), '.');
% xlabel('X');
% ylabel('Y');
% title('Griglia di punti');

delimiter = (length(data_1(1,:))-1)/num_variables ;

i = 1;
k = 1;
time = data_1(:,1);
data_1 = data_1(:,2:end);

for n_v = 1:num_variables
    % Calcola gli indici per estrarre i dati
    start_col = 1 + delimiter * (k-1);
    end_col = delimiter * k;
    % Estrai i dati e assegnali alla variabile nel cell array
    var_data{n_v} = data_1(:, start_col:end_col);
    % Aggiorna i contatori
    i = i + 1;
    k = k + 1;
end


for t = 1:length(data_1(:,1))
    for i = 1:size(X, 1)
        for j = 1:size(X, 2)
            idx = intersect(find(Y(i, 1) == y), find(X(1, j) == x));
            if ~isempty(idx)
                idx = idx(1);
                if Y(i, 1) == y(idx) && X(1, j) == x(idx)
                    for n_v = 1:num_variables
                        Var_data{n_v}(i, j, t) = var_data{n_v}(t, idx);
                    end
                end
            end
        end
    end
end


% Impostare tutti gli zeri a NaN in ciascuna matrice contenuta in var_data
Var_data = cellfun(@(x) replace_zeros_with_nan(x), Var_data, 'UniformOutput', false);

Output.time = time;
Output.X = X;
Output.Y = Y;

for i=1:num_variables
    clean_name = strrep(matches_var{i}, '-', '');
  
    Output.(clean_name) = Var_data{i};
   
end

% figure; 
% for i = 1:length(data_1(:,1))
%     % Plot della pcolor
%     pcolor(X, Y, Var_data{1}(:,:,i)), shading interp
%     caxis_min = max(Var_data{1}(:,:,i))-200; 
%     caxis_max = max(Var_data{1}(:,:,i));  
%     c = colorbar;
%     c.Label.String = '$P$';
%     c.Label.Interpreter = 'latex';
%     c.TickLabelInterpreter = 'latex';
%     c.Label.FontSize = 10;
%     caxis([caxis_min(1), caxis_max(1)]);
% 
% 
%     colormap(jet)  
% 
% 
%     axis equal
%     drawnow
%     pause(0.05)
% end


% Funzione ausiliaria per sostituire gli zeri con NaN
function mat = replace_zeros_with_nan(mat)
    mat(mat == 0) = NaN;
end
end