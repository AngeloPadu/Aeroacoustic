#  -*- coding: utf-8 -*-
## Assicura che la directory di output esista
import os
import numpy as np


import os
current_dir = os.getcwd()

vorticity_dir = "./vorticity_first"
if not os.path.exists(vorticity_dir):
    os.makedirs(vorticity_dir)
flow = "./vorticity_first/flow"    
if not os.path.exists(flow):
	os.makedirs(flow)
    

project0 = app.newProject()
project0.save(vorticity_dir + "/extract_for_vorticity.pap")
calculation0 = project0.createCalculation()
calculation0.name = "xVel"
calculation0.calcFunction = "Sample"
calculation0.inputTab.filename = current_dir + "/ac_plane1_stream_avg.snc"
calculation0.inputTab.variables[0].name = "XVelocity"
calculation0.outputTab.outputFormat = "Rake2D"
calculation0.outputTab.rake2DOptions.cornerC.x = 0.009223
calculation0.outputTab.rake2DOptions.cornerC.y = -0.000615
calculation0.outputTab.rake2DOptions.cornerC.z = 0.006223
calculation0.outputTab.rake2DOptions.cornerB.z = 0.006223
calculation0.outputTab.rake2DOptions.cornerA.z = 0.006223
calculation0.outputTab.rake2DOptions.cornerA.x = 0.003223
calculation0.outputTab.rake2DOptions.cornerB.x = 0.009223
calculation0.outputTab.rake2DOptions.cornerA.y = 0
calculation0.outputTab.rake2DOptions.cornerB.y = 0.00125
calculation0.outputTab.rake2DOptions.cornerA.y = 0.00125
calculation0.outputTab.rake2DOptions.ABGridsize.sizeVia = "Delta"
calculation0.outputTab.rake2DOptions.ABGridsize.delta = 0.0000243
calculation0.outputTab.rake2DOptions.BCGridsize.sizeVia = "Delta"
calculation0.outputTab.rake2DOptions.BCGridsize.delta = 0.0000243
calculation0.outputTab.rake2DOptions.maxProjectionDistance = 0.0001
calculation0.apply()
calculation0.apply()
calculation0.delete()
exportData0 = project0.calculations["xVel"].createExportData()
exportData0.apply()
exportData0.apply()
exportData0.delete()
calculation1 = project0.calculations["xVel"].copy()
calculation1.name = "yVel"
calculation1.inputTab.variables[0].name = "YVelocity"
calculation1.apply()
calculation1.apply()
calculation1.delete()
exportData1 = project0.calculations["yVel"].createExportData()
exportData1.apply()
exportData1.apply()
exportData1.delete()
calculation2 = project0.calculations["yVel"].copy()
calculation2.name = "density"
calculation2.inputTab.variables[0].name = "Density"
calculation2.apply()
calculation2.apply()
calculation2.delete()
exportData2 = project0.calculations["density"].createExportData()
exportData2.apply()
exportData2.apply()
exportData2.delete()
project0.save()
project0.queueAll(True)
