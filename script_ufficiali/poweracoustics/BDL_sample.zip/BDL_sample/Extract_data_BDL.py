#!/usr/bin/env python

import sys, os, math, subprocess

workdir = os.getcwd()
"NASA liner"
"Script to extract pressure time histories for the eduction methods"

newdir 	= workdir+"/BDL_samples/"
#0os.makedirs(newdir)

project0 = app.newProject()
calculation0 = project0.createCalculation()
calculation0.calcFunction = "Sample"
calculation0.name = "BDL_sample_0745"
calculation0.inputTab.variables[0].delete()
variable0 = calculation0.inputTab.createVariable()
variable0.name = "XVelocity"
calculation0.inputTab.filename = workdir+"/ac_plane1_stream_inst.snc"
calculation0.outputTab.filename = workdir+"/BDL_samples/BDL_0745.calc"
calculation0.outputTab.outputFormat = "ImportPoints"
calculation0.outputTab.ptfileOptions.filename = workdir+"/BDL_points/points_boundarylayer_0745.txt"
calculation0.apply()
exportData0 = project0.calculations["BDL_sample_0745"].createExportData()
exportData0.name = "BDL_sample_0745"
exportData0.filename = workdir+"/BDL_samples/bdl_0745.txt"
exportData0.apply()
 
project0.save(workdir+"/BDL_samples/BDL_sample.pap")
project0.queueAll(True)
